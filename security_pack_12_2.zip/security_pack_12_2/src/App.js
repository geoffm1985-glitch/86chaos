import React, { useState, useEffect } from 'react';
import { Bell, Check, Camera, ChevronLeft, ChevronRight, MessageSquare, Plus, Trash2, Users, Calendar, Clock, X, Loader2, Package, ClipboardList, Menu, Settings, LogOut, Shield, Send, Repeat, Edit, Moon, Sun, TrendingUp, BookOpen, Search, ChefHat, Scale, Coffee, Star, Bug, Wrench, Globe } from 'lucide-react';import { initializeApp } from 'firebase/app';
import { getFirestore, collection, addDoc, updateDoc, deleteDoc, doc, onSnapshot, query, where, getDoc, setDoc, getDocs, enableIndexedDbPersistence } from 'firebase/firestore';
import { getAuth, signInWithEmailAndPassword, sendPasswordResetEmail, createUserWithEmailAndPassword, updatePassword } from 'firebase/auth';
import { getMessaging, getToken, onMessage } from "firebase/messaging";
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { MapContainer, TileLayer, Marker, Circle, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet'; 

// Fix for React-Leaflet invisible pin issue
const customMapIcon = new L.Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});


// --- Master Theme (Mapped to Image 6187_2.png) ---
const T = {
  bg: "bg-[#12161A] text-slate-100",
  card: "bg-[#1A2126] border border-[#2A353D] shadow-lg rounded-xl",
  border: "border-[#2A353D]",
  copper: "text-[#D4A381]",
  grad: "bg-gradient-to-r from-[#C59373] to-[#8F6040]",
  btn: "bg-gradient-to-r from-[#C59373] to-[#8F6040] text-slate-900 font-black uppercase tracking-wider rounded-lg shadow-md hover:opacity-90 transition-all px-3 py-2 text-xs text-center",
  btnAlt: "bg-[#12161A] text-slate-300 border border-[#2A353D] font-bold rounded-lg hover:text-[#D4A381] transition-all px-3 py-2 text-xs",
  input: "w-full p-2.5 bg-[#12161A] border border-[#2A353D] text-white rounded-lg outline-none focus:border-[#D4A381] transition-colors font-medium text-sm",
  label: "block text-[10px] uppercase tracking-widest font-bold text-slate-400 mb-1",
  muted: "text-slate-400",
  th: "bg-[#12161A] border-b border-[#2A353D] text-[10px] font-black text-[#D4A381] uppercase tracking-widest p-2.5",
  row: "hover:bg-[#12161A]/50 border-b border-[#2A353D] transition-colors p-2.5",
};

// --- Firebase Initialization ---
// 1. TEST DATABASE CONFIG (Sandbox)
const testConfig = {
  apiKey: "AIzaSyBIRGMeLnVE3w3i1WZJzurcp-LkeaNZ3hw",
  authDomain: "chaos-test-d1601.firebaseapp.com",
  projectId: "chaos-test-d1601",
  storageBucket: "chaos-test-d1601.firebasestorage.app",
  messagingSenderId: "534993379994",
  appId: "1:534993379994:web:9fefb6e10309223afe7523"
};

// 2. MAIN PRODUCTION DATABASE CONFIG (Live Data)
const prodConfig = {
  apiKey: "AIzaSyA0kkmRCqGNoB1LXKfuCNIl1JKDyQci9hA",
  authDomain: "cheers-34b8d.firebaseapp.com",
  projectId: "cheers-34b8d",
  storageBucket: "cheers-34b8d.firebasestorage.app",
  messagingSenderId: "762225019248",
  appId: "1:762225019248:web:3e142c9563e58ca762a7b5",
  measurementId: "G-JFZ6EZB0E3"
};

// 3. THE SWITCHER (Automatically routes the database based on the URL)
const firebaseConfig = window.location.hostname === 'app.86chaos.com' ? prodConfig : testConfig;

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const storage = getStorage(app);
export const messaging = typeof window !== "undefined" ? getMessaging(app) : null;

// Kitchen Wi-Fi Armor: Keep app working in walk-in coolers
enableIndexedDbPersistence(db).catch((err) => console.warn("Offline mode issue:", err.code));

const auth = getAuth(app);

// --- OPTIONAL APP CHECK + SECURE API KEYCHAIN ---
// Put your Firebase App Check reCAPTCHA Enterprise site key here after enabling App Check in Firebase.
// Example: const APPCHECK_RECAPTCHA_ENTERPRISE_SITE_KEY = '6Lc...';
const APPCHECK_RECAPTCHA_ENTERPRISE_SITE_KEY = '';
let appCheckInstance = null;

if (typeof window !== "undefined" && APPCHECK_RECAPTCHA_ENTERPRISE_SITE_KEY && !window.__chaosAppCheckBooted) {
  window.__chaosAppCheckBooted = true;
  import('firebase/app-check')
    .then(({ initializeAppCheck, ReCaptchaEnterpriseProvider }) => {
      appCheckInstance = initializeAppCheck(app, {
        provider: new ReCaptchaEnterpriseProvider(APPCHECK_RECAPTCHA_ENTERPRISE_SITE_KEY),
        isTokenAutoRefreshEnabled: true
      });
      window.__chaosAppCheckReady = true;
    })
    .catch((err) => console.warn('App Check not initialized:', err?.message || err));
}

const getAppCheckHeader = async () => {
  if (!appCheckInstance) return {};
  try {
    const { getToken: getAppCheckToken } = await import('firebase/app-check');
    const result = await getAppCheckToken(appCheckInstance, false);
    return result?.token ? { 'X-Firebase-AppCheck': result.token } : {};
  } catch (err) {
    console.warn('App Check token unavailable:', err?.message || err);
    return {};
  }
};

// This attaches the real Firebase Auth token to Vercel API requests.
// Do not trust client-sent role/email/restaurantId in API routes; verify this token server-side.
const secureFetch = async (url, options = {}) => {
  if (!auth.currentUser) throw new Error("Unauthorized: No active user session.");
  const { forceTokenRefresh = false, headers: optionHeaders = {}, ...fetchOptions } = options;
  const token = await auth.currentUser.getIdToken(forceTokenRefresh);
  const appCheckHeader = await getAppCheckHeader();
  const headers = {
    ...optionHeaders,
    ...appCheckHeader,
    'Authorization': `Bearer ${token}`
  };
  return fetch(url, { ...fetchOptions, headers });
};

// --- Master Configuration ---
const MASTER_ADMIN_EMAIL = 'geoffm1985@gmail.com';
const EVENT_TAGS = ['Standard Day', 'Packers Game', 'Brewers Game', 'Live Music', 'Severe Weather', 'Private Catering', 'Holiday'];

// --- VERSION TRACKING ---
const CURRENT_VERSION = '12.2.0-security-admin';

// --- Helpers ---
const useLiveCollection = (coll, restId) => {
  const [data, setData] = useState([]);
  useEffect(() => {
    if (!restId) { setData([]); return; }
    const q = query(collection(db, coll), where("restaurantId", "==", restId));
    const unsubscribe = onSnapshot(
      q,
      snap => setData(snap.docs.map(d => ({ id: d.id, ...d.data() }))),
      err => {
        console.error(`Live collection error for ${coll} / ${restId}:`, err);
        setData([]);
      }
    );
    return () => unsubscribe();
  }, [coll, restId]);
  return data;
};
const formatDate = (date) => new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().split('T')[0];
const getToday = () => formatDate(new Date());
const getMonthStr = (d) => (d || getToday()).substring(0, 7);
const formatDisplayDate = (d) => new Date(d + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
const formatDisplayFullDate = (d) => new Date(d + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
const formatDisplayMonth = (m) => new Date(m + '-01T12:00:00').toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
const getDaysInMonth = (m) => new Date(m.split('-')[0], m.split('-')[1], 0).getDate();
const formatShortTime = (t) => { if (!t) return ''; if(t === 'CLOSE') return 'CL'; try { let [h, m] = t.split(':'); h = parseInt(h, 10); return `${h % 12 || 12}${m === '00' ? '' : ':' + m}${h >= 12 ? 'p' : 'a'}`; } catch(e){ return t; } };
const getAvatar = (name, url) => url || `https://ui-avatars.com/api/?name=${encodeURIComponent(name||'Staff')}&background=random&color=fff&bold=true`;
const generateTempPass = () => Math.random().toString(36).slice(-6).toUpperCase();

const sanitizeCachedUser = () => {
  if (typeof window === 'undefined') return;
  try {
    const raw = localStorage.getItem('86chaosUser');
    if (!raw) return;
    const cached = JSON.parse(raw);
    if (cached && Object.prototype.hasOwnProperty.call(cached, 'password')) {
      delete cached.password;
      localStorage.setItem('86chaosUser', JSON.stringify(cached));
    }
  } catch (err) {
    localStorage.removeItem('86chaosUser');
  }
};
sanitizeCachedUser();
const getExpDate = (d) => { const dt = new Date(d + 'T12:00:00'); dt.setDate(dt.getDate() + 6); return `${dt.getMonth()+1}/${dt.getDate()}/${dt.getFullYear().toString().slice(-2)}`; };

// --- Global Crash Reporter & Telemetry Engine ---
if (typeof window !== 'undefined' && !window.crashCatcherAttached) { 
  window.crashCatcherAttached = true; 
  window.breadcrumbs = [];

// Silently record the last 15 buttons clicked
  window.addEventListener('click', (e) => {
    let target = e.target;
    // Find the closest button if they clicked an icon inside a button
    let btn = target.closest('button');
    if (btn) {
      // Improved logic: Check title, aria-label, text, or the SVG class name
      let text = btn.title || btn.getAttribute('aria-label') || btn.innerText || '';
      if (!text.trim()) {
        const svg = btn.querySelector('svg');
        if (svg && svg.classList && svg.classList.length > 0) {
           // Extracts 'Trash2' or 'Edit' from the Lucide SVG class
           text = svg.classList[0].replace('lucide-', '').replace('lucide', 'Icon');
        } else {
           text = 'Icon Button';
        }
      }
      if (text.length > 40) text = text.substring(0, 40) + '...';
      window.breadcrumbs.push({ time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second:'2-digit'}), action: 'Clicked', target: text.trim().replace(/\n/g, ' ') });
      if (window.breadcrumbs.length > 15) window.breadcrumbs.shift();
    }
  }, true);

  window.onerror = (msg, url, lineNo, columnNo, error) => { 
    addDoc(collection(db, "crashReports"), { 
      type: 'error', 
      message: msg, 
      stack: error?.stack || '', 
      breadcrumbs: window.breadcrumbs || [], // Attach the breadcrumbs to the crash
      userAgent: navigator.userAgent, // Captures device, OS, and browser info
      screenSize: `${window.innerWidth}x${window.innerHeight}`, // Helps debug UI clipping
      time: new Date().toISOString() 
    }).catch(()=>{}); 
    return false; 
  }; 
}

// --- HOLIDAY & TIME ENGINE ---
const HOLIDAYS = {
  // Fixed Date Holidays (Work every year)
  "01-01": "New Year's Day", "02-14": "Valentine's Day", "03-17": "St. Patrick's Day", 
  "05-05": "Cinco de Mayo", "07-04": "Independence Day", "10-31": "Halloween", 
  "11-11": "Veterans Day", "12-24": "Christmas Eve", "12-25": "Christmas Day", "12-31": "NYE",
  
  // 2026 Floating Holidays
  "2026-02-08": "Super Bowl", "2026-03-31": "Opening Day", "2026-04-05": "Easter", "2026-05-10": "Mother's Day", 
  "2026-05-25": "Memorial Day", "2026-06-21": "Father's Day", "2026-09-07": "Labor Day", "2026-11-26": "Thanksgiving",

  // 2027 Floating Holidays
  "2027-02-14": "Super Bowl", "2027-03-25": "Opening Day", "2027-03-28": "Easter", "2027-05-09": "Mother's Day", 
  "2027-05-31": "Memorial Day", "2027-06-20": "Father's Day", "2027-09-06": "Labor Day", "2027-11-25": "Thanksgiving",

  // 2028 Floating Holidays
  "2028-02-13": "Super Bowl", "2028-03-30": "Opening Day", "2028-04-16": "Easter", "2028-05-14": "Mother's Day", 
  "2028-05-29": "Memorial Day", "2028-06-18": "Father's Day", "2028-09-04": "Labor Day", "2028-11-23": "Thanksgiving"
};
const getHoliday = (dateStr) => {
  if (!dateStr) return null;
  const mmdd = dateStr.substring(5);
  return HOLIDAYS[dateStr] || HOLIDAYS[mmdd] || null;
};


// --- SYSTEM AUDIT LOGGER ---
const logAudit = async (user, action, target, details) => {
  if (!user || !user.restaurantId) return;
  try {
    const isGhost = !!user.isGhost;
    await addDoc(collection(db, "auditLogs"), {
      userId: isGhost ? (user.ghostRealUserId || user.id || 'system') : (user.id || 'system'),
      userName: isGhost
        ? `${user.ghostRealUserName || user.name || 'System'} (Ghost${user.ghostTargetUserName ? ` as ${user.ghostTargetUserName}` : ''})`
        : (user.name || 'System'),
      ghostTargetUserId: user.ghostTargetUserId || null,
      ghostTargetUserName: user.ghostTargetUserName || null,
      ghostWorkspaceId: isGhost ? user.restaurantId : null,
      action,
      target,
      details,
      timestamp: new Date().toISOString(),
      restaurantId: user.restaurantId,
      isGhost
    });
  } catch (err) { console.error("Audit log failed:", err); }
};


// --- UI Components ---
// ============================================================================
// BRANDING & LOGOS
// ============================================================================
const CheersLogo = () => (
  <div className="flex items-center gap-2 sm:gap-3 cursor-pointer transition-opacity hover:opacity-80">
    <img src="/wisco.png" alt="86 App Icon" className="h-8 w-8 sm:h-9 w-auto" />
    <img src="/6139.png" alt="86 Chaos OS" className="h-5 sm:h-6 w-auto" />
  </div>
);


const Modal = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-[#12161A]/80 z-[60] flex items-center justify-center p-4 backdrop-blur-md transition-opacity">
      <div className={`${T.card} max-w-md w-full max-h-[90vh] overflow-y-auto`}>
        <div className={`flex justify-between items-center p-4 border-b ${T.border}`}>
          <h3 className="font-bold text-lg text-white">{title}</h3>
          <button onClick={onClose} className="p-1.5 hover:bg-[#12161A] rounded-full text-slate-400 hover:text-white transition-colors"><X size={20}/></button>
        </div>
        <div className="p-4">{children}</div>
      </div>
    </div>
  );
};

const DrawerMenu = ({ isOpen, onClose, activeTab, setActiveTab, appUser, setAppUser, hasUnreadMessages, hasMyShiftAlert, hasScheduleBuilderAlert, clientFeatures = {}, addToast }) => {
  const [isBugModalOpen, setIsBugModalOpen] = useState(false);
  const [bugText, setBugText] = useState('');
  const [isSubmittingBug, setIsSubmittingBug] = useState(false);

  const handleBugSubmit = async (e) => {
    e.preventDefault();
    if (!bugText.trim()) return;
    setIsSubmittingBug(true);
    try {
      await addDoc(collection(db, "crashReports"), {
        type: 'user_reported_bug',
        message: `USER REPORT: ${bugText.trim()}`,
        user: appUser?.name || 'Unknown',
        restaurantId: appUser?.restaurantId || 'Unknown',
        userAgent: navigator.userAgent,
        screenSize: `${window.innerWidth}x${window.innerHeight}`,
        time: new Date().toISOString()
      });
      setBugText('');
      setIsBugModalOpen(false);
      if (addToast) addToast('Report Sent', 'Bug sent directly to the dev team. Thanks!');
    } catch (err) {
      if (addToast) addToast('Error', 'Failed to send bug report.');
    }
    setIsSubmittingBug(false);
  };

  if (!isOpen && !isBugModalOpen) return null;
  const tabs = [];
  const perms = appUser?.permissions || {};
  const isGod = appUser?.email?.toLowerCase() === MASTER_ADMIN_EMAIL.toLowerCase() || appUser?.isSuperAdmin;

  const isEnabled = (feat) => clientFeatures[feat] !== false;

  if (isEnabled('schedule')) tabs.push({ id: 'published', label: 'Time Clock & Shifts', icon: <Clock size={18}/>, dot: hasMyShiftAlert }); 
  if (isEnabled('ops') && (isGod || appUser?.isAdmin || perms.ops)) tabs.push({ id: 'ops', label: 'Ops Command Center', icon: <ChefHat size={18}/> }); 
  if (isEnabled('messages')) tabs.push({ id: 'messages', label: 'Message Board', icon: <MessageSquare size={18}/>, dot: hasUnreadMessages });
  if (isEnabled('events') && (appUser?.isAdmin || perms.events || perms.schedule || perms.team)) tabs.push({ id: 'events', label: 'Event Calendar', icon: <Star size={18}/> });
  if (isEnabled('prep') && (appUser?.isAdmin || appUser?.role === 'Kitchen' || perms.prep)) tabs.push({ id: 'prep', label: 'Prep & Tasks', icon: <ClipboardList size={18}/> });
  if (isEnabled('recipes') && (appUser?.isAdmin || appUser?.role === 'Kitchen' || perms.prep || perms.team)) tabs.push({ id: 'recipes', label: 'Recipe Book', icon: <BookOpen size={18}/> });
  if (isEnabled('inventory') && (appUser?.isAdmin || perms.inventory || perms.team)) tabs.push({ id: 'inventory', label: 'Inventory & Orders', icon: <Package size={18}/> });  
  if (isEnabled('schedule') && (appUser?.isAdmin || perms.schedule)) tabs.push({ id: 'schedule', label: 'Schedule Builder', icon: <Calendar size={18}/>, dot: hasScheduleBuilderAlert });
  if (isEnabled('team') && (appUser?.isAdmin || perms.team)) tabs.push({ id: 'team', label: 'Staff Roster', icon: <Users size={18}/> });
  if (isEnabled('maintenance') && (appUser?.isAdmin || perms.team)) tabs.push({ id: 'maintenance', label: 'Maintenance Log', icon: <Wrench size={18}/> });
  if (isEnabled('sales') && (appUser?.isAdmin || perms.sales)) tabs.push({ id: 'sales', label: 'Daily Ledger', icon: <TrendingUp size={18}/> });
  
  const isTrueGod = (appUser?.email || '').toLowerCase() === MASTER_ADMIN_EMAIL.toLowerCase() || appUser?.isSuperAdmin === true;
  if (isTrueGod) tabs.push({ id: 'godmode', label: 'System Administrator', icon: <Globe size={18}/> });
  if (appUser?.isAdmin || isTrueGod) tabs.push({ id: 'audit', label: 'System Audit', icon: <Shield size={18}/> });  
  tabs.push({ id: 'settings', label: 'Settings', icon: <Settings size={18}/> });

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 z-[70] flex justify-end">
          <div className="absolute inset-0 bg-[#12161A]/60 backdrop-blur-sm" onClick={onClose}></div>
          <div className={`w-72 bg-[#1A2126] border-l ${T.border} h-full shadow-2xl flex flex-col relative animate-[slideIn_0.3s_ease-out]`}>
            <div className={`p-4 border-b ${T.border} bg-[#12161A] flex justify-between items-start`}>
               <div className="flex items-center gap-3">
                 <img src={getAvatar(appUser.name, appUser.photoURL)} alt="Profile" className={`w-10 h-10 rounded-full border ${T.border} object-cover`}/>
                 <div>
                   <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">Signed in as</div>
                   <div className="text-white font-black text-lg tracking-tight leading-none">{appUser.name}</div>
                   <div className={`flex items-center gap-1 ${T.copper} text-[10px] font-bold uppercase tracking-wider mt-1 bg-[#1A2126] border ${T.border} w-max px-2 py-0.5 rounded-md`}>{appUser.isAdmin && <Shield size={10} />} {appUser.role}</div>
                 </div>
               </div>
               <button onClick={onClose} className="p-1.5 bg-[#1A2126] border border-[#2A353D] rounded-full text-slate-400 hover:text-white transition-colors"><X size={18}/></button>
            </div>
            <div className="flex-1 overflow-y-auto p-3 space-y-1">
               {tabs.map(tab => (
                 <button key={tab.id} onClick={() => { setActiveTab(tab.id); onClose(); }} className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl font-bold text-sm transition-all duration-200 ${activeTab === tab.id ? `${T.grad} text-slate-900 shadow-md` : 'text-slate-400 hover:bg-[#12161A] hover:text-white'}`}>
                   <div className="flex items-center gap-3">
                     <div className="relative">
                       <span className={activeTab === tab.id ? 'text-slate-900' : T.copper}>{tab.icon}</span>
                       {tab.dot && <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full border border-[#1A2126] shadow-[0_0_8px_rgba(239,68,68,0.8)] animate-pulse"></span>}
                     </div>
                     {tab.label}
                   </div>
                 </button>
               ))}
            </div>
            <div className={`p-3 border-t ${T.border} bg-[#12161A] space-y-2`}>
             <button 
                onClick={() => { setIsBugModalOpen(true); onClose(); }} 
                className="w-full flex items-center justify-center gap-2 py-2.5 text-orange-400 text-sm font-bold rounded-xl hover:bg-orange-900/20 transition-colors border border-orange-900/30"
             >
                <Bug size={16} /> Report a Bug / Error
             </button>
             <button onClick={() => { localStorage.removeItem('86chaosUser'); setAppUser(null); onClose(); }} className="w-full flex items-center justify-center gap-2 py-2.5 text-red-400 text-sm font-bold rounded-xl hover:bg-red-900/20 transition-colors"><LogOut size={16} /> Log Out</button>
            </div>
          </div>
        </div>
      )}

      <Modal isOpen={isBugModalOpen} onClose={() => setIsBugModalOpen(false)} title="Report a Bug">
        <form onSubmit={handleBugSubmit} className="space-y-4">
          <p className="text-xs text-slate-300 font-bold">Describe the issue you're facing. This goes directly to the development team.</p>
          <textarea 
            value={bugText} 
            onChange={e => setBugText(e.target.value)} 
            className={T.input} 
            rows="4" 
            placeholder="What went wrong? What did you click before it happened?" 
            required 
          ></textarea>
          <button type="submit" disabled={isSubmittingBug} className={`w-full ${T.btn} disabled:opacity-50 flex items-center justify-center gap-2`}>
            {isSubmittingBug ? <Loader2 className="animate-spin" size={18} /> : <><Send size={18} /> Send Report</>}
          </button>
        </form>
      </Modal>
    </>
  );
};

// --- DEDICATED DAY DOT PRINT ENGINE ---
const DayDotPrintScreen = ({ labelsToPrint, prepDate, appUser, onClose }) => {
  useEffect(() => {
    const handleBackButton = () => onClose(); window.history.pushState({ tab: 'prep', printScreen: true }, ''); window.addEventListener('popstate', handleBackButton);
    const timer = setTimeout(() => window.print(), 800);
    return () => { clearTimeout(timer); window.removeEventListener('popstate', handleBackButton); };
  }, [onClose]);
  return (
    <div id="master-print-wrapper" className="fixed inset-0 z-[999999] bg-white overflow-y-auto text-black print:static print:block print:overflow-visible print:h-auto print:w-auto">
      <style>{`@media print { 
        @page { size: 3.5in 1.1in; margin: 0; } 
        body, html { margin: 0 !important; background: white !important; height: auto !important; } 
        #master-print-wrapper { position: static !important; overflow: visible !important; height: auto !important; display: block !important; }
        .no-print { display: none !important; } 
        .dk-label { width: 3.5in !important; height: 1.1in !important; display: flex !important; flex-direction: column !important; justify-content: center !important; padding: 0.05in 0.15in !important; box-sizing: border-box !important; page-break-after: always !important; margin: 0 !important; font-family: sans-serif !important; overflow: hidden !important; } 
        .dk-title { font-size: 16px !important; font-weight: 900 !important; text-transform: uppercase !important; text-align: center !important; margin-bottom: 2px !important; } 
        .dk-row { display: flex !important; justify-content: space-between !important; font-size: 11px !important; font-weight: bold !important; margin-bottom: 2px !important; } 
        .dk-exp { display: flex !important; justify-content: center !important; font-size: 14px !important; font-weight: 900 !important; border-top: 2px solid black !important; padding-top: 2px !important; } 
      }`}</style>
      <div className="no-print p-6 flex flex-col items-center justify-center min-h-screen bg-slate-100">
         <Loader2 className="animate-spin text-[#8F6040] mb-6" size={64} />
         <h2 className="text-3xl font-black text-slate-900 mb-2">Generating Labels</h2>
         <button onClick={() => window.history.back()} className="bg-slate-900 text-white px-10 py-5 rounded-xl font-black text-lg shadow-xl hover:bg-slate-800 w-full max-w-xs mt-8">Return to App</button>
      </div>
      <div id="print-data">
        {labelsToPrint.map((item, idx) => {
          const prepDateParts = formatDisplayDate(prepDate).split(','); const prepStr = prepDateParts.length > 1 ? prepDateParts[1].trim() : formatDisplayDate(prepDate);
          return (<div key={`print-${idx}`} className="dk-label"><div className="dk-title">{item.text}</div><div className="dk-row"><span>PREP: {prepStr}</span><span>EMP: {appUser?.name ? appUser.name.split(' ')[0].toUpperCase() : '___'}</span></div><div className="dk-exp">EXP: {getExpDate(prepDate)}</div></div>);
        })}
      </div>
    </div>
  );
};

// ============================================================================
// THE 86 CHAOS BOOT SCREEN (EMAIL/PASSWORD & FORCED RESET)
// ============================================================================
const LoginScreen = ({ setAppUser }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState(false);
  
  // New state to hold the user temporarily if they need to change their password
  const [pendingUser, setPendingUser] = useState(null);
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoginError('');
    
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const firebaseUser = userCredential.user;
      
      const userDocRef = doc(db, 'users', firebaseUser.uid);
      const userDocSnap = await getDoc(userDocRef);
      
      if (userDocSnap.exists()) {
        const userData = { id: firebaseUser.uid, ...userDocSnap.data() };
        
        // INTERCEPT: If the flag is true, hold them in the pending state
        if (userData.forcePasswordChange) {
          setPendingUser(userData);
        } else {
          localStorage.setItem('chaosRememberMe', rememberMe);
          setAppUser(userData); // Let them into the OS
        }
      } else {
        setLoginError('Login successful, but user profile is missing in the database.');
      }
    } catch (error) {
      setLoginError(error.message);
    }
  };

  const handleForcePasswordChange = async (e) => {
    e.preventDefault();
    setLoginError('');

    if (newPass !== confirmPass) return setLoginError('Passwords do not match.');
    if (newPass.length < 6) return setLoginError('Password must be at least 6 characters.');

    try {
      // 1. Update the secure Firebase Auth password
      await updatePassword(auth.currentUser, newPass);
      
      // 2. Flip the database flag so they are never asked again.
      // Passwords belong ONLY in Firebase Auth, never in Firestore.
      await updateDoc(doc(db, "users", pendingUser.id), { 
        forcePasswordChange: false,
        passwordPurgedAt: new Date().toISOString()
      });
      
      // 3. Unlock the system without caching the password in app state.
      localStorage.setItem('chaosRememberMe', rememberMe);
      const { password, ...safePendingUser } = pendingUser;
      setAppUser({ ...safePendingUser, forcePasswordChange: false });
      
    } catch (error) {
      setLoginError(error.message);
    }
  };

  const handleForgotCredentials = async () => {
    if (!email) {
      setLoginError("Please type your email address into the top box first, then click Forgot Password.");
      return;
    }
    try {
      await sendPasswordResetEmail(auth,
 email);
      setLoginError("Reset link sent! Check your email inbox.");
    } catch (error) {
      setLoginError(error.message);
    }
  };

  return (
    <div 
      className="min-h-screen flex flex-col items-center justify-center bg-[#0B0E11] bg-cover bg-center bg-no-repeat relative"
      style={{ backgroundImage: `url('/6136.jpg')` }}
    >
      <div className="absolute inset-0 bg-[#0B0E11]/75 backdrop-blur-[3px]"></div>
      
      <div className="relative z-10 w-full max-w-sm p-8 bg-[#161D22]/95 border border-[#2A353D] rounded-3xl shadow-2xl flex flex-col items-center animate-[slideIn_0.3s_ease-out]">
        
        <img src="/6139.png" alt="86 Chaos OS Logo" className="h-24 w-auto rounded-xl shadow-lg border border-[#2A353D] mb-8 object-contain bg-[#12161A] p-2" />
        
        {/* IF THEY NEED TO CHANGE PASSWORD, RENDER THIS FORM */}
        {pendingUser ? (
          <form onSubmit={handleForcePasswordChange} className="w-full space-y-4 animate-[slideIn_0.2s_ease-out]">
            <div className="text-center mb-4">
              <h2 className="text-xl font-black text-white leading-tight">Welcome, {pendingUser.name.split(' ')[0]}!</h2>
              <p className="text-xs text-[#D4A381] font-bold mt-1 uppercase tracking-widest">Please set a permanent password.</p>
            </div>
            
            {loginError && <div className="p-3 bg-red-900/50 border border-red-500/50 rounded-xl text-red-200 text-xs font-bold text-center">{loginError}</div>}

            <div>
              <input type="password" placeholder="New Password (min 6 chars)" value={newPass} onChange={e => setNewPass(e.target.value)} className="w-full text-center text-lg font-bold bg-[#0B0E11] border border-[#2A353D] rounded-xl py-4 text-white focus:outline-none focus:border-[#D4A381] transition-colors shadow-inner" required />
            </div>
            <div>
              <input type="password" placeholder="Confirm New Password" value={confirmPass} onChange={e => setConfirmPass(e.target.value)} className="w-full text-center text-lg font-bold bg-[#0B0E11] border border-[#2A353D] rounded-xl py-4 text-white focus:outline-none focus:border-[#D4A381] transition-colors shadow-inner" required />
            </div>
            
            <button type="submit" className="w-full bg-gradient-to-r from-[#D4A381] to-[#b58563] text-slate-900 font-black tracking-widest uppercase text-lg py-4 rounded-xl shadow-[0_0_20px_rgba(212,163,129,0.2)] hover:scale-[1.02] transition-all mt-2">
              Save & Enter OS
            </button>
          </form>
        ) : (
          /* OTHERWISE, RENDER THE STANDARD LOGIN FORM */
          <form onSubmit={handleLogin} className="w-full space-y-4">
            
            {loginError && <div className="p-3 bg-red-900/50 border border-red-500/50 rounded-xl text-red-200 text-xs font-bold text-center">{loginError}</div>}

            <div>
              <input type="text" placeholder="Email Address" value={email} onChange={e => setEmail(e.target.value)} className="w-full text-center text-lg font-bold bg-[#0B0E11] border border-[#2A353D] rounded-xl py-4 text-white focus:outline-none focus:border-[#D4A381] transition-colors shadow-inner" />
            </div>
     <div>
              <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} className="w-full text-center text-lg font-bold bg-[#0B0E11] border border-[#2A353D] rounded-xl py-4 text-white focus:outline-none focus:border-[#D4A381] transition-colors shadow-inner" />
            </div>

            <label className="flex items-center justify-center gap-2 cursor-pointer mt-2">
              <input type="checkbox" checked={rememberMe} onChange={(e) => setRememberMe(e.target.checked)} className="w-4 h-4 accent-[#D4A381] bg-[#0B0E11] border border-[#2A353D] rounded cursor-pointer" />
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-widest">Remember Me</span>
            </label>
            
            <button type="submit" className="w-full bg-gradient-to-r from-[#D4A381] to-[#b58563] text-slate-900 font-black tracking-widest uppercase text-lg py-4 rounded-xl shadow-[0_0_20px_rgba(212,163,129,0.2)] hover:scale-[1.02] transition-all mt-4">
              Unlock System
            </button>
<div className="pt-3 text-center flex flex-col gap-2">
              <button type="button" onClick={handleForgotCredentials} className="text-[10px] font-bold text-slate-500 uppercase tracking-widest hover:text-[#D4A381] transition-colors">
                Forgot Password or Username?
              </button>
              <button type="button" onClick={() => setIsPrivacyModalOpen(true)} className="text-[10px] font-bold text-slate-600 hover:text-slate-400 transition-colors mt-4">
                Privacy Policy & Terms of Service
              </button>
            </div>
          </form>
        )}
      </div>

      <Modal isOpen={isPrivacyModalOpen} onClose={() => setIsPrivacyModalOpen(false)} title="Privacy Policy">
        <div className="space-y-4 text-xs font-medium text-slate-300 leading-relaxed max-h-[60vh] overflow-y-auto custom-scrollbar pr-2">
          <div className="text-center border-b border-[#2A353D] pb-3 mb-3">
            <h3 className="font-black text-white text-lg uppercase tracking-widest">Privacy Policy for 86chaos</h3>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Last Updated: July 2, 2026</p>
          </div>
          <p>Chilton App Works, LLC ("we," "us," or "our") operates the 86chaos restaurant operating system (the "Service"). This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our mobile application and website.</p>
          
          <h4 className="font-black text-[#D4A381] text-sm mt-4">1. Information We Collect</h4>
          <p>We collect information that identifies, relates to, describes, or could reasonably be linked to you or your restaurant, including:</p>
          <ul className="list-disc pl-5 space-y-1 mt-1 text-slate-400">
            <li><strong className="text-white">Personal & Account Information:</strong> Names, email addresses, phone numbers, and profile photos.</li>
            <li><strong className="text-white">Employment & Financial Data:</strong> Job titles, hourly wages, time punches, shift schedules, tips declared, and custom permissions.</li>
            <li><strong className="text-white">Location Data (GPS):</strong> We collect precise location data exclusively when you attempt to clock in or out. This data is used solely to verify your presence within your employer's designated GPS geofence boundary. We do not track your location in the background.</li>
            <li><strong className="text-white">Device & Telemetry Data:</strong> To improve system stability, we collect device information (Operating System, screen size, user agent), IP addresses (for security whitelisting), and usage telemetry (such as recent buttons clicked) attached to crash reports.</li>
            <li><strong className="text-white">Images & Camera Data:</strong> We access your device camera and photo library, with your explicit permission, for scanning vendor invoices and attaching photos to the Message Board or Events ledger.</li>
          </ul>

          <h4 className="font-black text-[#D4A381] text-sm mt-4">2. How We Use Your Information</h4>
          <p>We use the collected information to:</p>
          <ul className="list-disc pl-5 space-y-1 mt-1 text-slate-400">
            <li>Facilitate core operational features, including time tracking, scheduling, and inventory management.</li>
            <li>Process vendor invoices through our AI integration to extract line items and update stock. (Note: AI processing is used strictly for document parsing, not for biometric or facial recognition).</li>
            <li>Send push notifications regarding shift changes, trade board requests, and critical manager alerts.</li>
            <li>Monitor system health, troubleshoot crashes, and prevent fraudulent activity.</li>
          </ul>

          <h4 className="font-black text-[#D4A381] text-sm mt-4">3. Third-Party Data Sharing</h4>
          <p>We do not sell your personal data. We share data only with essential third-party service providers who assist in operating the Service:</p>
          <ul className="list-disc pl-5 space-y-1 mt-1 text-slate-400">
            <li><strong className="text-white">Cloud Hosting & Database:</strong> Google Cloud/Firebase (for secure data storage and authentication).</li>
            <li><strong className="text-white">Serverless Infrastructure:</strong> Vercel (for routing and processing data).</li>
            <li><strong className="text-white">AI Processing:</strong> Third-party AI APIs are used specifically to parse and read uploaded invoice images.</li>
            <li><strong className="text-white">External Integrations:</strong> If your employer connects 86chaos to third-party Point of Sale (POS) or Payroll providers, data is transmitted to those entities according to your employer's configuration.</li>
          </ul>

          <h4 className="font-black text-[#D4A381] text-sm mt-4">4. Employer Control (B2B Clause)</h4>
          <p>86chaos is a B2B service provided to your employer. Your employer acts as the primary Data Controller. If you are an employee seeking to access, modify, or permanently delete your personal data (such as time punches or account records), you must direct those requests to your restaurant management team.</p>

          <h4 className="font-black text-[#D4A381] text-sm mt-4">5. Data Security & Retention</h4>
          <p>We use industry-standard security measures, including encryption and secure server environments, to protect your data. Data is retained for as long as your employer maintains an active workspace. If an employer deletes a user or a workspace, the associated data is permanently purged from our active databases.</p>

          <h4 className="font-black text-[#D4A381] text-sm mt-4">6. Contact Us</h4>
          <p>If you have questions about this Privacy Policy, please contact us at:</p>
          <p className="text-white font-bold mt-1">Email: support@86chaos.com<br/>Company: Chilton App Works, LLC</p>
        </div>
      </Modal>
    </div>
  );
};


// ============================================================================
// SECTION 3: MASTER SCHEDULE HUB (Combined Schedule, TimeClock, Month, Requests)
// ============================================================================
const TabMasterSchedule = ({ currentDate, appUser, users, shifts, shiftSwaps, timeOffRequests, events, addToast }) => {
  const [rosterFilterDate, setRosterFilterDate] = useState('');
  const monthStr = getMonthStr(currentDate);
  
  // --- TIME CLOCK LOGIC ---
  const [activePunch, setActivePunch] = useState(null);
  const [isTipModalOpen, setIsTipModalOpen] = useState(false);
  const [tipCash, setTipCash] = useState('');
  const [tipCredit, setTipCredit] = useState('');
  const [subTab, setSubTab] = useState('my-schedule');

  useEffect(() => {
    if (!appUser?.id) return;
    const q = query(
      collection(db, 'timePunches'), 
      where('employeeId', '==', appUser.id), 
      where('status', 'in', ['clocked_in', 'on_break'])
    );
    const unsub = onSnapshot(q, snap => {
      if (!snap.empty) { setActivePunch({ id: snap.docs[0].id, ...snap.docs[0].data() }); } 
      else { setActivePunch(null); }
    });
    return () => unsub();
  }, [appUser?.id]);



// --- GEOFENCE MATH ENGINE ---
  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371e3; // Earth's radius in meters
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return (R * c) * 3.28084; // Convert final result to feet
  };

const handleClockIn = async () => {
    // Check if scheduled today
    const isScheduledToday = shifts.some(s => s.employeeId === appUser.id && s.date === getToday() && s.isPublished);
    
    let isUnscheduled = false;
    if (!isScheduledToday) {
       const confirmUnscheduled = window.confirm("You are not scheduled for a shift today. Do you want to proceed with an unscheduled clock-in?");
       if (!confirmUnscheduled) return;
       isUnscheduled = true;
    }

    const executePunch = async () => {
      try {
        await addDoc(collection(db, "timePunches"), { 
          employeeId: appUser.id, employeeName: appUser.name, clockInTime: new Date().toISOString(), 
          status: 'clocked_in', restaurantId: appUser.restaurantId, date: getToday(), breakMinutes: 0,
          isUnscheduled: isUnscheduled, isApproved: !isUnscheduled
        });
        
        // Blast the manager alert to the Message Board
        if (isUnscheduled) {
           await addDoc(collection(db, "events"), { 
             date: new Date().toISOString(), title: `UNSCHEDULED PUNCH: ${appUser.name.split(' ')[0]} clocked in without a scheduled shift. Please review in Timesheets.`, 
             type: 'note', author: 'System Alert', isImportant: true, restaurantId: appUser.restaurantId, replies: [] 
           });
        }
        
        addToast('Clocked In', isUnscheduled ? 'Unscheduled shift started. Manager notified.' : 'Shift started successfully.');
      } catch (e) { addToast('Error', e.message); }
    };

    if (appUser?.systemSettings?.geofence) {
      if (!navigator.geolocation) return addToast('Error', 'Your device does not support location tracking.');
      
      const targetLat = parseFloat(appUser.systemSettings.lat);
      const targetLon = parseFloat(appUser.systemSettings.lon);
      const allowedRadius = parseInt(appUser.systemSettings.geofenceRadius) || 300; // Default to 300 feet
      
      if (!targetLat || !targetLon) return addToast('Geofence Error', 'Location coordinates are not set in Workspace settings yet.');
      
      addToast('Locating...', 'Verifying GPS coordinates. Hold still.');
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const dist = calculateDistance(targetLat, targetLon, pos.coords.latitude, pos.coords.longitude);
          if (dist <= allowedRadius) executePunch();
          else addToast('Access Denied', `Too far away. Move closer to the restaurant. (${Math.round(dist)} feet away)`);
        },
        (err) => addToast('Location Error', err.code === 1 ? 'Location access denied. Please allow location access in your browser to clock in.' : 'Could not lock GPS. Step outside the walk-in and try again.'),
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    } else {
      executePunch();
    }
  };

  const handleStartBreak = async () => {
    await updateDoc(doc(db, "timePunches", activePunch.id), { breakStartTime: new Date().toISOString(), status: 'on_break' });
    addToast('Break Started', 'Enjoy your break.');
  };

  const handleEndBreak = async () => {
    const breakStart = new Date(activePunch.breakStartTime);
    const now = new Date();
    const mins = (now - breakStart) / 60000;
    const currentBreaks = activePunch.breakMinutes || 0;
    await updateDoc(doc(db, "timePunches", activePunch.id), { breakStartTime: null, breakMinutes: currentBreaks + mins, status: 'clocked_in' });
    addToast('Break Ended', 'Welcome back to work.');
  };

  const initiateClockOut = () => {
    if (appUser?.systemSettings?.tips) { setIsTipModalOpen(true); } 
    else { finalizeClockOut(); }
  };

  const finalizeClockOut = async (e) => {
    if(e) e.preventDefault();
    if (!activePunch) return;
    try {
      let finalBreakMins = activePunch.breakMinutes || 0;
      if (activePunch.status === 'on_break') {
         const breakStart = new Date(activePunch.breakStartTime);
         finalBreakMins += (new Date() - breakStart) / 60000;
      }
      
      await updateDoc(doc(db, "timePunches", activePunch.id), { 
        clockOutTime: new Date().toISOString(), 
        status: 'clocked_out',
        cashTips: parseFloat(tipCash) || 0,
        creditTips: parseFloat(tipCredit) || 0,
        breakMinutes: finalBreakMins,
        breakStartTime: null
      });
      
      setIsTipModalOpen(false);
      setTipCash(''); setTipCredit('');
      addToast('Clocked Out', 'Shift ended. Great work today!');
    } catch (err) { addToast('Error', err.message); }
  };

// --- SHIFT LOGIC ---
  const myMonthShifts = shifts
    .filter(s => s.employeeId === appUser.id && s.date.startsWith(monthStr) && s.isPublished)
    .sort((a,b) => a.date === b.date ? (a.startTime || '').localeCompare(b.startTime || '') : a.date.localeCompare(b.date));

  const myNextShift = shifts
    .filter(s => s.employeeId === appUser.id && s.date >= getToday() && s.isPublished)
    .sort((a,b) => a.date === b.date ? (a.startTime || '').localeCompare(b.startTime || '') : a.date.localeCompare(b.date))[0];

  const activeMonthShifts = shifts
    .filter(s => s.date.startsWith(monthStr) && s.isPublished)
    .sort((a,b) => a.date === b.date ? (a.startTime || '').localeCompare(b.startTime || '') : a.date.localeCompare(b.date));

  // --- TRADE BOARD LOGIC ---
  const availableSwaps = shiftSwaps
    .filter(s => s.status === 'available' && s.date >= getToday())
    .sort((a,b) => a.date.localeCompare(b.date));

  const handleCancelSwap = async (swapId) => {
    if (!window.confirm("Remove this shift from the Trade Board?")) return;
    await deleteDoc(doc(db, "shiftSwaps", swapId));
    addToast('Revoked', 'Shift removed from Trade Board.');
  };

  const handleClaimShift = async (swap) => {
    if (!swap?.shiftId) return addToast('Error', 'This trade-board listing is missing its linked shift ID.');
    if (!window.confirm(`Claim this ${swap.role} shift on ${formatDisplayDate(swap.date)}?`)) return;

    try {
      await updateDoc(doc(db, "shifts", swap.shiftId), {
        employeeId: appUser.id,
        role: swap.role,
        updatedAt: new Date().toISOString(),
        claimedFromTradeBoard: true
      });

      await updateDoc(doc(db, "shiftSwaps", swap.id), {
        status: 'claimed',
        claimedBy: appUser.id,
        claimedByName: appUser.name,
        claimedAt: new Date().toISOString()
      });

      addToast('Shift Claimed', 'The shift has been added to your schedule.');
      setSubTab('my-schedule');
    } catch (e) {
      addToast('Error', e.message || 'Could not claim shift.');
    }
  };

const handleOfferSwap = async (shift) => {
    if (!window.confirm(`Offer your ${shift.role} shift on ${formatDisplayDate(shift.date)} to the Trade Board?`)) return;
    
    try {
      // 1. Add the swap to the database
      await addDoc(collection(db, "shiftSwaps"), {
        shiftId: shift.id,
        originalEmployeeId: appUser.id,
        role: shift.role,
        date: shift.date,
        startTime: shift.startTime,
        endTime: shift.endTime,
        status: 'available',
        restaurantId: appUser.restaurantId,
        listedAt: new Date().toISOString()
      });
      
      addToast('Listed', 'Shift is now on the Trade Board.');
      setSubTab('trade-board');

      // 2. Trigger the Universal Push Cannon
      try {
        await secureFetch('/api/send-push', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            restaurantId: appUser.restaurantId,
            type: 'trade', // This tells the cannon to respect the notifTrades toggle
            title: '🔄 Shift up for grabs!',
            body: `${appUser.name.split(' ')[0]} just posted a ${shift.role} shift on ${formatDisplayDate(shift.date)}.`,
            textContent: '', // Not a message, so no keyword scanning needed
            isCritical: false
          })
        });
      } catch (err) {
        console.error("Failed to trigger push:", err);
      }

    } catch (e) {
      addToast('Error', e.message);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-4 pb-24">
      
      <Modal isOpen={isTipModalOpen} onClose={() => setIsTipModalOpen(false)} title="Declare Tips">
        <form onSubmit={finalizeClockOut} className="space-y-4">
          <p className="text-xs text-slate-300 font-bold mb-2">Please declare your tips for this shift before clocking out.</p>
          <div>
            <label className={T.label}>Cash Tips ($)</label>
            <input type="number" step="0.01" min="0" value={tipCash} onChange={e=>setTipCash(e.target.value)} className={T.input} placeholder="0.00"/>
          </div>
          <div>
            <label className={T.label}>Credit Card Tips ($)</label>
            <input type="number" step="0.01" min="0" value={tipCredit} onChange={e=>setTipCredit(e.target.value)} className={T.input} placeholder="0.00"/>
          </div>
          <button type="submit" className={`w-full ${T.btn}`}>Finalize Clock Out</button>
        </form>
      </Modal>

      <div className="grid grid-cols-2 sm:flex sm:flex-wrap gap-2 border-b border-[#2A353D] mb-4 pb-2">
        {['my-schedule', 'full-schedule', 'month-view', 'time-off'].map((tab) => (
          <button key={tab} onClick={() => setSubTab(tab)} className={`px-2 sm:px-4 py-2 text-[10px] sm:text-xs font-black rounded-xl uppercase tracking-widest transition-all sm:flex-1 ${subTab === tab ? `${T.grad} text-slate-900 shadow-md` : 'bg-[#1A2126] text-slate-400 hover:text-white'}`}>
            {tab.replace('-', ' ')}
          </button>
        ))}
      </div>

      {subTab === 'my-schedule' && (
        <div className="space-y-4 animate-[slideIn_0.2s_ease-out]">
          {events.filter(e => e.type === 'note' && e.isImportant).slice(0,1).map(alert => (
            <div key={alert.id} className="bg-gradient-to-r from-[#7A4F31]/30 to-[#1A2126] border border-[#B88764]/40 p-3 rounded-xl flex gap-3 shadow-lg">
              <Bell size={24} className="text-red-500 flex-shrink-0" />
              <div>
                <span className="text-[9px] font-black uppercase text-[#D4A381] tracking-widest block">System Alert</span>
                <p className="text-xs text-slate-200 font-medium leading-snug">{alert.title}</p>
              </div>
            </div>
          ))}
          <div className={`${T.grad} rounded-3xl p-6 shadow-2xl relative overflow-hidden border border-[#D4A381]/30`}>
            <div className="absolute -top-4 -right-4 text-8xl font-black text-slate-900/10">86</div>
            <h3 className="text-sm font-black uppercase tracking-widest text-slate-900/60 mb-1">My Schedule</h3>
            {myNextShift ? (
              <div className="mb-6"><div className="text-2xl font-black text-slate-900 tracking-tight leading-none mb-1">Next: {myNextShift.role}</div><div className="text-sm font-bold text-slate-900/80 flex items-center gap-1.5">{formatDisplayDate(myNextShift.date)}   {formatShortTime(myNextShift.startTime)} - {formatShortTime(myNextShift.endTime)} {myNextShift.endTime === 'CLOSE' && <span className="bg-slate-900 text-[#D4A381] text-[9px] px-1.5 py-0.5 rounded ml-1 uppercase tracking-wider">Close</span>}</div></div>
            ) : (<div className="mb-6 text-slate-900 font-bold">No upcoming shifts scheduled.</div>)}
            
            {activePunch ? (
              <div className="space-y-2 relative z-10">
                <button onClick={initiateClockOut} className="w-full py-4 bg-red-900/80 text-red-100 rounded-xl font-black text-sm uppercase tracking-widest shadow-[0_0_15px_rgba(220,38,38,0.4)] hover:bg-red-800 border border-red-500/50 transition-all flex flex-col items-center justify-center gap-1">
                  <span>CLOCK OUT</span>
                  <span className="text-[10px] text-red-300 font-medium normal-case tracking-normal">Clocked in at {new Date(activePunch.clockInTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                </button>
                {appUser?.systemSettings?.breaks && (
                  activePunch.status === 'on_break' ? (
                    <button onClick={handleEndBreak} className="w-full py-3 bg-blue-900/80 text-blue-100 rounded-xl font-black text-sm uppercase tracking-widest hover:bg-blue-800 border border-blue-500/50 transition-all">END BREAK</button>
                  ) : (
                    <button onClick={handleStartBreak} className="w-full py-3 bg-slate-800/50 text-slate-900 rounded-xl font-black text-sm uppercase tracking-widest hover:bg-slate-800 hover:text-white border border-slate-700 transition-all">START UNPAID BREAK</button>
                  )
                )}
              </div>
            ) : (
              <button onClick={handleClockIn} className="w-full py-4 bg-emerald-600/20 text-emerald-400 rounded-xl font-black text-sm uppercase tracking-widest shadow-[0_0_15px_rgba(16,185,129,0.1)] hover:bg-emerald-600/30 border border-emerald-500/50 transition-all relative z-10">
                CLOCK IN
              </button>
            )}

          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <button onClick={() => setSubTab('trade-board')} className={`${T.card} p-4 flex flex-col items-center justify-center gap-2 hover:bg-[#2A353D] transition-colors relative`}>
              <Repeat size={24} className={T.copper}/>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-300">Trade Board</span>
              {availableSwaps.length > 0 && <span className="absolute top-2 right-2 bg-red-500 text-white text-[9px] font-black w-5 h-5 rounded-full flex items-center justify-center shadow-lg">{availableSwaps.length}</span>}
            </button>
            <button onClick={() => setSubTab('time-off')} className={`${T.card} p-4 flex flex-col items-center justify-center gap-2 hover:bg-[#2A353D] transition-colors`}>
              <Calendar size={24} className={T.copper}/>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-300">Request Off</span>
            </button>
          </div>

          <div className={`${T.card} overflow-hidden mt-4`}>
            <div className={T.th}>My Month Shifts</div>
            <div className={`divide-y ${T.border}`}>
              {myMonthShifts.length === 0 ? (
                <div className={`p-4 text-center text-xs font-bold ${T.muted}`}>No shifts scheduled for you this month.</div>
              ) : (
                myMonthShifts.map(s => {
                  const isFuture = s.date >= getToday();
                  const isOffered = shiftSwaps.some(swap => swap.shiftId === s.id && swap.status === 'available');

                  return (
                    <div key={s.id} className={`${T.row} flex justify-between items-center`}>
                      <div>
                        <div className="font-bold text-white text-sm">{formatDisplayDate(s.date)}</div>
                        <div className={`text-[9px] font-black uppercase tracking-widest ${T.copper} mt-0.5`}>{s.role}</div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className={`text-xs font-mono font-bold bg-[#12161A] ${T.copper} px-2 py-1 rounded-md border ${T.border}`}>
                          {formatShortTime(s.startTime)} - {formatShortTime(s.endTime)}
                        </div>
                        {isFuture && (
                          isOffered ? (
                            <span className="text-[8px] font-black uppercase tracking-widest text-orange-400 bg-orange-900/20 border border-orange-900/50 px-2 py-1 rounded">Listed</span>
                          ) : (
                            <button onClick={() => handleOfferSwap(s)} className="text-[8px] font-black uppercase tracking-widest bg-[#1A2126] text-slate-300 border border-[#2A353D] hover:text-[#D4A381] hover:border-[#D4A381]/50 px-2 py-1 rounded transition-colors shadow-sm">
                              Swap
                            </button>
                          )
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* THE TRADE BOARD */}
      {subTab === 'trade-board' && (
        <div className="animate-[slideIn_0.2s_ease-out]">
          <div className={`${T.card} overflow-hidden`}>
            <div className={`bg-[#12161A] p-4 border-b ${T.border} flex justify-between items-center`}>
              <h3 className={`font-black text-lg flex items-center gap-2 ${T.copper}`}><Repeat size={18} /> Trade Board</h3>
              <button onClick={() => setSubTab('my-schedule')} className="text-xs font-bold text-slate-400 hover:text-white border border-[#2A353D] px-3 py-1.5 rounded-lg">Back to Dashboard</button>
            </div>
            
            <div className={`divide-y ${T.border}`}>
              {availableSwaps.length === 0 ? (
                <div className={`p-8 text-center text-sm font-bold ${T.muted}`}>No shifts currently available.</div>
              ) : (
                availableSwaps.map(swap => {
                  const isMine = swap.originalEmployeeId === appUser.id;
                  const originalEmp = users.find(u => u.id === swap.originalEmployeeId);
                  
                  return (
                    <div key={swap.id} className={`${T.row} p-4 flex flex-col sm:flex-row justify-between sm:items-center gap-4`}>
                      <div>
                        <div className="font-bold text-white text-base">{formatDisplayDate(swap.date)}</div>
                        <div className="text-[10px] font-black uppercase tracking-widest text-[#D4A381] mt-0.5">
                          {swap.role}   {formatShortTime(swap.startTime)} - {formatShortTime(swap.endTime)}
                        </div>
                        <div className="text-xs text-slate-400 font-medium mt-1">Listed by {originalEmp?.name || 'Unknown Staff'}</div>
                      </div>
                      <div className="flex-shrink-0">
                        {isMine ? (
                          <button onClick={() => handleCancelSwap(swap.id)} className="w-full sm:w-auto px-4 py-2 bg-red-900/20 text-red-500 text-xs font-black uppercase tracking-widest rounded-lg border border-red-900/50 hover:bg-red-900/40 transition-colors">Revoke Listing</button>
                        ) : (
                          <button onClick={() => handleClaimShift(swap)} className="w-full sm:w-auto px-4 py-2 bg-emerald-900/20 text-emerald-400 text-xs font-black uppercase tracking-widest rounded-lg border border-emerald-900/50 hover:bg-emerald-900/40 transition-colors shadow-[0_0_10px_rgba(16,185,129,0.1)]">Claim Shift</button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

{subTab === 'full-schedule' && (() => {
        const filteredRosterShifts = activeMonthShifts.filter(s => rosterFilterDate ? s.date === rosterFilterDate : true);
        return (
          <div className={`${T.card} overflow-hidden animate-[slideIn_0.2s_ease-out]`}>
            <div className="bg-[#12161A] p-3 border-b border-[#2A353D] flex flex-col sm:flex-row justify-between sm:items-center gap-3">
              <div className="flex items-center gap-2">
                 <h3 className={`text-xs font-black uppercase tracking-widest ${T.copper}`}>Active Roster</h3>
                 <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider hidden sm:inline">({formatDisplayMonth(currentDate)})</span>
              </div>
              <div className="flex items-center gap-2">
                 <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Filter Day:</span>
                 <input type="date" value={rosterFilterDate} onChange={(e) => setRosterFilterDate(e.target.value)} className={`${T.input} py-1 px-2 text-xs w-auto min-w-[130px]`} />
                 {rosterFilterDate && <button onClick={() => setRosterFilterDate('')} className="text-slate-400 hover:text-red-400 p-1"><X size={14}/></button>}
              </div>
            </div>
            <div className="divide-y divide-[#2A353D] max-h-[60vh] overflow-y-auto custom-scrollbar">
              {filteredRosterShifts.map((shift, index) => {
                 const emp = users.find(u => u.id === shift.employeeId);
                 const showDivider = index === 0 || shift.date !== filteredRosterShifts[index - 1].date;
                 
                 return (
                   <React.Fragment key={shift.id}>
                     {showDivider && (
                       <div className="bg-[#1A2126] px-3 py-2 border-y border-[#2A353D] text-[10px] font-black uppercase tracking-widest text-[#D4A381] sticky top-0 z-10 shadow-sm flex flex-wrap items-center gap-2">
                         <span>{formatDisplayDate(shift.date)}</span>
                         {getHoliday(shift.date) && <span className="bg-amber-900/40 text-amber-400 px-1.5 py-0.5 rounded border border-amber-500/30">{getHoliday(shift.date)}</span>}
                       </div>
                     )}
                     <div className={`${T.row} hover:bg-[#12161A]`}>
                       <div className="flex items-center justify-between">
                         <div className="flex items-center gap-3"><img src={getAvatar(emp?.name, emp?.photoURL)} className={`w-8 h-8 rounded-full border ${T.border} object-cover`} alt="avatar"/><div><div className="text-sm font-bold text-white">{emp?.name ? emp.name.split(' ')[0] : 'Unknown'}</div><div className={`text-[9px] ${T.muted} font-bold uppercase`}>{shift.role}</div></div></div>
                         <div className={`text-xs font-mono font-bold bg-[#12161A] ${T.copper} px-2 py-1 rounded-md border ${T.border}`}>{formatShortTime(shift.startTime)} - {formatShortTime(shift.endTime)}</div>
                       </div>
                     </div>
                   </React.Fragment>
                 )
              })}
              {filteredRosterShifts.length === 0 && <div className={`p-6 text-center text-xs font-bold ${T.muted}`}>No shifts found for this selection.</div>}
            </div>
          </div>
        );
      })()}

      {subTab === 'month-view' && <div className="animate-[slideIn_0.2s_ease-out]"><TabMonth currentDate={currentDate} users={users} shifts={shifts} appUser={appUser} /></div>}
      {subTab === 'time-off' && <div className="animate-[slideIn_0.2s_ease-out]"><TabTimeOff timeOffRequests={timeOffRequests} appUser={appUser} users={users} addToast={addToast} events={events} /></div>}  
    </div>
  );
};

// --- TEAM MANAGEMENT ---
const TabTeam = ({ users, appUser, addToast }) => {
  const canManageTeam = appUser.isAdmin || appUser.permissions?.team;
  const [name, setName] = useState(''); 
  const [email, setEmail] = useState(''); 
  const [phone, setPhone] = useState(''); 
  const [role, setRole] = useState('Bartender'); 
  const [wage, setWage] = useState(''); 
  const [photoURL, setPhotoURL] = useState(''); 
  const [isAdmin, setIsAdmin] = useState(false);
  const DEFAULT_PERMISSIONS = { schedule: false, events: false, ops: false, inventory: false, prep: false, sales: false, team: false };
  const [perms, setPerms] = useState(DEFAULT_PERMISSIONS);
  const [editingUserId, setEditingUserId] = useState(null);

  const dbRoles = useLiveCollection('roles', appUser?.restaurantId);
  const DEFAULT_ROLES = ['General Manager', 'Manager', 'Chef', 'Sous Chef', 'Line Cook', 'Prep Cook', 'Bartender', 'Server', 'Host', 'Dishwasher'];
  const roles = dbRoles.length > 0 ? dbRoles.map(r => r.name).sort() : DEFAULT_ROLES;
  
  const generateTempPass = () => Math.random().toString(36).slice(-6);

  const resetForm = () => {
    setName(''); setEmail(''); setPhone(''); setWage(''); setPhotoURL(''); setRole('Bartender'); setIsAdmin(false); setPerms(DEFAULT_PERMISSIONS); setEditingUserId(null);
  };

  const handleEditClick = (u) => {
    setName(u.name); setEmail(u.email); setPhone(u.phone || ''); setWage(u.wage || ''); setPhotoURL(u.photoURL || ''); setRole(u.role || 'Bartender'); setIsAdmin(u.isAdmin || false); setPerms({ ...DEFAULT_PERMISSIONS, ...(u.permissions || {}) }); setEditingUserId(u.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSave = async (e) => { 
    e.preventDefault(); if (!name.trim() || !email.trim() || !phone.trim()) return; 
    
    if (editingUserId) {
        try {
            await updateDoc(doc(db, "users", editingUserId), {
                name: name.trim(), phone: phone.trim(), role, wage: parseFloat(wage) || 0, isAdmin, permissions: perms, photoURL: photoURL.trim()
            });
            addToast('Updated', `${name}'s profile has been updated.`);
            resetForm();
        } catch(err) { addToast('Error', err.message); }
        return;
    }

    const tPass = generateTempPass(); 
    try { 
      const secondaryApp = initializeApp(firebaseConfig, "TeamBuilderApp_" + Date.now());
      const secondaryAuth = getAuth(secondaryApp);
      const userCredential = await createUserWithEmailAndPassword(secondaryAuth, email.toLowerCase().trim(), tPass);
      const newAuthUid = userCredential.user.uid;
      
      await secondaryAuth.signOut();

      await setDoc(doc(db, "users", newAuthUid), { 
        name: name.trim(), email: email.toLowerCase().trim(), phone: phone.trim(), 
        role, wage: parseFloat(wage) || 0, isAdmin, permissions: perms, isActive: true, 
        forcePasswordChange: true, photoURL: photoURL.trim(), restaurantId: appUser.restaurantId,
        passwordStored: false, passwordPurgedAt: new Date().toISOString()
      }); 
      
      const welcomeMsg = `Welcome to 86chaos!\n\nAccess the 86 Chaos OS here: https://app.86chaos.com\n\nUsername: ${email.toLowerCase().trim()}\nTemporary Password: ${tPass}\n\nPlease log in and update your password.`;
      
      const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
      if (isMobile && phone.trim()) {
        const smsChar = /iPad|iPhone|iPod/.test(navigator.userAgent) ? '&' : '?';
        window.location.href = `sms:${phone.trim()}${smsChar}body=${encodeURIComponent(welcomeMsg)}`;
      } else {
        window.location.href = `mailto:${email.toLowerCase().trim()}?subject=${encodeURIComponent("Your 86 Chaos Account")}&body=${encodeURIComponent(welcomeMsg)}`;
      }

      addToast('Staff Added', `Account created successfully.`); 
      resetForm();
    } catch (err) { 
      console.error(err); 
      addToast('Error', err.message || 'Failed to create user account.');
    } 
  };

const handleDeactivate = async (u) => { 
    if (!window.confirm(`Terminate ${u.name}? This will permanently delete their global account from the entire system.`)) return; 
    
    addToast('Terminating', `Erasing ${u.name} from the system...`);
    try {
      // 1. Nuke the Authentication Login via Vercel
      await secureFetch('/api/delete-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetUid: u.id })
      });
      
      // 2. Nuke the Database Profile
      await deleteDoc(doc(db, "users", u.id)); 
      addToast('Terminated', `${u.name}'s account has been completely erased.`); 
    } catch (err) {
      addToast('Error', 'Could not delete authentication credential. See logs.');
    }
  };

  const handlePasswordReset = async (u) => {
    if (!window.confirm(`Send a password reset email to ${u.email}?`)) return;
    try {
      await sendPasswordResetEmail(auth, u.email);
      addToast('Sent', `Reset email sent to ${u.email}`);
    } catch(err) { addToast('Error', err.message); }
  };

  const activeUsers = users.filter(u => u.isActive !== false).sort((a, b) => a.role === b.role ? a.name.localeCompare(b.name) : (a.role==='Bartender'?-1:1));

return (
    <div className="max-w-4xl mx-auto space-y-6 pb-24">
      
      {canManageTeam && (
        <form onSubmit={handleSave} className={`${T.card} p-4 sm:p-6 space-y-2`}>
          {editingUserId && (
            <div className="bg-blue-900/40 border border-blue-500/50 p-3 rounded-xl flex justify-between items-center">
              <span className="text-blue-400 font-bold text-xs uppercase tracking-widest">Editing Staff Member</span>
              <button type="button" onClick={resetForm} className="text-white text-xs font-bold hover:text-blue-300">Cancel Edit ?</button>
            </div>
          )}
          
          <div><label className={T.label}>Name</label><input type="text" value={name} onChange={e=>setName(e.target.value)} className={T.input} required placeholder="e.g. Gordon Ramsay" /></div>
          
          <div>
            <label className={T.label}>Email {editingUserId && <span className="text-slate-500 lowercase normal-case ml-1">(Cannot be changed after creation)</span>}</label>
            <input type="email" value={email} onChange={e=>setEmail(e.target.value)} disabled={!!editingUserId} className={`${T.input} ${editingUserId ? 'opacity-50 cursor-not-allowed' : ''}`} required />
          </div>

          
          <div><label className={T.label}>Phone</label><input type="tel" value={phone} onChange={e=>setPhone(e.target.value)} className={T.input} required /></div>
          
          <div><label className={T.label}>Role</label><select value={role} onChange={e=>setRole(e.target.value)} className={T.input}>{roles.map(r => <option key={r} value={r}>{r}</option>)}</select></div>
          
          {/* STRICTLY LOCKED TO ADMINS */}
          {appUser?.isAdmin && (
            <div>
              <label className={T.label}>Hourly Wage ($)</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 font-bold">$</span>
                <input type="number" step="0.01" min="0" value={wage} onChange={e=>setWage(e.target.value)} className={`${T.input} pl-8`} placeholder="Ex: 15.50" />
              </div>
            </div>
          )}

  {appUser?.isAdmin && (
            <label className="flex items-center gap-3 p-4 bg-[#12161A] rounded-xl border border-[#2A353D] cursor-pointer">
              <input type="checkbox" checked={isAdmin} onChange={e=>setIsAdmin(e.target.checked)} className="w-5 h-5 accent-red-500 bg-[#1A2126] border-[#2A353D] rounded" />
              <span className="text-sm font-black text-red-500">Store Manager (Full Admin)</span>
            </label>
          )}
          
          {!isAdmin && (
            <div className="p-4 bg-[#12161A] rounded-xl border border-[#2A353D]">
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-3">Custom Permissions: Ops Command Center is only visible when Ops permission or Store Manager is enabled.</p>
              <div className="flex flex-wrap gap-4">
                {Object.keys(perms).map(k => (
                  <label key={k} className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-300 uppercase">
                    <input type="checkbox" checked={perms[k]} onChange={e=>setPerms({...perms, [k]: e.target.checked})} className="w-4 h-4 accent-[#8F6040] bg-[#1A2126] border-[#2A353D] rounded" /> 
                    {{ schedule: 'Schedule Builder', events: 'Event Calendar', ops: 'Ops Command Center', inventory: 'Inventory', prep: 'Prep / Recipes', sales: 'Daily Ledger', team: 'Team Management' }[k] || k}
                  </label>
                ))}
              </div>
            </div>
          )}
          
          <button type="submit" className={`w-full ${T.btn}`}>{editingUserId ? 'UPDATE STAFF PROFILE' : 'ADD STAFF'}</button>
        </form>
      )}
      
      <div className={`${T.card} overflow-hidden`}>
        <div className="divide-y divide-[#2A353D]">
          {activeUsers.length === 0 && <div className={`p-6 text-center text-sm font-bold ${T.muted}`}>No active staff found.</div>}
          
          {activeUsers.map(u => (
            <div key={u.id} className="p-2.5 border-b border-[#2A353D] hover:bg-[#12161A] transition-colors flex items-center justify-between gap-2">
              <div className="flex items-center gap-3 overflow-hidden">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-white text-xs flex-shrink-0 ${u.isAdmin ? 'bg-red-900/50 border border-red-500/50' : 'bg-[#1A2126] border border-[#2A353D]'}`}>
                  {u.name.charAt(0)}
                </div>
                <div className="min-w-0">
                  <h4 className="font-bold text-white text-sm leading-tight truncate">{u.name} {u.isAdmin && <span className="ml-1 text-[7px] uppercase tracking-widest bg-red-500 text-white px-1 py-0.5 rounded-sm">Admin</span>}</h4>
<div className="flex items-center gap-2 mt-0.5">
                    <span className={`text-[8px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded border ${u.role==='Bartender'?'bg-blue-900/20 text-blue-400 border-blue-900/50':'bg-[#12161A] text-[#D4A381] border-[#2A353D]'}`}>{u.role}</span>
                    {u.phone && <span className="text-[9px] font-bold text-slate-500 truncate">{u.phone}</span>}
                    {appUser?.isAdmin && u.wage > 0 && <span className="text-[9px] font-black text-emerald-500 uppercase tracking-widest bg-emerald-900/10 border border-emerald-900/30 px-1.5 py-0.5 rounded ml-1">${Number(u.wage).toFixed(2)}/hr</span>}
                    {appUser?.isAdmin && <span className={`text-[8px] font-black uppercase tracking-widest ml-1 ${(!u.lastActive || Math.floor((Date.now() - new Date(u.lastActive).getTime()) / 86400000) > 1) ? 'text-red-500' : 'text-emerald-500'}`}>{!u.lastActive ? 'Never' : Math.floor((Date.now() - new Date(u.lastActive).getTime()) / 86400000) === 0 ? 'Active Today' : `Inactive ${Math.floor((Date.now() - new Date(u.lastActive).getTime()) / 86400000)} days`}</span>}
                  </div>
                </div>
              </div>
              
           {(appUser?.isAdmin || (canManageTeam && !u.isAdmin)) && (
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button onClick={() => handlePasswordReset(u)} className="px-2 py-1 text-[9px] font-bold text-slate-400 hover:text-blue-400 transition-colors bg-[#12161A] rounded border border-[#2A353D]">Reset</button>
                  <button onClick={() => handleEditClick(u)} className="p-1 text-slate-400 hover:text-[#D4A381] transition-colors bg-[#12161A] rounded border border-[#2A353D]"><Edit size={12}/></button>
                  <button onClick={() => handleDeactivate(u)} className="p-1 text-slate-400 hover:text-red-500 transition-colors bg-[#12161A] rounded border border-[#2A353D]"><Trash2 size={12}/></button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};

// --- MESSAGE BOARD ---
const TabMessages = ({ events, appUser, users, addToast }) => {
  const [message, setMessage] = useState('');
  const [replyTexts, setReplyTexts] = useState({});
  const [imageFile, setImageFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isImportant, setIsImportant] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedReplies, setExpandedReplies] = useState({});
  const messageRetentionDays = parseInt(appUser?.systemSettings?.messageRetentionDays || 30, 10);

  const toggleReplies = (id) => setExpandedReplies(prev => ({ ...prev, [id]: !prev[id] }));

  // --- AUTO-CLEANER ENGINE ---
  useEffect(() => {
    const cleanOldMessages = async () => {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - messageRetentionDays);
      const oldNotes = events.filter(e => e.type === 'note' && new Date(e.date) < thirtyDaysAgo);
      for (const note of oldNotes) {
        try { await deleteDoc(doc(db, "events", note.id)); }
        catch(e) { console.warn("Silent cleaner failed to delete note", e); }
      }
    };
    if (events.length > 0) cleanOldMessages();
  }, [events, messageRetentionDays]);

  const allNotes = events
    .filter(e => e.type === 'note')
    .filter(e => {
      const term = searchTerm.toLowerCase();
      return (e.title || '').toLowerCase().includes(term) || (e.author || '').toLowerCase().includes(term);
    })
    .sort((a,b) => new Date(b.date) - new Date(a.date));

  const handleBroadcast = async (e) => {
    e.preventDefault();
    if(!message.trim() && !imageFile) return;
    setIsUploading(true);

    let photoUrl = null;
    if (imageFile) {
      try {
        const fileRef = ref(storage, `messages/${appUser.restaurantId}/${Date.now()}_${imageFile.name}`);
        await uploadBytes(fileRef, imageFile);
        photoUrl = await getDownloadURL(fileRef);
      } catch (error) {
        addToast('Error', 'Image upload failed. Check connection.');
        setIsUploading(false);
        return;
      }
    }

    const isCritical = isImportant || message.trim().toLowerCase().includes('!critical');
    const finalMessage = message.trim().replace(/!critical/ig, '').trim();

    await addDoc(collection(db, "events"), {
      date: new Date().toISOString(),
      title: finalMessage,
      type: 'note',
      author: appUser.name,
      isImportant: isCritical,
      restaurantId: appUser.restaurantId,
      replies: [],
      imageUrl: photoUrl
    });

    try {
      await secureFetch('/api/send-push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          restaurantId: appUser.restaurantId,
          type: 'message',
          title: isCritical ? '🚨 CRITICAL ALERT' : `New Message from ${appUser.name.split(' ')[0]}`,
          body: finalMessage,
          textContent: finalMessage,
          isCritical: isCritical
        })
      });
    } catch (err) { console.error("Push failed:", err); }

    setMessage('');
    setImageFile(null);
    setIsUploading(false);
    setIsImportant(false);
    addToast('Posted', 'Message sent.');
  };

  const handleReplyChange = (id, text) => { setReplyTexts(prev => ({ ...prev, [id]: text })); };

  const handleSendReply = async (e, eventId) => {
    e.preventDefault();
    const text = replyTexts[eventId];
    if (!text || !text.trim()) return;
    const targetEvent = events.find(ev => ev.id === eventId);
    const currentReplies = targetEvent?.replies || [];
    const newReply = { id: Date.now().toString(), author: appUser.name, text: text.trim(), timestamp: new Date().toISOString() };
    try {
      await updateDoc(doc(db, "events", eventId), { replies: [...currentReplies, newReply] });
      setReplyTexts(prev => ({ ...prev, [eventId]: '' }));
    } catch (err) { addToast('Error', 'Could not post reply.'); }
  };

  const getTimeAgo = (dateString) => {
    const mins = Math.floor((new Date() - new Date(dateString)) / 60000);
    if (mins < 1) return 'now';
    if (mins < 60) return `${mins}m`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h`;
    return new Date(dateString).toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-2 message-pro pb-20">
      <div className="cockpit-panel rounded-xl overflow-hidden">
        <div className="p-2.5 sm:p-3 flex flex-col sm:flex-row sm:items-center gap-2 border-b border-[#2A353D] bg-[#12161A]/70">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <div className="h-8 w-8 rounded-lg bg-[#0B0E11] border border-[#2A353D] flex items-center justify-center text-[#D4A381]"><MessageSquare size={16}/></div>
            <div className="min-w-0">
              <h2 className="text-sm font-black text-white leading-none">Message Board</h2>
              <p className="text-[9px] font-bold uppercase tracking-widest text-slate-500 mt-1">Ops announcements, shift notes, and manager alerts</p>
            </div>
          </div>
          <div className="relative sm:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={15}/>
            <input type="text" placeholder="Search posts..." value={searchTerm} onChange={(e)=>setSearchTerm(e.target.value)} className="w-full pl-9 pr-3 py-2 bg-[#0B0E11] border border-[#2A353D] text-white text-xs rounded-lg outline-none focus:border-[#D4A381] transition-colors placeholder-slate-600" />
          </div>
          <div className="hidden md:flex items-center gap-2 text-[9px] font-black uppercase tracking-widest text-slate-500"><span className="cockpit-light bg-emerald-400 text-emerald-400 slow"></span>{allNotes.length} visible</div>
        </div>

        <form onSubmit={handleBroadcast} className="p-2.5 sm:p-3 bg-[#1A2126]">
          <div className="flex gap-2.5">
            <img src={getAvatar(appUser.name, appUser.photoURL)} className="w-8 h-8 rounded-full border border-[#2A353D] object-cover flex-shrink-0" alt="avatar"/>
            <div className="flex-1 min-w-0">
              <textarea value={message} onChange={e=>setMessage(e.target.value)} className="w-full bg-[#0B0E11] border border-[#2A353D] text-white text-sm outline-none resize-none min-h-[38px] rounded-lg px-3 py-2 placeholder-slate-600 focus:border-[#D4A381] transition-colors" placeholder="Post a clear shift note, 86 item, handoff, or manager update..." />
              {imageFile && (
                <div className="mt-2 text-[10px] text-blue-300 font-bold bg-blue-900/10 px-2 py-1.5 rounded-lg border border-blue-900/30 flex justify-between items-center w-full sm:w-max max-w-full">
                  <span className="truncate pr-3 flex items-center gap-1.5"><Camera size={12}/> {imageFile.name}</span>
                  <button type="button" onClick={()=>setImageFile(null)} className="text-slate-400 hover:text-white p-1 rounded-md transition-colors"><X size={12}/></button>
                </div>
              )}
              <div className="flex justify-between items-center gap-2 mt-2">
                <div className="flex items-center gap-2 min-w-0">
                  <label className="h-8 w-8 rounded-lg bg-[#0B0E11] border border-[#2A353D] text-[#D4A381] hover:bg-[#12161A] flex items-center justify-center cursor-pointer transition-colors" title="Attach Photo"><Camera size={15} /><input type="file" accept="image/*" onChange={(e) => setImageFile(e.target.files[0])} className="hidden" disabled={isUploading} /></label>
                  <label className={`flex items-center gap-2 cursor-pointer rounded-lg px-2.5 py-2 border transition-colors ${isImportant ? 'bg-red-900/20 border-red-500/50 text-red-300' : 'bg-[#0B0E11] border-[#2A353D] text-slate-400 hover:text-slate-200'}`}>
                    <input type="checkbox" checked={isImportant} onChange={e=>setIsImportant(e.target.checked)} className="w-3.5 h-3.5 rounded bg-[#12161A] border-[#2A353D] accent-red-500 cursor-pointer" />
                    <span className="text-[9px] font-black uppercase tracking-widest">Priority</span>
                  </label>
                </div>
                <button type="submit" disabled={isUploading || (!message.trim() && !imageFile)} className="bg-gradient-to-r from-[#C59373] to-[#8F6040] hover:opacity-90 text-slate-900 font-black tracking-widest uppercase text-[10px] py-2 px-4 rounded-lg transition-all disabled:opacity-50 flex items-center justify-center gap-1.5">
                  {isUploading ? <Loader2 className="animate-spin" size={14}/> : <><Send size={13}/> Post</>}
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>

      <div className="space-y-2">
        {allNotes.length === 0 && (
          <div className="text-center py-12 bg-[#1A2126] border border-[#2A353D] rounded-xl">
             <MessageSquare size={28} className="mx-auto text-slate-600 mb-2" />
             <p className="text-sm font-bold text-slate-500">{searchTerm ? 'No posts matched your search.' : 'No active posts. Clean board, clean shift.'}</p>
             <p className="text-[10px] text-slate-600 font-bold uppercase tracking-widest mt-1">Messages auto-archive after {messageRetentionDays} days</p>
          </div>
        )}

        {allNotes.map(n => {
          const authorUser = users.find(u => u.name === n.author);
          const replies = n.replies || [];
          return (
            <div key={n.id} className={`message-card-pro rounded-xl border overflow-hidden transition-colors ${n.isImportant ? 'border-red-500/40 bg-red-950/10' : 'border-[#2A353D] bg-[#1A2126] hover:bg-[#1A2126]/90'}`}>
              <div className="flex">
                <div className={`w-1.5 flex-shrink-0 ${n.isImportant ? 'bg-red-500' : 'bg-[#2A353D]'}`}></div>
                <div className="flex-1 min-w-0 p-2.5 sm:p-3">
                  <div className="flex items-start gap-2.5">
                    <img src={getAvatar(n.author, authorUser?.photoURL)} className="w-8 h-8 rounded-full border border-[#2A353D] object-cover bg-[#12161A] flex-shrink-0" alt="pic"/>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between gap-2 items-start">
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap leading-none">
                            <span className={`font-black text-sm ${n.isImportant ? 'text-red-300' : 'text-white'}`}>{n.author || 'Unknown'}</span>
                            {authorUser?.isAdmin && <span className="bg-[#0B0E11] border border-[#2A353D] text-[#D4A381] text-[8px] px-1.5 py-0.5 rounded uppercase font-black tracking-widest">Admin</span>}
                            {n.isImportant && <span className="bg-red-500/10 border border-red-500/40 text-red-300 text-[8px] px-1.5 py-0.5 rounded uppercase font-black tracking-widest flex items-center gap-1"><Bell size={10}/> Important</span>}
                          </div>
                          <div className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1" title={new Date(n.date).toLocaleString()}>{getTimeAgo(n.date)}</div>
                        </div>
                        {appUser?.isAdmin && <button onClick={() => { if(window.confirm('Delete this post?')) deleteDoc(doc(db, 'events', n.id)); }} className="text-slate-600 hover:text-red-500 transition-colors p-1 rounded-md hover:bg-red-900/20"><Trash2 size={14}/></button>}
                      </div>

                      {n.title && <p className="font-medium text-sm leading-snug text-slate-200 break-words whitespace-pre-wrap mt-2">{n.title}</p>}
                      {n.imageUrl && <div className="mt-2 rounded-lg overflow-hidden border border-[#2A353D] bg-[#0B0E11] max-w-xl"><img src={n.imageUrl} alt="Attached" className="w-full max-h-[260px] object-cover" /></div>}

                      {replies.length > 0 && (
                        <button type="button" onClick={() => toggleReplies(n.id)} className="mt-2 flex items-center gap-1.5 text-[10px] font-black text-slate-500 hover:text-[#D4A381] uppercase tracking-widest transition-colors">
                          <MessageSquare size={13} /> {expandedReplies[n.id] ? 'Hide Thread' : `${replies.length} ${replies.length === 1 ? 'Reply' : 'Replies'}`}
                        </button>
                      )}

                      {expandedReplies[n.id] && replies.length > 0 && (
                        <div className="mt-2 space-y-2 border-l border-[#2A353D] pl-3 animate-[slideIn_0.2s_ease-out]">
                          {replies.map((r) => (
                            <div key={r.id} className="flex gap-2">
                              <img src={getAvatar(r.author, users.find(u => u.name === r.author)?.photoURL)} className="w-6 h-6 rounded-full border border-[#2A353D] object-cover flex-shrink-0" alt="pic"/>
                              <div className="flex-1 bg-[#0B0E11] border border-[#2A353D] rounded-lg px-2.5 py-2">
                                <div className="flex items-center gap-1.5 leading-none mb-1"><span className="font-bold text-xs text-white">{r.author}</span><span className="text-slate-500 text-[10px]">· {getTimeAgo(r.timestamp)}</span></div>
                                <div className="text-slate-300 font-medium text-xs leading-snug">{r.text}</div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {n.author !== 'System Alert' && (
                        <form onSubmit={(e) => handleSendReply(e, n.id)} className="flex gap-2 mt-2 items-center">
                          <img src={getAvatar(appUser.name, appUser.photoURL)} className="w-6 h-6 rounded-full border border-[#2A353D] object-cover flex-shrink-0" alt="pic"/>
                          <div className="relative flex-1">
                            <input type="text" placeholder="Reply..." value={replyTexts[n.id] || ''} onChange={(e) => handleReplyChange(n.id, e.target.value)} className="w-full bg-[#0B0E11] border border-[#2A353D] text-white text-xs font-medium rounded-lg pl-3 pr-8 py-1.5 outline-none focus:border-[#D4A381] transition-colors placeholder-slate-600" />
                            <button type="submit" disabled={!replyTexts[n.id]?.trim()} className="absolute right-1 top-1/2 -translate-y-1/2 text-[#D4A381] disabled:opacity-30 hover:bg-[#D4A381]/10 p-1 rounded-md transition-colors"><Send size={12}/></button>
                          </div>
                        </form>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// --- SCHEDULE MAKER (Monthly View, Single Page Desktop, Scrolling Mobile) ---
const TabSchedule = ({ currentDate, users, shifts, events, timeOffRequests, timePunches = [], addToast, appUser, initialSubTab = 'schedule', hideSubTabs = false }) => {
  const [subTab, setSubTab] = useState(initialSubTab); 
  const [selectedEmp, setSelectedEmp] = useState(''); 
  const [assignDates, setAssignDates] = useState([]); 
  const [presetShift, setPresetShift] = useState('Custom'); 
  const [startTime, setStartTime] = useState('16:00'); 
  const [endTime, setEndTime] = useState('21:00');
  
  const [isEventModalOpen, setIsEventModalOpen] = useState(false); 
const [eventDate, setEventDate] = useState(getToday()); 
  const [eventTime, setEventTime] = useState('');
  const [eventTitle, setEventTitle] = useState('');
  const [eventNotes, setEventNotes] = useState('');
  const [editingEventId, setEditingEventId] = useState(null);
  const [eventImageFile, setEventImageFile] = useState(null);
  const [isEventUploading, setIsEventUploading] = useState(false);
  
// Repeating Events State
  const [isRepeating, setIsRepeating] = useState(false);
  const [repeatType, setRepeatType] = useState('weekly');
  const [repeatUntil, setRepeatUntil] = useState('');

  // --- EVENTS CALENDAR STATE ---
  const [eventsCalMonth, setEventsCalMonth] = useState(getMonthStr(currentDate));
  useEffect(() => { setEventsCalMonth(getMonthStr(currentDate)); }, [currentDate]);

  const changeEventsMonth = (offset) => {
    const d = new Date(eventsCalMonth + '-01T12:00:00');
    d.setMonth(d.getMonth() + offset);
    setEventsCalMonth(d.toISOString().substring(0, 7));
  };
  
  const eventsMonthDays = Array.from({length: getDaysInMonth(eventsCalMonth)}).map((_, i) => `${eventsCalMonth}-${String(i+1).padStart(2, '0')}`);
  const eventsFirstDayOffset = new Date(eventsCalMonth+'-01T12:00:00').getDay();
  const eventsCalEvents = events.filter(e => e.type === 'special_event' && e.date?.startsWith(eventsCalMonth));

  // --- AUTO-POPULATE STATE ---
  const [isAutoPopulateModalOpen, setIsAutoPopulateModalOpen] = useState(false);
  const [autoPopSourceMonth, setAutoPopSourceMonth] = useState('');
  
  const monthStr = getMonthStr(currentDate); 
  const monthDays = Array.from({length: getDaysInMonth(monthStr)}).map((_, i) => `${monthStr}-${String(i+1).padStart(2, '0')}`);
  const monthShifts = shifts.filter(s => s.date.startsWith(monthStr));
  const monthEvents = events.filter(e => e.type === 'special_event' && e.date.startsWith(monthStr)).sort((a,b) => (a.date || '').localeCompare(b.date || ''));

  // --- CUSTOM DROPDOWN TIME GENERATOR ---
  const TIME_OPTIONS = [];
  for (let i = 0; i < 24; i++) {
    for (let j = 0; j < 60; j += 15) {
      TIME_OPTIONS.push(`${String(i).padStart(2, '0')}:${String(j).padStart(2, '0')}`);
    }
  }

  // --- CUSTOM SHIFT PRESETS LOGIC ---
  const [customPresets, setCustomPresets] = useState([]);
  const [isPresetModalOpen, setIsPresetModalOpen] = useState(false);
  const [editingPresetId, setEditingPresetId] = useState(null);
  const [newPresetLabel, setNewPresetLabel] = useState('');
  const [newPresetStart, setNewPresetStart] = useState('16:00');
  const [newPresetEnd, setNewPresetEnd] = useState('21:00');

  useEffect(() => {
    const saved = localStorage.getItem(`customPresets_${appUser?.restaurantId}`);
    if (saved) {
      setCustomPresets(JSON.parse(saved));
    } else {
      const seed = [ 
        { id: '1', label: "9a-3p", start: "09:00", end: "15:00" }, { id: '2', label: "10a-4p", start: "10:00", end: "16:00" }, 
        { id: '3', label: "10a-9p", start: "10:00", end: "21:00" }, { id: '4', label: "11a-3p", start: "11:00", end: "15:00" }, 
        { id: '5', label: "11a-4p", start: "11:00", end: "16:00" }, { id: '6', label: "4p-9p", start: "16:00", end: "21:00" }
      ];
      setCustomPresets(seed);
      localStorage.setItem(`customPresets_${appUser?.restaurantId}`, JSON.stringify(seed));
    }
  }, [appUser?.restaurantId]);

  const saveCustomPresetsLocally = (newPresets) => {
    setCustomPresets(newPresets);
    localStorage.setItem(`customPresets_${appUser?.restaurantId}`, JSON.stringify(newPresets));
  };

  const SHIFT_PRESETS = [
    ...[...customPresets].sort((a,b) => a.start.localeCompare(b.start)),
    { id: 'custom', label: "Custom", start: "", end: "" }
  ];

  const handlePresetChange = (e) => { 
    const val = e.target.value; 
    setPresetShift(val); 
    const p = SHIFT_PRESETS.find(x => x.label === val); 
    if (p && val !== 'Custom') { 
      setStartTime(p.start); 
      setEndTime(p.end); 
    } 
  };

  const handleSavePreset = (e) => {
    e.preventDefault();
    if (!newPresetLabel || !newPresetStart || !newPresetEnd) return;
    
    if (editingPresetId) {
      const updated = customPresets.map(p => 
        p.id === editingPresetId ? { ...p, label: newPresetLabel.trim(), start: newPresetStart, end: newPresetEnd } : p
      );
      saveCustomPresetsLocally(updated);
      addToast('Updated', 'Shift preset updated.');
    } else {
      const newPreset = {
        id: Date.now().toString(),
        label: newPresetLabel.trim(),
        start: newPresetStart,
        end: newPresetEnd
      };
      saveCustomPresetsLocally([...customPresets, newPreset]);
      addToast('Saved', 'New shift preset added.');
    }
    cancelPresetEdit();
  };

  const handleEditPreset = (preset) => {
    setNewPresetLabel(preset.label);
    setNewPresetStart(preset.start);
    setNewPresetEnd(preset.end);
    setEditingPresetId(preset.id);
    document.getElementById('preset-modal-form')?.scrollIntoView({ behavior: 'smooth' });
  };

  const cancelPresetEdit = () => {
    setNewPresetLabel('');
    setNewPresetStart('16:00');
    setNewPresetEnd('21:00');
    setEditingPresetId(null);
  };

  const handleDeletePreset = (id) => {
    if(window.confirm('Delete this preset?')) {
      const filtered = customPresets.filter(p => p.id !== id);
      saveCustomPresetsLocally(filtered);
    }
  };

// --- PAYROLL DATE RANGE ---
  const [periodStart, setPeriodStart] = useState(`${monthStr}-01`);
  const [periodEnd, setPeriodEnd] = useState(`${monthStr}-${String(getDaysInMonth(monthStr)).padStart(2, '0')}`);
  
  // --- PUNCH FILTERS ---
  const [punchFilterDate, setPunchFilterDate] = useState('');
  const [punchFilterEmp, setPunchFilterEmp] = useState('');

  // --- LABOR & FINANCIAL TARGETS ---
  const [isTargetSettingsOpen, setIsTargetSettingsOpen] = useState(false);
  const [targetSales, setTargetSales] = useState(appUser?.systemSettings?.targetSales || '0');
  const [targetLaborPct, setTargetLaborPct] = useState(appUser?.systemSettings?.targetLaborPct || '0');
  
  const handleSaveTargets = async (e) => {
    e.preventDefault();
    try {
      await updateDoc(doc(db, "restaurants", appUser.restaurantId), {
        'systemSettings.targetSales': parseFloat(targetSales) || 0,
        'systemSettings.targetLaborPct': parseFloat(targetLaborPct) || 0,
        'systemSettings.enableTargets': true
      });
      addToast('Saved', 'Financial and labor targets updated.');
      setIsTargetSettingsOpen(false);
    } catch (err) { addToast('Error', err.message); }
  };

  useEffect(() => {
    setPeriodStart(`${monthStr}-01`);
    setPeriodEnd(`${monthStr}-${String(getDaysInMonth(monthStr)).padStart(2, '0')}`);
  }, [monthStr]);

  const activeRoster = users.filter(u => u.isActive !== false);

  const displayUsers = [...activeRoster].sort((a,b) => {
    const roleA = a.role || 'Unassigned';
    const roleB = b.role || 'Unassigned';
    const nameA = a.name || 'Unknown';
    const nameB = b.name || 'Unknown';
    return roleA === roleB ? nameA.localeCompare(nameB) : roleA.localeCompare(roleB);
  });
  
  const groupedUsers = activeRoster.reduce((acc, user) => {
    const role = user.role || 'Unassigned';
    if (!acc[role]) acc[role] = [];
    acc[role].push(user);
    return acc;
  }, {});
  const sortedRoles = Object.keys(groupedUsers).sort();

  const getRoleColors = (role, isPublished) => {
    if (!isPublished) return 'bg-slate-400 text-slate-900';
    const r = (role || '').toLowerCase();
    if (r.includes('bartender')) return 'bg-blue-400 text-blue-950';
    if (r.includes('cook') || r.includes('chef') || r.includes('kitchen')) return 'bg-orange-400 text-orange-950';
    if (r.includes('server') || r.includes('wait')) return 'bg-pink-400 text-pink-950';
    if (r.includes('host')) return 'bg-emerald-400 text-emerald-950';
    if (r.includes('manager')) return 'bg-purple-400 text-purple-950';
    if (r.includes('dish')) return 'bg-cyan-400 text-cyan-950';
    return 'bg-[#D4A381] text-slate-900'; 
  };

  const handleCellClick = (d, empId) => {
    if (d < getToday()) return addToast("Locked", "Cannot edit past dates.");
    const existing = monthShifts.find(s => s.date === d && s.employeeId === empId);
    if (existing) { if(window.confirm("Delete shift?")) deleteDoc(doc(db,"shifts",existing.id)); return; }
    setSelectedEmp(empId); if (assignDates.includes(d)) setAssignDates(assignDates.filter(x => x!==d)); else setAssignDates([...assignDates, d]);
  };

  const handleAssign = async () => {
    if (!selectedEmp || assignDates.length === 0) return; const emp = users.find(u => u.id === selectedEmp);
    const validDates = [];
    for (const d of assignDates) { 
      const existingShift = monthShifts.find(s => s.date === d && s.employeeId === emp.id);
      if (existingShift) { addToast('Blocked', `${(emp.name||'Unknown').split(' ')[0]} is already scheduled on ${formatDisplayDate(d)}.`); return; }
      
      const req = timeOffRequests.find(r => r.date === d && r.userId === emp.id && r.status !== 'pending');
      if (req) {
        if (!req.isPartial) { addToast('Blocked', `${(emp.name||'Unknown').split(' ')[0]} requested ${formatDisplayDate(d)} off.`); return; } 
        else { const reqEnd = req.endTime || '23:59'; if ((startTime < reqEnd) && (endTime > req.startTime)) { addToast('Blocked', `${(emp.name||'Unknown').split(' ')[0]} is unavailable from ${formatShortTime(req.startTime)} to ${formatShortTime(req.endTime)} on ${formatDisplayDate(d)}.`); return; } }
      }
      validDates.push(d);
    }
    for (const d of validDates) { await addDoc(collection(db, "shifts"), { date: d, employeeId: emp.id, role: emp.role || 'Unassigned', startTime: startTime, endTime: endTime, isPublished: false, restaurantId: appUser.restaurantId }); }
    setAssignDates([]); addToast('Assigned', `Added ${validDates.length} shifts.`);
  };

const handlePublish = async () => { 
    if(!window.confirm("Publish schedule? Notifications will be sent.")) return; 
    
    const unpub = shifts.filter(s => !s.isPublished); 
    
    if (unpub.length === 0) {
      addToast('Notice', 'No unpublished shifts found.');
      return;
    }
    
    addToast('Publishing...', `Pushing ${unpub.length} shifts live. Please wait.`);
    
    try {
      await Promise.all(unpub.map(s => updateDoc(doc(db, "shifts", s.id), { isPublished: true })));
      
      addToast("Published", "Schedule is live."); 
      logAudit(appUser, 'PUBLISH_SCHEDULE', 'Master Roster', `Pushed ${unpub.length} shifts live.`); 

// --- NEW: TRIGGER PUSH NOTIFICATIONS ---
      try {
        addToast('Pinging Server', 'Sending alert request to Vercel...');
        const pushRes = await secureFetch('/api/send-schedule-alert', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            restaurantId: appUser.restaurantId,
            restaurantName: appUser.restaurantName || 'Your restaurant'
          })
        });
        
        const pushData = await pushRes.json();
        console.log("VERCEL RESPONSE:", pushData);
        
        if (pushData.message) {
          // This catches the "No devices registered" silent exit
          addToast('Server Reply', pushData.message); 
        } else if (pushData.success) {
          addToast('Alerts Sent!', `Successfully pushed to ${pushData.sentCount} devices.`);
        } else {
          addToast('API Error', pushData.error || 'Unknown server error');
        }

      } catch (pushErr) {
        console.error("Failed to send push notifications:", pushErr);
        addToast('Network Error', 'Failed to reach Vercel API.');
      }

    } catch (err) {
      addToast("Error", "Some shifts failed to publish. Check connection and try again.");
    }
  };
  
const handleAddEvent = async (e) => { 
    e.preventDefault(); 
    if(!eventTitle.trim()) return; 
    setIsEventUploading(true);

    let photoUrl = null;
    if (eventImageFile) {
      try {
        const fileRef = ref(storage, `events/${appUser.restaurantId}/${Date.now()}_${eventImageFile.name}`);
        await uploadBytes(fileRef, eventImageFile);
        photoUrl = await getDownloadURL(fileRef);
      } catch (error) {
        addToast('Error', 'Image upload failed. Check connection.');
        setIsEventUploading(false);
        return;
      }
    }

    const baseEventData = { type: 'special_event', time: eventTime, title: eventTitle.trim(), notes: eventNotes.trim(), addedBy: appUser.name, restaurantId: appUser.restaurantId };
    if (photoUrl) baseEventData.imageUrl = photoUrl; 

    if (editingEventId) {
      await updateDoc(doc(db, "events", editingEventId), { date: eventDate, time: eventTime, title: eventTitle.trim(), notes: eventNotes.trim(), ...(photoUrl && { imageUrl: photoUrl }) });
      addToast('Updated', 'Event modified successfully.');
    } else {
      if (isRepeating && repeatUntil) {
        const seriesId = Date.now().toString();
        let currentDateObj = new Date(eventDate + 'T12:00:00');
        const endDateObj = new Date(repeatUntil + 'T12:00:00');
        const promises = [];
        let count = 0;

        while (currentDateObj <= endDateObj && count < 365) { // Hard cap at 365 events to prevent DB crash loops
          const dateStr = currentDateObj.toISOString().split('T')[0];
          promises.push(addDoc(collection(db, "events"), { ...baseEventData, date: dateStr, seriesId }));
          
          if (repeatType === 'daily') currentDateObj.setDate(currentDateObj.getDate() + 1);
          else if (repeatType === 'weekly') currentDateObj.setDate(currentDateObj.getDate() + 7);
          else if (repeatType === 'bi-weekly') currentDateObj.setDate(currentDateObj.getDate() + 14);
          else if (repeatType === 'monthly') currentDateObj.setMonth(currentDateObj.getMonth() + 1);
          else if (repeatType === 'yearly') currentDateObj.setFullYear(currentDateObj.getFullYear() + 1);
          count++;
        }
        await Promise.all(promises);
        addToast('Events Generated', `Created ${count} recurring events.`);
      } else {
        await addDoc(collection(db, "events"), { ...baseEventData, date: eventDate }); 
        addToast('Event Added', 'Calendar updated.');
      }
    }
    setEventTitle(''); setEventTime(''); setEventNotes(''); setEditingEventId(null); setEventImageFile(null); setIsEventUploading(false); setIsEventModalOpen(false); setIsRepeating(false); setRepeatUntil(''); 
  };

  const openEditEventModal = (ev) => {
    setEventDate(ev.date); setEventTime(ev.time || ''); setEventTitle(ev.title || ''); setEventNotes(ev.notes || ''); setEditingEventId(ev.id); setEventImageFile(null); setIsEventModalOpen(true);
  };

  const openNewEventModal = () => {
    setEventDate(currentDate); setEventTime(''); setEventTitle(''); setEventNotes(''); setEditingEventId(null); setEventImageFile(null); setIsEventModalOpen(true);
  };

  // --- AUTO-POPULATE SCHEDULE ENGINE ---
  const handleAutoPopulate = async () => {
    if (!autoPopSourceMonth) return addToast('Error', 'Please select a source month.');
    const sourceShifts = shifts.filter(s => s.date.startsWith(autoPopSourceMonth));
    if (sourceShifts.length === 0) return addToast('Empty', 'No shifts found in the selected month.');

    const targetMonth = getMonthStr(currentDate);
    if (autoPopSourceMonth === targetMonth) return addToast('Error', 'Cannot copy to the exact same month.');

    // Calculate Day Offset to cleanly align days of the week (Monday to Monday)
    let sMon = new Date(autoPopSourceMonth + '-01T12:00:00');
    while(sMon.getDay() !== 1) sMon.setDate(sMon.getDate() + 1);

    let tMon = new Date(targetMonth + '-01T12:00:00');
    while(tMon.getDay() !== 1) tMon.setDate(tMon.getDate() + 1);

    const dayOffset = Math.round((tMon - sMon) / (1000 * 60 * 60 * 24));

    let addedCount = 0;
    for (const s of sourceShifts) {
      const sDate = new Date(s.date + 'T12:00:00');
      sDate.setDate(sDate.getDate() + dayOffset);
      const newDateStr = sDate.toISOString().split('T')[0];

      if (newDateStr.startsWith(targetMonth)) {
        // Prevent exact duplicates 
        const exists = shifts.find(existing => existing.date === newDateStr && existing.employeeId === s.employeeId && existing.role === s.role && existing.startTime === s.startTime && existing.endTime === s.endTime);
        
        if (!exists) {
          await addDoc(collection(db, "shifts"), { 
            date: newDateStr, 
            employeeId: s.employeeId, 
            role: s.role, 
            startTime: s.startTime, 
            endTime: s.endTime, 
            isPublished: false, 
            restaurantId: appUser.restaurantId 
          });
          addedCount++;
        }
      }
    }
    setIsAutoPopulateModalOpen(false);
    setAutoPopSourceMonth('');
    addToast('Populated', `Drafted ${addedCount} shifts. Conflicts are highlighted in red.`);
  };

  // --- LABOR PROJECTION ENGINE ---
  const calculateShiftHours = (start, end) => {
    if (!start || !end) return 0;
    let sH = parseInt(start.split(':')[0]), sM = parseInt(start.split(':')[1]) / 60;
    let eH = parseInt(end.split(':')[0]), eM = parseInt(end.split(':')[1]) / 60;
    let total = (eH + eM) - (sH + sM);
    if (total < 0) total += 24; 
    return total;
  };

  let projectedMonthLabor = 0;
  const projectedDailyLabor = {};
  monthDays.forEach(d => projectedDailyLabor[d] = 0);

  monthShifts.forEach(shift => {
    const emp = users.find(u => u.id === shift.employeeId);
    const wage = emp?.wage || 0; 
    const hours = calculateShiftHours(shift.startTime, shift.endTime);
    const cost = hours * wage;
    
    projectedMonthLabor += cost;
    if (projectedDailyLabor[shift.date] !== undefined) {
      projectedDailyLabor[shift.date] += cost;
    }
  });

  const periodPunches = timePunches.filter(p => p.date >= periodStart && p.date <= periodEnd).sort((a,b) => new Date(a.clockInTime || 0) - new Date(b.clockInTime || 0));
  
  const calculatePunchHours = (inTime, outTime, breakMins = 0) => {
      if (!inTime || !outTime) return 0;
      const rawMins = (new Date(outTime) - new Date(inTime)) / 60000;
      return Math.max(0, (rawMins - breakMins) / 60);
  };

  const getWeekStart = (dateString) => {
      const daysMap = { 'Sunday': 0, 'Monday': 1, 'Tuesday': 2, 'Wednesday': 3, 'Thursday': 4, 'Friday': 5, 'Saturday': 6 };
      const startDayInt = daysMap[appUser?.preferences?.payPeriodStart || 'Monday'];
      let d = new Date(dateString + 'T12:00:00');
      while (d.getDay() !== startDayInt) { d.setDate(d.getDate() - 1); }
      return d.toISOString().split('T')[0];
  };
  const payrollSummary = {};
  const weeklyHours = {}; 
  const OT_THRESHOLD = parseFloat(appUser?.systemSettings?.overtime || 40);

  periodPunches.forEach(p => {
      if (p.status === 'clocked_in' || !p.clockOutTime) return;
      
      const emp = users.find(u => u.id === p.employeeId);
      if (!payrollSummary[p.employeeId]) {
          payrollSummary[p.employeeId] = {
              name: p.employeeName || 'Unknown', regHours: 0, otHours: 0, cashTips: 0, creditTips: 0, rate: emp?.wage || 0, pay: 0
          };
      }
      
      const hours = calculatePunchHours(p.clockInTime, p.clockOutTime, p.breakMinutes || 0);
      const weekKey = `${p.employeeId}_${getWeekStart(p.date)}`;
      const prevWeeklyHours = weeklyHours[weekKey] || 0;
      const newWeeklyHours = prevWeeklyHours + hours;
      
      let reg = 0; let ot = 0;
      if (prevWeeklyHours >= OT_THRESHOLD) { ot = hours; } else if (newWeeklyHours > OT_THRESHOLD) { reg = OT_THRESHOLD - prevWeeklyHours; ot = newWeeklyHours - OT_THRESHOLD; } else { reg = hours; }
      
      weeklyHours[weekKey] = newWeeklyHours;
      payrollSummary[p.employeeId].regHours += reg; payrollSummary[p.employeeId].otHours += ot;
      payrollSummary[p.employeeId].cashTips += (parseFloat(p.cashTips) || 0); payrollSummary[p.employeeId].creditTips += (parseFloat(p.creditTips) || 0);
      
      const rate = emp?.wage || 0;
      payrollSummary[p.employeeId].pay += (reg * rate) + (ot * rate * 1.5);
  });
  
  const summaryList = Object.values(payrollSummary).sort((a, b) => a.name.localeCompare(b.name));
  const actualPeriodLabor = summaryList.reduce((acc, s) => acc + s.pay, 0);

  const handleForceClockOut = async (punch) => {
      if (!window.confirm(`Force clock out ${punch.employeeName}?`)) return;
      await updateDoc(doc(db, "timePunches", punch.id), { clockOutTime: new Date().toISOString(), status: 'clocked_out' });
      addToast('Updated', `Punched out ${punch.employeeName}.`);
  };

  const handleDeletePunch = async (id) => {
      if (!window.confirm("Delete this time punch permanently?")) return;
      await deleteDoc(doc(db, "timePunches", id));
      addToast('Deleted', 'Time punch removed.');
  };

const [isPunchModalOpen, setIsPunchModalOpen] = useState(false);
  const [editingPunch, setEditingPunch] = useState(null);
  const [editPunchEmpId, setEditPunchEmpId] = useState(''); // NEW: For creating punches
  const [editPunchIn, setEditPunchIn] = useState('');
  const [editPunchOut, setEditPunchOut] = useState('');
  const [editBreakMins, setEditBreakMins] = useState('');
  const [editCash, setEditCash] = useState('');
  const [editCredit, setEditCredit] = useState('');

  const openEditPunchModal = (punch) => {
    setEditingPunch(punch);
    const formatForInput = (iso) => {
      if (!iso) return '';
      const d = new Date(iso);
      const tzOffset = d.getTimezoneOffset() * 60000;
      return new Date(d.getTime() - tzOffset).toISOString().slice(0, 16);
    };
    setEditPunchIn(formatForInput(punch.clockInTime));
    setEditPunchOut(punch.clockOutTime && punch.status === 'clocked_out' ? formatForInput(punch.clockOutTime) : '');
    setEditBreakMins(punch.breakMinutes || 0);
    setEditCash(punch.cashTips || 0);
    setEditCredit(punch.creditTips || 0);
    setIsPunchModalOpen(true);
  };

  const openAddPunchModal = () => {
    setEditingPunch(null);
    setEditPunchEmpId('');
    setEditPunchIn('');
    setEditPunchOut('');
    setEditBreakMins('0');
    setEditCash('0');
    setEditCredit('0');
    setIsPunchModalOpen(true);
  };

  const handleSavePunchEdit = async (e) => {
    e.preventDefault();
    try {
      if (editingPunch) {
        if (!editPunchIn) return;
        const updateData = { clockInTime: new Date(editPunchIn).toISOString(), breakMinutes: parseFloat(editBreakMins) || 0, cashTips: parseFloat(editCash) || 0, creditTips: parseFloat(editCredit) || 0 };
        if (editPunchOut) { updateData.clockOutTime = new Date(editPunchOut).toISOString(); updateData.status = 'clocked_out'; } else { updateData.clockOutTime = null; updateData.status = 'clocked_in'; }
        await updateDoc(doc(db, "timePunches", editingPunch.id), updateData);
        addToast('Updated', 'Time punch modified successfully.');
      } else {
        if (!editPunchEmpId || !editPunchIn) return addToast('Error', 'Employee and Clock In Time required.');
        const emp = users.find(u => u.id === editPunchEmpId);
        const newData = {
          employeeId: emp.id,
          employeeName: emp.name,
          clockInTime: new Date(editPunchIn).toISOString(),
          breakMinutes: parseFloat(editBreakMins) || 0,
          cashTips: parseFloat(editCash) || 0,
          creditTips: parseFloat(editCredit) || 0,
          date: editPunchIn.split('T')[0], // Extract YYYY-MM-DD
          restaurantId: appUser.restaurantId
        };
        if (editPunchOut) { newData.clockOutTime = new Date(editPunchOut).toISOString(); newData.status = 'clocked_out'; } 
        else { newData.clockOutTime = null; newData.status = 'clocked_in'; }
        await addDoc(collection(db, "timePunches"), newData);
        addToast('Added', 'Missing time punch created.');
      }
      setIsPunchModalOpen(false);
      setEditingPunch(null);
    } catch (err) { addToast('Error', err.message); }
  };

const handleExportTimesheets = () => {
    if (periodPunches.length === 0) return addToast("Empty", "No punches to export for this period.");
    const pStartStr = new Date(periodStart + 'T12:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    const pEndStr = new Date(periodEnd + 'T12:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    
    // Header for the Payroll Summary
    let csv = `"--- PAYROLL SUMMARY ---"\n"Pay Period: ${pStartStr} - ${pEndStr}"\n\n"Employee Name","Reg Hours","OT Hours","Hourly Rate","Total Gross Pay","Declared Cash Tips","Declared Credit Tips"\n`;
    summaryList.forEach(s => { 
      csv += `"${s.name}","${s.regHours.toFixed(2)}","${s.otHours.toFixed(2)}","$${s.rate.toFixed(2)}","$${s.pay.toFixed(2)}","$${s.cashTips.toFixed(2)}","$${s.creditTips.toFixed(2)}"\n`; 
    });
    
    // Header for Individual Punches
    csv += '\n"--- INDIVIDUAL PUNCHES ---"\n"Employee Name","Date","Clock In","Clock Out","Break (Mins)","Total Hours","Hourly Rate","Total Pay","Cash Tips","Credit Tips"\n';
    
    const sortedPunches = [...periodPunches].sort((a,b) => new Date(b.clockInTime || 0) - new Date(a.clockInTime || 0));
    sortedPunches.forEach(p => {
       const emp = users.find(u => u.id === p.employeeId); 
       const hours = calculatePunchHours(p.clockInTime, p.clockOutTime, p.breakMinutes || 0); 
       const rate = emp?.wage || 0; 
       const estCost = hours * rate; 
       const inStr = p.clockInTime ? new Date(p.clockInTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : 'Unknown';
       const outStr = p.status === 'clocked_in' ? 'ON CLOCK' : (p.clockOutTime ? new Date(p.clockOutTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : 'Unknown');
       
       csv += `"${p.employeeName || 'Unknown'}","${p.date || 'Unknown'}","${inStr}","${outStr}","${p.breakMinutes||0}","${hours.toFixed(2)}","$${rate.toFixed(2)}","$${estCost.toFixed(2)}","$${parseFloat(p.cashTips||0).toFixed(2)}","$${parseFloat(p.creditTips||0).toFixed(2)}"\n`;
    });

    const blob = new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8;' }); 
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a"); 
    link.setAttribute("href", url); 
    link.setAttribute("download", `Payroll_Export_${periodStart}_to_${periodEnd}.csv`);
    document.body.appendChild(link); 
    link.click(); 
    document.body.removeChild(link); 
    URL.revokeObjectURL(url); 
    addToast('Exported', 'Spreadsheet generated.');
  };

  const daysMap = { 'Sunday': 0, 'Monday': 1, 'Tuesday': 2, 'Wednesday': 3, 'Thursday': 4, 'Friday': 5, 'Saturday': 6 };
  const startDayInt = daysMap[appUser?.preferences?.payPeriodStart || 'Monday'];
  const endDayInt = startDayInt === 0 ? 6 : startDayInt - 1;

  const weeksInMonth = []; let currentWeek = [];
  monthDays.forEach(d => { currentWeek.push(d); if (new Date(d+'T12:00').getDay() === endDayInt) { weeksInMonth.push(currentWeek); currentWeek = []; } });
  if (currentWeek.length > 0) weeksInMonth.push(currentWeek);

  const scheduledHours = displayUsers.map(u => {
     const userShifts = monthShifts.filter(s => s.employeeId === u.id);
     const weekly = weeksInMonth.map(weekDaysArr => { return weekDaysArr.reduce((sum, d) => { const shift = userShifts.find(s => s.date === d); return sum + (shift ? calculateShiftHours(shift.startTime, shift.endTime) : 0); }, 0); });
     return { id: u.id, name: u.name, weekly, total: weekly.reduce((a,b)=>a+b,0) };
  }).filter(u => u.total > 0);

  return (
    <div className="space-y-4 pb-12 w-full">

{/* MANAGER EXPLANATION BANNER */}
      {timeOffRequests.filter(r => r.status === 'pending' && r.date.startsWith(monthStr)).length > 0 && (
        <div className="bg-red-900/20 border border-red-500/50 p-4 rounded-xl flex items-center justify-between gap-4 shadow-lg animate-[slideIn_0.2s_ease-out]">
          <div className="flex items-center gap-3">
            <Shield className="text-red-500 flex-shrink-0 animate-pulse" size={24} />
            <div>
              <h3 className="text-red-400 font-black text-sm uppercase tracking-widest">Action Required</h3>
              <p className="text-xs text-red-200/80 font-medium mt-0.5">
                You have pending time-off requests this month. Go to <strong className="text-white">My Shift {'->'} Request Off</strong> to approve them in the Master Override Log.
              </p>
            </div>
          </div>
        </div>
      )}

    
      {/* --- AUTO POPULATE MODAL --- */}
      <Modal isOpen={isAutoPopulateModalOpen} onClose={() => setIsAutoPopulateModalOpen(false)} title="Auto-Populate Schedule">
        <div className="space-y-4">
          <p className="text-xs text-slate-300 font-bold leading-relaxed">
            Select a previous month to copy shifts from. <br/><br/>
            <span className="text-[#D4A381]">Smart Mapping:</span> Days will automatically align to match the correct day of the week (e.g. 1st Monday to 1st Monday). All copied shifts will be added as unpublished drafts.
          </p>
          <div>
            <label className={T.label}>Source Month</label>
            <input type="month" value={autoPopSourceMonth} onChange={e=>setAutoPopSourceMonth(e.target.value)} className={T.input} />
          </div>
          <button onClick={handleAutoPopulate} className={`w-full ${T.btn} py-3`}>Copy Schedule</button>
        </div>
      </Modal>

      <Modal isOpen={isEventModalOpen} onClose={()=>setIsEventModalOpen(false)} title={editingEventId ? "Edit Special Event" : "Add Special Event"}>
        <form onSubmit={handleAddEvent} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div><label className={T.label}>Date</label><input type="date" value={eventDate} onChange={e=>setEventDate(e.target.value)} className={T.input} required/></div>
         <div>
              <label className={T.label}>Time (Optional)</label>
              <input type="time" value={eventTime} onChange={e=>setEventTime(e.target.value)} className={T.input}/>
            </div>
          </div>
<div><label className={T.label}>Event Title</label><input type="text" value={eventTitle} onChange={e=>setEventTitle(e.target.value)} className={T.input} placeholder="e.g., Packers Playoff Game" required/></div>
        
        {!editingEventId && (
          <div className="bg-[#12161A] p-3 rounded-xl border border-[#2A353D]">
            <label className="flex items-center gap-2 text-xs font-bold text-slate-300 cursor-pointer mb-2">
              <input type="checkbox" checked={isRepeating} onChange={e => setIsRepeating(e.target.checked)} className="w-4 h-4 rounded bg-[#1A2126] border-[#2A353D] accent-[#8F6040]" />
              Make this a repeating event
            </label>
            
            {isRepeating && (
              <div className="grid grid-cols-2 gap-3 mt-3 animate-[slideIn_0.2s_ease-out]">
                <div>
                  <label className={T.label}>Repeats Every</label>
                  <select value={repeatType} onChange={e => setRepeatType(e.target.value)} className={T.input}>
                    <option value="daily">Day</option>
                    <option value="weekly">Week</option>
                    <option value="bi-weekly">Two Weeks</option>
                    <option value="monthly">Month</option>
                    <option value="yearly">Year</option>
                  </select>
                </div>
                <div>
                  <label className={T.label}>Until Date</label>
                  <input type="date" min={eventDate} value={repeatUntil} onChange={e => setRepeatUntil(e.target.value)} className={T.input} required={isRepeating} />
                </div>
              </div>
            )}
          </div>
        )}

          <div>
            <label className={T.label}>Notes & Photo (Optional)</label>
            <textarea rows="2" value={eventNotes} onChange={e=>setEventNotes(e.target.value)} className={`${T.input} mb-2`} placeholder="Extra details..."/>
            
            {eventImageFile && (
              <div className="text-xs text-emerald-400 font-bold bg-emerald-900/20 p-2 rounded-lg border border-emerald-900/50 flex justify-between items-center mb-2">
                <span className="truncate pr-2">📷 {eventImageFile.name} attached</span>
                <button type="button" onClick={()=>setEventImageFile(null)} className="text-red-400 hover:text-red-300 p-1"><X size={14}/></button>
              </div>
            )}
            
            <div className="flex flex-wrap sm:flex-nowrap gap-2 items-center w-full">
              <div className={`flex flex-1 sm:flex-none bg-[#12161A] border border-[#2A353D] rounded-xl overflow-hidden shadow-sm h-12 ${isEventUploading ? 'opacity-50 pointer-events-none' : ''}`}>
                 <label className="flex-1 sm:w-16 flex items-center justify-center cursor-pointer hover:bg-[#1A2126] transition-colors border-r border-[#2A353D] text-[#D4A381]" title="Take Photo">
                    <Camera size={20} />
                    <input type="file" accept="image/*" capture="environment" onChange={(e) => setEventImageFile(e.target.files[0])} className="hidden" disabled={isEventUploading} />
                 </label>
                 <label className="flex-1 sm:w-20 flex items-center justify-center cursor-pointer hover:bg-[#1A2126] transition-colors text-[#D4A381]" title="Upload Photo">
                    <span className="text-[10px] font-black uppercase tracking-wider">Upload</span>
                    <input type="file" accept="image/*" onChange={(e) => setEventImageFile(e.target.files[0])} className="hidden" disabled={isEventUploading} />
                 </label>
              </div>
              <button type="submit" disabled={isEventUploading || !eventTitle.trim()} className={`flex-1 sm:flex-1 ${T.btn} h-12 disabled:opacity-50 flex items-center justify-center`}>
                {isEventUploading ? <Loader2 className="animate-spin" size={20}/> : (editingEventId ? 'Update Event' : 'Save Event')}
              </button>
            </div>
          </div>
        </form>
      </Modal>

<Modal isOpen={isPunchModalOpen} onClose={()=>setIsPunchModalOpen(false)} title={editingPunch ? `Edit Punch: ${editingPunch?.employeeName}` : "Add Missing Time Punch"}>
        <form onSubmit={handleSavePunchEdit} className="space-y-4 max-h-[70vh] overflow-y-auto custom-scrollbar pr-2">
          {!editingPunch && (
            <div>
              <label className={T.label}>Select Employee</label>
              <select value={editPunchEmpId} onChange={e=>setEditPunchEmpId(e.target.value)} className={T.input} required>
                <option value="">-- Select Staff Member --</option>
                {users.filter(u => u.isActive !== false).sort((a,b) => a.name.localeCompare(b.name)).map(u => (
                  <option key={u.id} value={u.id}>{u.name}</option>
                ))}
              </select>
            </div>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className={T.label}>Clock In Time</label>
              <input type="datetime-local" value={editPunchIn} onChange={e=>setEditPunchIn(e.target.value)} className={T.input} required/>
            </div>
            <div>
              <label className={T.label}>Clock Out Time (Leave blank if currently on clock)</label>
              <input type="datetime-local" value={editPunchOut} onChange={e=>setEditPunchOut(e.target.value)} className={T.input}/>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className={T.label}>Break (Mins)</label>
              <input type="number" min="0" value={editBreakMins} onChange={e=>setEditBreakMins(e.target.value)} className={T.input}/>
            </div>
            <div>
              <label className={T.label}>Cash Tips ($)</label>
              <input type="number" step="0.01" min="0" value={editCash} onChange={e=>setEditCash(e.target.value)} className={T.input}/>
            </div>
            <div>
              <label className={T.label}>Credit Tips ($)</label>
              <input type="number" step="0.01" min="0" value={editCredit} onChange={e=>setEditCredit(e.target.value)} className={T.input}/>
            </div>
          </div>
          <button type="submit" className={`w-full ${T.btn}`}>{editingPunch ? 'Save Changes' : 'Create Time Punch'}</button>
        </form>
      </Modal>

      {/* --- PRESET MANAGER MODAL --- */}
      <Modal isOpen={isPresetModalOpen} onClose={() => { setIsPresetModalOpen(false); cancelPresetEdit(); }} title="Manage Custom Shifts">
        <div className="space-y-4 max-h-[60vh] overflow-y-auto custom-scrollbar pr-2 pb-10">
            <form id="preset-modal-form" onSubmit={handleSavePreset} className="space-y-3 p-4 bg-[#1A2126] border border-[#2A353D] rounded-xl">
                <div className="flex justify-between items-center">
                    <h4 className="text-sm font-black text-[#D4A381] uppercase tracking-widest">{editingPresetId ? 'Edit Preset' : 'Add New Preset'}</h4>
                    {editingPresetId && <button type="button" onClick={cancelPresetEdit} className="text-xs font-bold text-slate-400 hover:text-white transition-colors">Cancel ✖</button>}
                </div>
                <div>
                    <label className={T.label}>Label (e.g., "Mid Shift 12p-5p")</label>
                    <input type="text" value={newPresetLabel} onChange={e=>setNewPresetLabel(e.target.value)} className={T.input} required />
                </div>
                <div className="grid grid-cols-2 gap-3">
                    <div>
                        <label className={T.label}>Start Time</label>
                        <select value={newPresetStart} onChange={e=>setNewPresetStart(e.target.value)} className={T.input} required>
                          {TIME_OPTIONS.map(t => <option key={t} value={t}>{formatShortTime(t)}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className={T.label}>End Time</label>
                        <select value={newPresetEnd} onChange={e=>setNewPresetEnd(e.target.value)} className={T.input} required>
                          {TIME_OPTIONS.map(t => <option key={t} value={t}>{formatShortTime(t)}</option>)}
                        </select>
                    </div>
                </div>
                <button type="submit" className={`w-full ${T.btn} py-3 text-sm flex items-center justify-center`}><Plus size={18} className="inline mr-2"/> {editingPresetId ? 'Update Preset' : 'Save Custom Time'}</button>
            </form>

            <div className="space-y-2 pt-2">
                <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest border-b border-[#2A353D] pb-2">Your Custom Shifts</h4>
                {customPresets.length === 0 && <p className="text-xs font-bold text-slate-500 text-center p-4 border border-dashed border-[#2A353D] rounded-xl">No custom times added yet.</p>}
                {customPresets.map(preset => (
                    <div key={preset.id} className="flex justify-between items-center bg-[#12161A] p-3 rounded-lg border border-[#2A353D]">
                        <div>
                            <div className="font-bold text-base text-white">{preset.label}</div>
                            <div className="text-xs font-mono font-bold text-[#D4A381]">{formatShortTime(preset.start)} - {formatShortTime(preset.end)}</div>
                        </div>
                        <div className="flex items-center gap-1 border-l border-[#2A353D] pl-2 ml-2">
                            <button type="button" onClick={() => handleEditPreset(preset)} className="p-2 text-slate-400 hover:text-[#D4A381] transition-colors bg-[#1A2126] rounded border border-[#2A353D]">
                                <Edit size={16}/>
                            </button>
                            <button type="button" onClick={() => handleDeletePreset(preset.id)} className="p-2 text-slate-400 hover:text-red-500 transition-colors bg-[#1A2126] rounded border border-[#2A353D]">
                                <Trash2 size={16}/>
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      </Modal>

{/* TOP NAVIGATION TOGGLE */}
      {!hideSubTabs && (
        <div className="flex flex-wrap gap-2 border-b border-[#2A353D] pb-3 mb-4">
          <button onClick={() => setSubTab('schedule')} className={`px-4 py-2 text-[10px] sm:text-xs font-black rounded-xl uppercase tracking-widest transition-all ${subTab === 'schedule' ? `${T.grad} text-slate-900 shadow-md` : 'bg-[#1A2126] text-slate-400 hover:text-white'}`}>Schedule Maker</button>
          {appUser?.isAdmin && (
            <button onClick={() => {
              if (appUser?.planType === 'Starter' || appUser?.planType === 'Pro') return addToast('Locked', 'Upgrade to Elite to unlock Timesheets & Labor.');
              setSubTab('timesheets');
            }} className={`px-4 py-2 text-[10px] sm:text-xs font-black rounded-xl uppercase tracking-widest transition-all ${subTab === 'timesheets' ? `${T.grad} text-slate-900 shadow-md` : 'bg-[#1A2126] text-slate-400 hover:text-white'} ${(appUser?.planType === 'Starter' || appUser?.planType === 'Pro') ? 'opacity-50 cursor-not-allowed border border-[#2A353D]' : ''}`}>
              {(appUser?.planType === 'Starter' || appUser?.planType === 'Pro') ? '🔒 Timesheets (Elite)' : 'Timesheets & Labor'}
            </button>
          )}
        </div>
      )}

      {subTab === 'schedule' && (
        <div className="space-y-6 animate-[slideIn_0.2s_ease-out]">
          
          <div className={`${T.card} p-3 sm:p-4 flex flex-col 2xl:flex-row gap-3 items-center justify-between`}>
            <div className="flex flex-wrap xl:flex-nowrap gap-3 w-full 2xl:w-auto items-center">
              
              {/* Staff Selector */}
              <select value={selectedEmp} onChange={e=>{setSelectedEmp(e.target.value); setAssignDates([]);}} className={`${T.input} w-full sm:w-auto sm:flex-1 xl:w-40 py-2.5 px-3 text-sm font-bold h-12 shadow-inner shrink-0`}>
                <option value="">-- Select Staff --</option>
                {displayUsers.map(u=><option key={u.id} value={u.id}>{u.name}</option>)}
              </select>
              
              {/* Preset Selector & Edit Button */}
              <div className="flex gap-2 items-center w-full sm:w-auto sm:flex-1 xl:w-auto shrink-0">
                <select value={presetShift} onChange={handlePresetChange} className={`${T.input} w-full py-2.5 px-3 text-sm font-bold h-12 shadow-inner`}>
                  {SHIFT_PRESETS.map(p=><option key={p.label} value={p.label}>{p.label}</option>)}
                </select>
                <button onClick={() => setIsPresetModalOpen(true)} className="px-4 bg-[#12161A] text-slate-400 hover:text-[#D4A381] border border-[#2A353D] rounded-xl transition-colors h-12 flex items-center justify-center shrink-0 shadow-sm" title="Edit Presets">
                  <Edit size={18} />
                </button>
              </div>

        {/* Custom Time Overrides */}
              <div className="flex gap-2 w-full sm:w-auto sm:flex-1 xl:w-auto shrink-0">
                <div className="relative flex-1 xl:w-32">
                    <span className="absolute -top-2.5 left-2 bg-[#1A2126] px-1 text-[9px] font-black text-slate-400 uppercase tracking-widest">In</span>
                    <input type="time" value={startTime} onChange={e=>{setStartTime(e.target.value);setPresetShift('Custom');}} className={`${T.input} w-full py-2.5 px-2 text-sm font-bold h-12 shadow-inner`}/>
                </div>
                <div className="relative flex-1 xl:w-32">
                    <span className="absolute -top-2.5 left-2 bg-[#1A2126] px-1 text-[9px] font-black text-slate-400 uppercase tracking-widest">Out</span>
                    <input type="time" value={endTime} onChange={e=>{setEndTime(e.target.value);setPresetShift('Custom');}} className={`${T.input} w-full py-2.5 px-2 text-sm font-bold h-12 shadow-inner`}/>
                </div>
              </div>

              {/* Assign Button */}
              <button onClick={handleAssign} disabled={!selectedEmp||assignDates.length===0} className={`w-full xl:w-auto ${T.btn} py-2.5 px-6 text-sm h-12 disabled:opacity-50 flex items-center justify-center shadow-lg shrink-0 whitespace-nowrap`}>Assign ({assignDates.length})</button>

            </div>
            
            {/* Action Row */}
            <div className="flex w-full 2xl:w-auto gap-2 items-center pt-3 2xl:pt-0 border-t 2xl:border-t-0 border-[#2A353D]">
              <div className="hidden sm:flex flex-col items-end mr-3 bg-[#12161A] border border-[#2A353D] px-4 py-1.5 rounded-xl">
                <span className="text-[9px] font-black uppercase tracking-widest text-slate-500">Proj. Month Labor</span>
                <span className="text-emerald-400 font-black text-base">${projectedMonthLabor.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
              </div>
<button onClick={() => {
                if (appUser?.planType === 'Starter' || appUser?.planType === 'Pro') return addToast('Locked', 'Upgrade to Elite to use Smart Auto-Fill.');
                setIsAutoPopulateModalOpen(true);
              }} className={`flex-1 2xl:flex-none ${T.btnAlt} py-2.5 h-12 flex items-center justify-center font-black ${(appUser?.planType === 'Starter' || appUser?.planType === 'Pro') ? 'opacity-50 text-slate-500 border-[#2A353D]' : 'border-blue-900/50 text-blue-400'}`}>
                <Repeat size={16} className="mr-1"/> {(appUser?.planType === 'Starter' || appUser?.planType === 'Pro') ? '🔒 Auto-Fill' : 'Auto-Fill'}
              </button>              <button onClick={handlePublish} className={`flex-1 2xl:flex-none ${T.btnAlt} py-2.5 h-12 flex items-center justify-center font-black`}>Publish</button>
              <button onClick={openNewEventModal} className={`flex-1 2xl:flex-none ${T.btnAlt} border-[#D4A381] text-[#D4A381] py-2.5 h-12 flex items-center justify-center font-black`}><Plus size={16} className="mr-1"/> Event</button>
            </div>
          </div>

          <div className={`${T.card} w-full overflow-hidden`}>
            <div className="overflow-x-auto w-full no-scrollbar">
              <table className="w-full text-left text-[10px] border-collapse table-fixed min-w-[1200px] xl:min-w-full">
                <thead>
                  <tr className="bg-[#12161A] border-b border-[#2A353D]">
                    <th className={`p-1 sm:p-2 font-bold bg-[#12161A] sticky left-0 z-20 w-16 sm:w-24 border-r border-[#2A353D] ${T.copper} truncate`}>Staff</th>
                    {monthDays.map(d => {
                      const holiday = getHoliday(d);
                      const dayEvents = monthEvents.filter(e => e.date === d);
                      const hasAlert = holiday || dayEvents.length > 0;
                      
                      return (
                      <th key={d} className={`p-0.5 sm:p-1 text-center border-r border-[#2A353D] align-top relative group cursor-help ${new Date(d+'T12:00').getDay()%6===0?'bg-[#1A2126]':''}`}>
                        <div className={`font-bold uppercase text-[8px] sm:text-[9px] ${T.muted}`}>{new Date(d+'T12:00').toLocaleDateString('en-US',{weekday:'narrow'})}</div>
                        <div className={`text-xs sm:text-sm font-black mt-0.5 ${hasAlert ? (holiday ? 'text-amber-400' : 'text-red-400') : 'text-white'}`}>
                          {parseInt(d.split('-')[2])}
                        </div>
                        
                        {hasAlert && (
                          <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 w-32 bg-[#1A2126] border border-[#D4A381] text-white text-[10px] p-2 rounded shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible z-50 pointer-events-none transition-all">
                            {holiday && <div className="text-amber-400 font-black mb-1 leading-tight">{holiday}</div>}
                            {dayEvents.map(ev => (
                              <div key={ev.id} className="text-red-400 font-bold leading-tight mt-1 border-t border-[#2A353D] pt-1">
                                {ev.title} {ev.time && <span className="block text-white opacity-80">{formatShortTime(ev.time)}</span>}
                                {ev.notes && <span className="block text-slate-300 font-normal mt-0.5">{ev.notes}</span>}
                              </div>
                            ))}
                          </div>
                        )}
                      </th>
                    )})}
                  </tr>
                </thead>
              <tbody className="divide-y divide-[#2A353D]">
                  {sortedRoles.map(role => (
                    <React.Fragment key={`role-group-${role}`}>
                      <tr className="bg-[#1A2126]">
                        <td colSpan={monthDays.length + 1} className={`px-2 py-1 text-[9px] font-black uppercase tracking-widest ${T.copper} border-b border-[#2A353D] sticky left-0 z-10`}>
                          {role}
                        </td>
                      </tr>
                      {groupedUsers[role].sort((a,b) => (a.name||'').localeCompare(b.name||'')).map(u => (
                        <tr key={u.id} className={selectedEmp===u.id?'bg-[#12161A]/50':''}>
                          <td onClick={()=>{setSelectedEmp(u.id);setAssignDates([]);}} className={`px-2 py-1 text-xs font-bold sticky left-0 z-10 border-r border-[#2A353D] cursor-pointer truncate shadow-sm ${selectedEmp===u.id?`${T.grad} text-slate-900`:'bg-[#1A2126] text-white'}`}>{u.name.split(' ')[0]}</td>
                          {monthDays.map(d => {
                            const shift = monthShifts.find(s=>s.date===d&&s.employeeId===u.id); 
                            const req = timeOffRequests.find(r=>r.date===d&&r.userId===u.id && r.status !== 'pending'); 
                            const sel = assignDates.includes(d) && selectedEmp===u.id;

                            // Conflict Check: Alert if a shift overlaps with ANY time-off request (pending or approved)
                            const allUserReqs = timeOffRequests.filter(r => r.date === d && r.userId === u.id);
                            const hasConflict = shift && allUserReqs.some(r => {
                               if (!r.isPartial) return true; // Full day off conflict
                               return (shift.startTime < (r.endTime || '23:59')) && (shift.endTime > (r.startTime || '00:00'));
                            });

                            return (
                            <td key={d} onClick={()=>handleCellClick(d,u.id)} className={`p-0.5 border-r border-[#2A353D] cursor-pointer transition-all align-top h-7 sm:h-8 ${sel?'bg-[#8F6040] outline outline-2 outline-[#D4A381] shadow-inner z-0 relative':'hover:bg-[#12161A]'}`}>
                            <div className="flex flex-col gap-[1px] w-full justify-start overflow-hidden">
                              {req && !req.isPartial && <div className="w-full rounded font-black text-[7px] sm:text-[8px] py-0.5 text-center text-red-400 bg-red-900/40 uppercase tracking-tighter" title="Requested Off">Off</div>}
                              {req && req.isPartial && <div className="w-full rounded font-black text-[7px] sm:text-[8px] py-0.5 text-center text-amber-400 bg-amber-900/40 uppercase tracking-tighter truncate" title={`Off: ${formatShortTime(req.startTime)}-${formatShortTime(req.endTime)}`}>{formatShortTime(req.startTime)}-{formatShortTime(req.endTime)}</div>}
                              {shift && (
                                <div 
                                  className={`w-full rounded font-bold text-[7px] sm:text-[8px] py-0.5 text-center truncate ${getRoleColors(shift.role, shift.isPublished)} ${hasConflict ? 'border-2 border-red-500 animate-pulse shadow-[0_0_8px_rgba(239,68,68,0.8)]' : ''}`} 
                                  title={`${formatShortTime(shift.startTime)} - ${formatShortTime(shift.endTime)} ${hasConflict ? '(CONFLICT DETECTED)' : ''}`}
                                >
                                  {formatShortTime(shift.startTime)}-{formatShortTime(shift.endTime)}
                                </div>
                              )}
                            </div>
                          </td>)
                          })}
                        </tr>
                      ))}
                    </React.Fragment>
                  ))}
                  <tr className="bg-[#0B0E11] border-t-2 border-[#D4A381]/30">
                    <td className={`px-2 py-2 text-[8px] font-black uppercase tracking-widest text-[#D4A381] sticky left-0 z-10 border-r border-[#2A353D] text-right shadow-md`}>
                      Proj. Cost
                    </td>
                    {monthDays.map(d => (
                      <td key={`cost-${d}`} className={`p-1 border-r border-[#2A353D] text-center align-middle font-black text-[9px] sm:text-[10px] ${projectedDailyLabor[d] > 0 ? 'text-emerald-400' : 'text-slate-600'}`}>
                        ${projectedDailyLabor[d].toFixed(0)}
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          
          <div className={`${T.card} overflow-hidden mt-6`}>
            <div className={`bg-[#12161A] p-4 border-b ${T.border} flex justify-between items-center`}>
              <h3 className={`font-black text-sm flex items-center gap-2 ${T.copper}`}><Clock className={T.copper} size={16}/> Scheduled Hours Tracker</h3>
              <span className={`text-[9px] font-bold ${T.muted} uppercase tracking-widest`}>OT Threshold: {appUser?.systemSettings?.overtime || 40}h</span>
            </div>
            <div className="overflow-x-auto no-scrollbar">
              <table className="w-full text-left text-xs border-collapse min-w-[600px]">
                <thead>
                  <tr className="bg-[#1A2126] border-b border-[#2A353D] text-[9px] font-black uppercase tracking-widest text-slate-400">
                    <th className="p-3 border-r border-[#2A353D] sticky left-0 bg-[#1A2126] z-10 w-24">Employee</th>
                    {weeksInMonth.map((w, i) => <th key={i} className="p-3 text-center border-r border-[#2A353D]">Wk {i+1}<div className="text-[7px] text-slate-600 mt-0.5">{parseInt(w[0].split('-')[2])}-{parseInt(w[w.length-1].split('-')[2])}</div></th>)}
                    <th className="p-3 text-center text-[#D4A381]">Month Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#2A353D]">
                  {scheduledHours.length === 0 && <tr><td colSpan={weeksInMonth.length + 2} className="p-6 text-center text-slate-500 font-bold">No hours scheduled yet.</td></tr>}
                  {scheduledHours.map(u => (
                    <tr key={u.id} className="hover:bg-[#12161A]/50 transition-colors">
                      <td className="p-3 font-bold text-white border-r border-[#2A353D] sticky left-0 bg-[#1A2126] z-10 truncate">{u.name.split(' ')[0]}</td>
                      {u.weekly.map((hrs, i) => (
                        <td key={i} className={`p-3 text-center font-black border-r border-[#2A353D] ${hrs > parseFloat(appUser?.systemSettings?.overtime || 40) ? 'text-red-500 bg-red-900/10' : hrs > 0 ? 'text-emerald-400' : 'text-slate-600'}`}>
                          {hrs > 0 ? hrs.toFixed(1) : '-'}
                        </td>
                      ))}
                      <td className="p-3 text-center font-black text-[#D4A381] bg-[#12161A]/30">{u.total.toFixed(1)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

{/* --- THE NEW EVENTS LEDGER SUB-TAB --- */}
      {subTab === 'events' && (
        <div className="animate-[slideIn_0.2s_ease-out] space-y-6">
          
          {/* INTERACTIVE CALENDAR */}
          <div className={`${T.card} overflow-hidden shadow-2xl`}>
            <div className={`bg-[#12161A] p-3 border-b ${T.border} flex justify-between items-center`}>
              <button onClick={() => changeEventsMonth(-1)} className={T.btnAlt}><ChevronLeft size={16}/></button>
              <h3 className="font-black text-base text-white tracking-tight">{formatDisplayMonth(eventsCalMonth)}</h3>
              <button onClick={() => changeEventsMonth(1)} className={T.btnAlt}><ChevronRight size={16}/></button>
            </div>
            <div className={`grid grid-cols-7 border-t ${T.border}`}>
              {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d=><div key={d} className={`py-1.5 text-center text-[9px] font-black ${T.copper} uppercase border-b border-[#2A353D] bg-[#12161A]`}>{d}</div>)}
              {Array.from({length: eventsFirstDayOffset}).map((_,i) => <div key={`empty-${i}`} className={`p-1 border-b border-r ${T.border} bg-[#1A2126] min-h-[45px]`} />)}
              {eventsMonthDays.map(d => {
                const holiday = getHoliday(d);
                const dayEvents = eventsCalEvents.filter(e => e.date === d);

                return (
                  <div key={d} onClick={() => {
                    setEventDate(d); setEventTime(''); setEventTitle(''); setEventNotes(''); setEditingEventId(null); setEventImageFile(null); setIsEventModalOpen(true);
                  }} className={`p-1 border-b border-r ${T.border} min-h-[70px] flex flex-col items-center justify-start pt-1 transition-colors hover:bg-[#12161A]/50 cursor-pointer group`}>
                    <span className={`text-xs font-black ${d === getToday() ? T.copper : 'text-slate-300'}`}>{parseInt(d.split('-')[2])}</span>
                    
                    {holiday && <span className="text-[6px] sm:text-[7px] text-amber-500 font-bold uppercase text-center leading-tight mt-0.5 px-0.5">{holiday}</span>}
                    {dayEvents.map(ev => (
                      <span key={ev.id} className="text-[6px] sm:text-[7px] text-blue-400 font-bold uppercase text-center leading-tight mt-1 px-1 py-0.5 w-full truncate bg-blue-900/20 border border-blue-900/50 rounded" title={ev.title}>
                        {ev.time ? `${formatShortTime(ev.time)} ` : ''}{ev.title}
                      </span>
                    ))}
                    <div className="mt-auto pt-1 opacity-0 group-hover:opacity-100 text-[8px] text-slate-500 font-bold uppercase transition-opacity pb-1">
                      + Add
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          <div className="flex justify-between items-end">
             <h3 className={`font-black text-lg flex items-center gap-2 ${T.copper}`}><Star className={T.copper}/> Events Ledger</h3>
             <button onClick={openNewEventModal} className={`${T.btn} flex items-center justify-center gap-2 py-2 px-4 text-xs`}><Plus size={14}/> Add Event</button>
          </div>

          <div className={`${T.card} overflow-hidden`}>
            <div className={`divide-y ${T.border}`}>
              {eventsCalEvents.length === 0 && <div className={`p-6 text-center text-sm font-bold ${T.muted}`}>No special events scheduled this month.</div>}
              {eventsCalEvents.sort((a,b) => (a.date || '').localeCompare(b.date || '')).map(ev => (
                <div key={ev.id} className={`${T.row} flex flex-col sm:flex-row justify-between sm:items-center gap-4`}>
                  <div className="flex items-start sm:items-center gap-4">
                    <div className={`bg-[#12161A] border ${T.border} ${T.copper} font-black text-center rounded-xl p-2 w-14 shadow-sm flex-shrink-0`}>
                      <div className="text-[10px] uppercase">{new Date(ev.date+'T12:00').toLocaleDateString('en-US',{month:'short'})}</div><div className="text-lg leading-tight">{parseInt(ev.date.split('-')[2])}</div>
                    </div>
                  <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-white">{ev.title} {ev.time && <span className="text-[#D4A381] ml-2">@ {formatShortTime(ev.time)}</span>}</h4>
                      {ev.notes && <p className="text-xs text-slate-300 mt-1 font-medium bg-[#12161A] p-2 rounded-lg border border-[#2A353D] whitespace-pre-wrap">{ev.notes}</p>}
                      {ev.imageUrl && (
                        <div className="mt-2 overflow-hidden rounded-xl border border-[#2A353D] shadow-inner bg-[#0B0E11] max-w-sm">
                          <img src={ev.imageUrl} alt="Attached" className="w-full max-h-48 object-contain" />
                        </div>
                      )}
                      <span className={`text-[10px] font-bold ${T.muted} block mt-1`}>Added by {ev.addedBy}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 sm:self-end self-start">
                    <button onClick={() => openEditEventModal(ev)} className="p-2 text-slate-400 hover:text-[#D4A381] transition-colors bg-[#12161A] rounded-lg border border-[#2A353D]"><Edit size={14}/></button>
                    <button onClick={() => { if(window.confirm("Delete event?")) deleteDoc(doc(db,"events",ev.id)); }} className="p-2 text-slate-400 hover:text-red-500 transition-colors bg-[#12161A] rounded-lg border border-[#2A353D]"><Trash2 size={14}/></button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

{/* THE TIMESHEET SUB-TAB (Secured & Safed) */}
      {subTab === 'timesheets' && appUser?.isAdmin && (
        <div className={`${T.card} overflow-hidden animate-[slideIn_0.2s_ease-out]`}>
          
          <div className={`bg-[#12161A] p-4 border-b ${T.border} flex flex-col md:flex-row justify-between md:items-center gap-4`}>
            <div className="flex items-center gap-4 flex-wrap">
              <h3 className={`font-black text-lg flex items-center gap-2 ${T.copper}`}>Payroll</h3>
              <div className="flex items-center gap-2 bg-[#1A2126] border border-[#2A353D] p-1.5 rounded-lg shadow-inner">
                 <input type="date" value={periodStart} onChange={e=>setPeriodStart(e.target.value)} className="bg-transparent text-[#D4A381] text-xs font-bold outline-none cursor-pointer" />
                 <span className="text-slate-500 font-black text-[10px] uppercase">to</span>
                 <input type="date" value={periodEnd} onChange={e=>setPeriodEnd(e.target.value)} className="bg-transparent text-[#D4A381] text-xs font-bold outline-none cursor-pointer" />
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <button onClick={openAddPunchModal} className="bg-[#1A2126] border border-[#2A353D] text-slate-300 font-bold px-3 py-1.5 rounded-lg text-xs hover:text-[#D4A381] transition-colors flex items-center gap-2"><Plus size={14}/> Add Punch</button>
              <button onClick={handleExportTimesheets} className="bg-[#1A2126] border border-[#2A353D] text-slate-300 font-bold px-3 py-1.5 rounded-lg text-xs hover:text-emerald-400 transition-colors flex items-center gap-2">📋 Export CSV</button>
              <div className="bg-[#1A2126] border border-[#2A353D] px-3 py-1.5 rounded-lg flex flex-col items-end shadow-sm">
                <span className="text-[8px] font-black uppercase tracking-widest text-slate-500">Period Labor</span>
                <span className="text-emerald-400 font-black text-sm">${actualPeriodLabor.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
              </div>
            </div>
          </div>

{/* TARGETS DASHBOARD */}
          {appUser?.systemSettings?.enableTargets && (
            <div className="bg-[#0B0E11] p-4 border-b border-[#2A353D] flex flex-col sm:flex-row gap-4 justify-between items-center">
              <div className="flex items-center gap-6">
                 <div>
                   <div className="text-[10px] font-black uppercase tracking-widest text-slate-500">Target Period Sales</div>
                   <div className="text-lg font-black text-white">${parseFloat(appUser.systemSettings.targetSales || 0).toLocaleString()}</div>
                 </div>
                 <div>
                   <div className="text-[10px] font-black uppercase tracking-widest text-slate-500">Target Labor %</div>
                   <div className="text-lg font-black text-white">{parseFloat(appUser.systemSettings.targetLaborPct || 0).toFixed(1)}%</div>
                 </div>
                 <div className="border-l border-[#2A353D] pl-6">
                   <div className="text-[10px] font-black uppercase tracking-widest text-slate-500">Actual Period Labor %</div>
                   <div className={`text-lg font-black ${((actualPeriodLabor / parseFloat(appUser.systemSettings.targetSales || 1)) * 100) > parseFloat(appUser.systemSettings.targetLaborPct || 100) ? 'text-red-400' : 'text-emerald-400'}`}>
                     {appUser.systemSettings.targetSales > 0 ? ((actualPeriodLabor / parseFloat(appUser.systemSettings.targetSales)) * 100).toFixed(1) : '0.0'}%
                   </div>
                 </div>
              </div>
              <button onClick={() => setIsTargetSettingsOpen(!isTargetSettingsOpen)} className="text-xs font-bold text-slate-400 hover:text-[#D4A381] border border-[#2A353D] bg-[#1A2126] px-3 py-1.5 rounded-lg transition-colors">Configure Targets</button>
            </div>
          )}

          {!appUser?.systemSettings?.enableTargets && (
            <div className="bg-[#0B0E11] p-3 border-b border-[#2A353D] text-right">
              <button onClick={() => setIsTargetSettingsOpen(!isTargetSettingsOpen)} className="text-xs font-bold text-slate-400 hover:text-[#D4A381] transition-colors">Configure Financial Targets</button>
            </div>
          )}

          {isTargetSettingsOpen && (
            <form onSubmit={handleSaveTargets} className="p-4 bg-[#1A2126] border-b border-[#2A353D] space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className={T.label}>Period Sales Target ($)</label>
                  <input type="number" step="0.01" value={targetSales} onChange={e=>setTargetSales(e.target.value)} className={T.input} placeholder="e.g. 50000" />
                </div>
                <div>
                  <label className={T.label}>Target Labor Cost (%)</label>
                  <input type="number" step="0.1" value={targetLaborPct} onChange={e=>setTargetLaborPct(e.target.value)} className={T.input} placeholder="e.g. 25.5" />
                </div>
              </div>
              <div className="flex gap-2">
                 <button type="submit" className={`flex-1 ${T.btn} py-2 text-xs`}>Save Targets</button>
                 <button type="button" onClick={async () => { await updateDoc(doc(db, "restaurants", appUser.restaurantId), { 'systemSettings.enableTargets': false }); setIsTargetSettingsOpen(false); }} className={`px-4 bg-red-900/20 text-red-500 font-bold text-xs rounded-xl border border-red-900/50 hover:bg-red-900/40 transition-colors`}>Disable</button>
              </div>
            </form>
          )}

{summaryList.length > 0 && (
            <div className="p-4 border-b border-[#2A353D] bg-[#0B0E11]">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-emerald-400 mb-3">Period Payroll Summary</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {summaryList.map(s => (
                  <div key={s.name} className="bg-[#1A2126] p-3 rounded-xl border border-[#2A353D] flex justify-between items-center shadow-sm hover:border-[#D4A381]/50 transition-colors">
                    <div>
                      <div className="font-bold text-white text-sm">{s.name}</div>
                      <div className="text-[9px] font-black uppercase text-slate-400 tracking-widest mt-0.5">
                        REG: {s.regHours.toFixed(2)}h | OT: {s.otHours.toFixed(2)}h
                      </div>
                      <div className="text-[9px] font-black uppercase text-emerald-500 tracking-widest mt-0.5">
                        TIPS: ${(s.cashTips + s.creditTips).toFixed(2)}
                      </div>
                    </div>
                    <div className="text-[#D4A381] font-black text-lg">${s.pay.toFixed(2)}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TIME PUNCH FILTERS */}
          <div className={`bg-[#12161A] p-3 border-b ${T.border} flex flex-col sm:flex-row gap-3 justify-between sm:items-center`}>
            <h4 className="text-[10px] font-black uppercase tracking-widest text-[#D4A381]">Filter Punches</h4>
            <div className="flex flex-wrap gap-2 w-full sm:w-auto">
              <input type="date" value={punchFilterDate} onChange={e => setPunchFilterDate(e.target.value)} className={`${T.input} py-1.5 px-2 text-xs w-auto flex-1 sm:flex-none`} />
              <select value={punchFilterEmp} onChange={e => setPunchFilterEmp(e.target.value)} className={`${T.input} py-1.5 px-2 text-xs w-auto flex-1 sm:flex-none`}>
                <option value="">All Staff</option>
                {users.filter(u => u.isActive !== false).sort((a,b) => a.name.localeCompare(b.name)).map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
              </select>
              {(punchFilterDate || punchFilterEmp) && <button onClick={() => { setPunchFilterDate(''); setPunchFilterEmp(''); }} className="p-1.5 text-slate-400 hover:text-red-400 border border-[#2A353D] bg-[#1A2126] rounded-lg transition-colors"><X size={14}/></button>}
            </div>
          </div>

          <div className={`divide-y ${T.border}`}>
            {periodPunches.filter(p => (punchFilterDate ? p.date === punchFilterDate : true) && (punchFilterEmp ? p.employeeId === punchFilterEmp : true)).length === 0 && <div className={`p-6 text-center text-sm font-bold ${T.muted}`}>No clock-ins found for this selection.</div>}
            
            {periodPunches.filter(p => (punchFilterDate ? p.date === punchFilterDate : true) && (punchFilterEmp ? p.employeeId === punchFilterEmp : true)).sort((a,b) => new Date(b.clockInTime || 0) - new Date(a.clockInTime || 0)).map(p => {
               const emp = users.find(u => u.id === p.employeeId);
               const hours = calculatePunchHours(p.clockInTime, p.clockOutTime, p.breakMinutes || 0);
               const cost = hours * (emp?.wage || 0);
               const isClockedIn = p.status === 'clocked_in' || p.status === 'on_break';
               
               const safeIn = p.clockInTime ? new Date(p.clockInTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : 'ERR';
               const safeOut = isClockedIn ? '---' : (p.clockOutTime ? new Date(p.clockOutTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : 'ERR');
               
               return (
                 <div key={p.id} className={`${T.row} flex flex-col md:flex-row justify-between md:items-center gap-4`}>
                   <div>
<div className="font-bold text-white text-base">
  {p.employeeName || 'Unknown'}
  {p.isUnscheduled && !p.isApproved && <span className="ml-2 text-[8px] bg-amber-500 text-slate-900 px-1.5 py-0.5 rounded-sm uppercase tracking-widest font-black align-middle">Unscheduled</span>}
</div>                     <div className={`text-[10px] font-black uppercase tracking-widest ${T.muted} mt-0.5`}>
                       {p.date ? formatDisplayDate(p.date) : 'Unknown Date'}
                     </div>
                   </div>
                   <div className="flex items-center gap-6">
                     <div className="text-right">
                       <div className="text-xs font-mono text-slate-300">
                         <span className="text-emerald-400">IN:</span> {safeIn}
                       </div>
                       <div className="text-xs font-mono text-slate-300">
                         <span className="text-red-400">OUT:</span> {safeOut}
                       </div>
                     </div>
                     <div className="text-right border-l border-[#2A353D] pl-6 w-24">
                       <div className={`text-sm font-black ${isClockedIn ? 'text-amber-400 animate-pulse' : 'text-white'}`}>{isClockedIn ? 'ON CLOCK' : `${hours.toFixed(2)} hrs`}</div>
                       <div className="text-[10px] font-black text-[#D4A381] uppercase tracking-widest">${cost.toFixed(2)}</div>
                     </div>
                     <div className="flex gap-2 border-l border-[#2A353D] pl-4">
                       {isClockedIn && <button onClick={() => handleForceClockOut(p)} className="px-3 py-1 bg-red-900/20 text-red-500 text-[10px] font-black uppercase rounded-lg border border-red-900/50 hover:bg-red-900/40 transition-colors">Force Out</button>}
    {p.isUnscheduled && !p.isApproved && <button onClick={() => updateDoc(doc(db, "timePunches", p.id), { isApproved: true })} className="px-3 py-1 bg-amber-900/20 text-amber-400 text-[10px] font-black uppercase rounded-lg border border-amber-900/50 hover:bg-amber-900/40 transition-colors animate-pulse">Approve</button>}
                       <button onClick={() => openEditPunchModal(p)} className="p-2 text-slate-400 hover:text-[#D4A381] bg-[#12161A] rounded-lg border border-[#2A353D] transition-colors"><Edit size={14}/></button>
                       <button onClick={() => handleDeletePunch(p.id)} className="p-2 text-slate-400 hover:text-red-500 bg-[#12161A] rounded-lg border border-[#2A353D] transition-colors"><Trash2 size={14}/></button>
                     </div>
                   </div>
                 </div>
               )
            })}
          </div>
        </div>
      )}
    </div>
  );
};

// --- COMPACT MONTH VIEW ---
const TabMonth = ({ currentDate, users, shifts, appUser }) => {
  const [roleFilter, setRoleFilter] = useState('All');
  const uniqueRoles = ['All', ...new Set(users.map(u => u.role).filter(Boolean))].sort();

  const monthStr = getMonthStr(currentDate); 
  const firstDay = new Date(monthStr+'-01T12:00:00').getDay(); 
  const days = getDaysInMonth(monthStr);
  
  // Calculate how many weeks this month spans to perfectly stretch the grid rows on paper
  const totalCells = firstDay + days;
  const weeks = Math.ceil(totalCells / 7);

  return (
    <div className={`${T.card} overflow-hidden print-container`}>
      <style>{`
        @media print {
          @page { size: landscape; margin: 0.25in; }
          body * { visibility: hidden; }
          
          /* Hijack the entire printed page */
          .print-container, .print-container * { visibility: visible; }
          .print-container {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100vw !important;
            height: 100vh !important;
            max-height: 100vh !important;
            display: flex !important;
            flex-direction: column !important;
            background: white !important;
            z-index: 999999 !important;
            padding: 0 !important;
            margin: 0 !important;
            border: none !important;
            box-shadow: none !important;
            overflow: hidden !important; 
            page-break-inside: avoid !important;
          }
          
          .no-print { display: none !important; }
          
          /* The Header */
          .print-header { 
            display: block !important; 
            text-align: center !important; 
            font-size: 22px !important; 
            font-weight: 900 !important; 
            color: black !important; 
            margin-top: 0 !important;
            margin-bottom: 8px !important; 
            text-transform: uppercase !important; 
            height: 30px !important;
          }
          
          /* The Grid - Stretches to fill exact remaining space on the paper */
          .print-grid {
            flex-grow: 1 !important;
            display: grid !important;
            grid-template-rows: 25px repeat(${weeks}, 1fr) !important;
            border-top: 2px solid black !important;
            border-left: 2px solid black !important;
            height: calc(100vh - 45px) !important; /* Math: 100% minus the header
 height to prevent page 2 bleed */
            max-height: calc(100vh - 45px) !important;
            box-sizing: border-box !important;
            page-break-inside: avoid !important;
          }
          
          /* The Cells */
          .cell {
            border-right: 2px solid black !important;
            border-bottom: 2px solid black !important;
            background: white !important;
            color: black !important;
            min-height: 0 !important;
            padding: 3px !important;
            display: flex !important;
            flex-direction: column !important;
            overflow: hidden !important;
          }
          
          .cell-header-text { color: black !important; font-size: 11px !important; font-weight: 900 !important; }
          .cell-date { font-size: 13px !important; font-weight: 900 !important; color: black !important; margin-bottom: 2px !important; }
          
          /* The Shifts */
          .print-shift {
            background: #f8fafc !important;
            color: black !important;
            border: 1px solid #94a3b8 !important;
            border-radius: 4px !important;
            padding: 1px 4px !important;
            font-size: 9px !important;
            font-weight: 900 !important;
            margin-bottom: 2px !important;
            white-space: nowrap !important;
            overflow: hidden !important;
          }
        }
      `}</style>
      
<div className="flex justify-between items-center p-2 no-print border-b border-[#2A353D] bg-[#12161A]">
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 hidden sm:inline">Filter Role:</span>
    <select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)} className="bg-[#1A2126] border border-[#2A353D] text-[#D4A381] text-xs font-bold rounded-lg px-2 py-1.5 outline-none cursor-pointer shadow-inner">
            <option value="All">Whole Schedule</option>
            <option value="ME">My Shifts Only</option>
            {uniqueRoles.filter(r => r !== 'All').map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <button onClick={()=>window.print()} className={T.btnAlt}>🖨️ Print Calendar</button>
      </div>
      
      <div className="hidden print:block print-header">
        86chaos Schedule {roleFilter !== 'All' ? `- ${roleFilter}` : ''}   {formatDisplayMonth(monthStr)}
      </div>

      <div className={`grid grid-cols-7 border-t border-l ${T.border} print-grid`}>
        {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d=><div key={d} className={`p-1 bg-[#12161A] text-center font-black text-[10px] ${T.copper} border-b border-r ${T.border} uppercase cell`}><span className="print-text-dark cell-header-text">{d}</span></div>)}
        
        {Array.from({length:firstDay}).map((_,i)=><div key={`e-${i}`} className={`bg-[#12161A]/50 border-b border-r ${T.border} min-h-[50px] cell`}/>)}
        
{Array.from({length:days}).map((_,i)=>{
          const date = `${monthStr}-${String(i+1).padStart(2,'0')}`; 
          const dayShifts = shifts
            .filter(s => s.date === date && s.isPublished && (roleFilter === 'All' || (roleFilter === 'ME' ? s.employeeId === appUser?.id : s.role === roleFilter)))
            .sort((a, b) => {
              if (a.role !== b.role) return (a.role || '').localeCompare(b.role || '');
              return (a.startTime || '').localeCompare(b.startTime || '');
            });
          return (
            <div key={date} className={`p-0.5 border-b border-r ${T.border} min-h-[50px] flex flex-col cell`}>
              <span className={`text-right text-[9px] font-black ${T.muted} mb-0.5 cell-date`}>{i+1}</span>
              <div className="space-y-0.5 overflow-y-auto no-scrollbar flex-1">
                {dayShifts.map(s=>(
                  <div key={s.id} className={`text-[8px] font-bold px-0.5 rounded leading-tight truncate bg-[#12161A] border ${T.border} ${s.role==='Bartender'?'text-blue-400':'text-orange-400'} print-shift`}>
                    {users.find(u=>u.id===s.employeeId)?.name.split(' ')[0]} {formatShortTime(s.startTime)}-{formatShortTime(s.endTime)}
                  </div>
                ))}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  );
};


// --- PREP, LINE CHECKS & TASKS COMMAND CENTER ---
const TabPrep = ({ currentDate, appUser, setLabelsToPrint }) => {
  const prepItems = useLiveCollection('prepItems', appUser?.restaurantId);
  const tasks = useLiveCollection('tasks', appUser?.restaurantId);
  const [subTab, setSubTab] = useState('prep');
  const [prepDate, setPrepDate] = useState(currentDate);

  // --- USDA Food Safety Standards Engine ---
  const USDA_CATEGORIES = {
    'Cold Holding (≤ 41°F)': { max: 41 },
    'Hot Holding (≥ 135°F)': { min: 135 },
    'Poultry / Reheat (≥ 165°F)': { min: 165 },
    'Ground Meats (≥ 155°F)': { min: 155 },
    'Whole Meats / Fish (≥ 145°F)': { min: 145 }
  };

  const evaluateTemp = (temp, cat) => {
    const rules = USDA_CATEGORIES[cat];
    if (!rules) return 'Unknown';
    const t = parseFloat(temp);
    if (rules.max && t > rules.max) return 'Danger';
    if (rules.min && t < rules.min) return 'Danger';
    return 'Safe';
  };

  // Sync internal prepDate with global currentDate
  useEffect(() => { setPrepDate(currentDate); }, [currentDate]);

  // Permissions
  const canManageLineChecks = appUser?.isAdmin || appUser?.permissions?.team || appUser?.permissions?.prep;

  // Local selection state (Fixes checkboxes staying checked across days)
  const [selectedPreps, setSelectedPreps] = useState([]);

  // Prep Form State
  const [text, setText] = useState(''); 
  const [station, setStation] = useState('Grill'); 
  const dbPrepCats = useLiveCollection('prepCategories', appUser?.restaurantId); 
  const displayStations = dbPrepCats.length > 0 ? dbPrepCats.map(c => c.name).sort() : ['Grill', 'Fry', 'Salad/Cold', 'Expo', 'Prep Table'];
  const [isMaster, setIsMaster] = useState(true);
  
  // Task Form State
  const [taskText, setTaskText] = useState(''); 
  const [taskCat, setTaskCat] = useState('Cleaning'); 
  const [taskFreq, setTaskFreq] = useState('daily');
  const [taskTargetDay, setTaskTargetDay] = useState('Monday'); 
  const [taskTargetDate, setTaskTargetDate] = useState('1');
  const [editingTaskId, setEditingTaskId] = useState(null);

  // Line Check State
  const lineChecks = useLiveCollection('lineCheckItems', appUser?.restaurantId);
  const tempLogs = useLiveCollection('tempLogs', appUser?.restaurantId);
  
  const [lcSearch, setLcSearch] = useState('');
  const [lcName, setLcName] = useState('');
  const [lcCat, setLcCat] = useState('Cold Holding (≤ 41°F)');
  const [temps, setTemps] = useState({});
  const [editLineCheckItem, setEditLineCheckItem] = useState(null);

  // --- PREP LOGIC ---
  const activePrep = prepItems.filter(p => p.date === prepDate || p.isMaster);
  
  const handleAddPrep = async (e) => { 
    e.preventDefault(); 
    if(text.trim()) { 
      await addDoc(collection(db, "prepItems"), { 
        date: isMaster ? 'MASTER' : prepDate, 
        text: text.trim(), 
        station, 
        isCompleted: false, 
        completedDates: {}, 
        isMaster, 
        qty: 1,
        restaurantId: appUser.restaurantId
      }); 
      setText(''); 
    } 
  };
  
  const toggleSelection = (id) => {
    setSelectedPreps(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const togglePrepStatus = async (item) => { 
    if (item.isMaster) { 
      const dts = {...(item.completedDates||{})}; 
      if (dts[prepDate]) {
        delete dts[prepDate]; 
      } else {
        dts[prepDate] = appUser.name;
      }
      await updateDoc(doc(db, "prepItems", item.id), { completedDates: dts }); 
    } else { 
      await updateDoc(doc(db, "prepItems", item.id), { isCompleted: !item.isCompleted, completedBy: !item.isCompleted ? appUser.name : null }); 
    } 
  };
  
  const groupedPrep = activePrep.reduce((acc, i) => { const s = i.station || 'General'; if(!acc[s]) acc[s]=[]; acc[s].push(i); return acc; }, {});

  // --- LINE CHECK LOGIC ---
  const handleAddLineCheck = async (e) => {
    e.preventDefault();
    if(lcName.trim()) {
      await addDoc(collection(db, "lineCheckItems"), {
        name: lcName.trim(),
        category: lcCat,
        restaurantId: appUser.restaurantId
      });
      setLcName('');
    }
  };

  const handleSaveLineCheckEdit = async (e) => {
    e.preventDefault();
    await updateDoc(doc(db, "lineCheckItems", editLineCheckItem.id), {
      name: editLineCheckItem.name.trim(),
      category: editLineCheckItem.category
    });
    setEditLineCheckItem(null);
  };

  const handleLogTemp = async (item) => {
    const val = temps[item.id];
    if (!val) return;
    
    const status = evaluateTemp(val, item.category);
    
    await addDoc(collection(db, "tempLogs"), {
      itemId: item.id,
      itemName: item.name,
      category: item.category,
      temp: parseFloat(val),
      status: status,
      loggedBy: appUser.name,
      date: getToday(),
      timestamp: new Date().toISOString(),
      restaurantId: appUser.restaurantId
    });
    
    setTemps({...temps, [item.id]: ''});
  };

  const filteredLineChecks = lineChecks
    .filter(lc => (lc.name || '').toLowerCase().includes(lcSearch.toLowerCase()))
    .sort((a, b) => a.category.localeCompare(b.category));

  // --- TASK LOGIC ---
  const handleAddTask = async (e) => { 
    e.preventDefault(); 
    if(taskText.trim()) { 
      if (editingTaskId) {
        await updateDoc(doc(db, "tasks", editingTaskId), { title: taskText.trim(), category: taskCat, frequency: taskFreq, targetDay: taskFreq === 'weekly' ? taskTargetDay : null, targetDate: taskFreq === 'monthly' ? taskTargetDate : null });
        setEditingTaskId(null);
      } else {
        await addDoc(collection(db, "tasks"), { title: taskText.trim(), category: taskCat, frequency: taskFreq, targetDay: taskFreq === 'weekly' ? taskTargetDay : null, targetDate: taskFreq === 'monthly' ? taskTargetDate : null, completions: {}, restaurantId: appUser.restaurantId }); 
      }
      setTaskText(''); 
    } 
  };

  const editTask = (t) => {
    setTaskText(t.title);
    setTaskCat(t.category || 'Cleaning');
    setTaskFreq(t.frequency || 'daily');
    if (t.frequency === 'weekly') setTaskTargetDay(t.targetDay || 'Monday');
    if (t.frequency === 'monthly') setTaskTargetDate(t.targetDate || '1');
    setEditingTaskId(t.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const cancelTaskEdit = () => {
    setTaskText('');
    setEditingTaskId(null);
  };
  
  const getTaskPeriodKey = (freq) => {
    if (freq === 'daily') return prepDate;
    if (freq === 'weekly') { 
      const d = new Date(prepDate+'T12:00:00'); 
      const day = d.getDay(); 
      d.setDate(d.getDate() - day + (day === 0 ? -6 : 1)); 
      return formatDate(d); 
    }
    if (freq === 'monthly') return prepDate.substring(0, 7);
  };

  const toggleTaskStatus = async (task) => {
    const periodKey = getTaskPeriodKey(task.frequency);
    const updatedCompletions = { ...(task.completions || {}) };
    if (updatedCompletions[periodKey]) { 
      delete updatedCompletions[periodKey]; 
    } else { 
      updatedCompletions[periodKey] = { by: appUser.name, at: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) }; 
    }
    await updateDoc(doc(db, "tasks", task.id), { completions: updatedCompletions });
  };

  const renderTasks = (freqFilter) => {
    const filteredTasks = tasks.filter(t => t.frequency === freqFilter);
    const grouped = filteredTasks.reduce((acc, t) => { if(!acc[t.category]) acc[t.category]=[]; acc[t.category].push(t); return acc; }, { 'Cleaning': [], 'General': [] });
    const periodKey = getTaskPeriodKey(freqFilter);
    
    return (
      <div className="space-y-4 mt-4">
        {canManageLineChecks && (
          <form onSubmit={handleAddTask} className={`${T.card} p-3 flex flex-col md:flex-row gap-2 items-center bg-[#1A2126]`}>
            {editingTaskId && <div className="text-[10px] font-black text-blue-400 uppercase tracking-widest px-2 whitespace-nowrap">Editing Task</div>}
            <input type="text" value={taskText} onChange={e=>setTaskText(e.target.value)} className="flex-1 w-full p-2 bg-[#12161A] border border-[#2A353D] rounded-xl outline-none text-sm font-medium text-white" placeholder={`New ${freqFilter} task...`} required/>
            <div className="flex w-full md:w-auto gap-2">
              <select value={taskCat} onChange={e=>setTaskCat(e.target.value)} className="w-1/2 md:w-32 p-2 text-xs font-bold bg-[#12161A] border border-[#2A353D] rounded-xl text-white"><option>Cleaning</option><option>General</option></select>
              {freqFilter === 'weekly' && <select value={taskTargetDay} onChange={e=>setTaskTargetDay(e.target.value)} className="w-1/2 md:w-32 p-2 text-xs font-bold bg-[#12161A] border border-[#2A353D] rounded-xl text-white">{['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'].map(d=><option key={d}>{d}</option>)}</select>}
              {freqFilter === 'monthly' && <select value={taskTargetDate} onChange={e=>setTaskTargetDate(e.target.value)} className="w-1/2 md:w-32 p-2 text-xs font-bold bg-[#12161A] border border-[#2A353D] rounded-xl text-white">{Array.from({length:31}).map((_,i)=><option key={i+1}>{i+1}</option>)}</select>}
              <button type="submit" className={`${T.btn} px-4 py-2 flex items-center justify-center`}>{editingTaskId ? <Check size={18}/> : <Plus size={18}/>}</button>
              {editingTaskId && <button type="button" onClick={cancelTaskEdit} className={`${T.btnAlt} px-4 py-2 flex items-center justify-center border-red-900/50 text-red-400 hover:text-red-300`}><X size={18}/></button>}
            </div>
          </form>
        )}

        {['Cleaning', 'General'].map(cat => {
          if (grouped[cat].length === 0) return null;
          return (
            <div key={cat} className={`${T.card} overflow-hidden`}>
              <div className={T.th}><span>{cat} Tasks</span></div>
              <div className={`divide-y ${T.border}`}>
                {grouped[cat].map(t => {
                  const completion = t.completions?.[periodKey];
                  const isDone = !!completion;
                  return (
                    <div key={t.id} className={`${T.row} flex items-center justify-between gap-3`}>
                      <div>
                        <div className={`text-sm font-bold ${isDone ? 'line-through text-slate-500' : 'text-white'}`}>{t.title}</div>
                        <div className={`text-[9px] font-black uppercase mt-1 flex gap-2`}>
                          {freqFilter === 'weekly' && <span className="text-[#D4A381]">Due: {t.targetDay}s</span>}
                          {freqFilter === 'monthly' && <span className="text-[#D4A381]">Due: {t.targetDate}{t.targetDate.endsWith('1') && t.targetDate !== '11' ? 'st' : t.targetDate.endsWith('2') && t.targetDate !== '12' ? 'nd' : t.targetDate.endsWith('3') && t.targetDate !== '13' ? 'rd' : 'th'}</span>}
                          {isDone && <span className="text-emerald-500 tracking-wider">✓ {completion.by} @ {completion.at}</span>}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button onClick={()=>toggleTaskStatus(t)} className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-md transition-all ${isDone ? 'bg-[#12161A] text-emerald-500 border border-emerald-900/50' : `${T.grad} text-slate-900`}`}>{isDone ? <Check size={20}/> : <div className="w-4 h-4 border-2 border-slate-900 rounded-sm"></div>}</button>
                        {canManageLineChecks && <button onClick={()=>editTask(t)} className="text-slate-500 hover:text-[#D4A381] p-2"><Edit size={16}/></button>}
                        {canManageLineChecks && <button onClick={()=>deleteDoc(doc(db,"tasks",t.id))} className="text-slate-500 hover:text-red-500 p-2"><Trash2 size={16}/></button>}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )
        })}
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4 pb-40">
      
      {/* EDIT LINE CHECK MODAL */}
      <Modal isOpen={!!editLineCheckItem} onClose={() => setEditLineCheckItem(null)} title="Edit Line Check">
        {editLineCheckItem && (
          <form onSubmit={handleSaveLineCheckEdit} className="space-y-4">
            <div>
              <label className={T.label}>Item / Cooler Name</label>
              <input type="text" value={editLineCheckItem.name} onChange={e=>setEditLineCheckItem({...editLineCheckItem, name: e.target.value})} className={T.input} required />
            </div>
            <div>
              <label className={T.label}>USDA Safe Temp Rule</label>
              <select value={editLineCheckItem.category} onChange={e=>setEditLineCheckItem({...editLineCheckItem, category: e.target.value})} className={T.input}>
                {Object.keys(USDA_CATEGORIES).map(c=><option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <button type="submit" className={`w-full ${T.btn}`}>Save Changes</button>
          </form>
        )}
      </Modal>

      <div className="flex flex-wrap gap-2 border-b border-[#2A353D] mb-4 pb-2">
        {['prep', 'line-check', 'daily', 'weekly', 'monthly'].map((tab) => (
          <button key={tab} onClick={() => { setSubTab(tab); if(tab !== 'prep' && tab !== 'line-check') setTaskFreq(tab); }} className={`px-3 sm:px-5 py-2.5 text-[10px] sm:text-xs font-black rounded-xl uppercase tracking-widest transition-all flex-1 sm:flex-none ${subTab === tab ? `${T.grad} text-slate-900 shadow-md` : 'bg-[#1A2126] text-slate-400 hover:text-white'}`}>
            {tab === 'prep' ? 'Food Prep' : tab === 'line-check' ? 'Line Check' : `${tab} Tasks`}
          </button>
        ))}
      </div>

      {subTab === 'line-check' && (
        <div className="space-y-4 animate-[slideIn_0.2s_ease-out]">
          
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={18}/>
              <input type="text" placeholder="Search logs & coolers..." value={lcSearch} onChange={e=>setLcSearch(e.target.value)} className={`${T.input} pl-10`} />
            </div>
          </div>

          {canManageLineChecks && (
            <form onSubmit={handleAddLineCheck} className={`${T.card} p-3 flex flex-col sm:flex-row gap-3 items-center bg-[#1A2126]`}>
              <input type="text" value={lcName} onChange={e=>setLcName(e.target.value)} className="flex-1 w-full p-2 bg-[#12161A] border border-[#2A353D] rounded-xl text-sm outline-none font-medium text-white placeholder-slate-500" placeholder="Add cooler or food item..." required/>
              <div className="flex w-full sm:w-auto gap-2 items-center">
                <select value={lcCat} onChange={e=>setLcCat(e.target.value)} className="w-full sm:w-48 p-2 text-xs font-bold bg-[#12161A] border border-[#2A353D] rounded-xl outline-none text-[#D4A381]">
                  {Object.keys(USDA_CATEGORIES).map(c=><option key={c} value={c}>{c}</option>)}
                </select>
                <button type="submit" className={`${T.btn} py-2 px-4 flex-shrink-0`}><Plus size={18}/></button>
              </div>
            </form>
          )}

          <div className={`${T.card} overflow-hidden`}>
            <div className={T.th}>USDA Safety & Temp Log (Today)</div>
            <div className={`divide-y ${T.border}`}>
              {filteredLineChecks.length === 0 && <div className="p-6 text-center font-bold text-slate-500 text-sm">No items configured for line check.</div>}
              {filteredLineChecks.map(item => {
                // Find latest log for this item TODAY
                const todaysLogs = tempLogs.filter(l => l.itemId === item.id && l.date === getToday()).sort((a,b) => new Date(b.timestamp) - new Date(a.timestamp));
                const latestLog = todaysLogs.length > 0 ? todaysLogs[0] : null;

                return (
                  <div key={item.id} className={`${T.row} flex flex-col md:flex-row justify-between md:items-center gap-4`}>
                    <div className="flex-1">
                      <div className="font-bold text-white text-base">{item.name}</div>
                      <div className="text-[10px] text-[#D4A381] font-black uppercase tracking-widest mt-0.5">{item.category}</div>
                      
                      {latestLog ? (
                        <div className={`text-[10px] font-black mt-2 inline-flex items-center gap-2 px-2 py-1 rounded-md border ${latestLog.status === 'Safe' ? 'bg-emerald-900/20 text-emerald-400 border-emerald-900/50' : 'bg-red-900/20 text-red-400 border-red-900/50'}`}>
                          <span className="text-sm">{latestLog.temp}°F</span> 
                          <span>({latestLog.status})</span>
                          <span className="opacity-70 font-bold border-l border-current pl-2 ml-1">By {latestLog.loggedBy} at {new Date(latestLog.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                        </div>
                      ) : (
                        <div className="text-[10px] text-slate-500 font-bold mt-2 uppercase tracking-widest">Not logged yet today</div>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-3 md:self-end">
                      <div className="flex items-center gap-1 bg-[#12161A] p-1 rounded-lg border border-[#2A353D]">
                        <input type="number" step="0.1" value={temps[item.id] || ''} onChange={e=>setTemps({...temps, [item.id]: e.target.value})} placeholder="°F" className="w-16 bg-transparent text-white font-black text-center text-sm outline-none" />
                        <button onClick={() => handleLogTemp(item)} disabled={!temps[item.id]} className="bg-slate-800 text-white disabled:opacity-50 px-3 py-1.5 rounded text-xs font-black uppercase hover:bg-slate-700 transition-colors">Log</button>
                      </div>
                      
                      {canManageLineChecks && (
                        <div className="flex gap-1 border-l border-[#2A353D] pl-3">
                          <button onClick={() => setEditLineCheckItem(item)} className="p-2 text-slate-400 hover:text-white"><Edit size={16}/></button>
                          <button onClick={() => { if(window.confirm(`Delete ${item.name}?`)) deleteDoc(doc(db,"lineCheckItems",item.id)); }} className="p-2 text-slate-400 hover:text-red-500"><Trash2 size={16}/></button>
                        </div>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )}

      {subTab === 'prep' && (
        <div className="space-y-4 animate-[slideIn_0.2s_ease-out]">
          <div className={`${T.card} p-3 flex justify-between items-center bg-[#1A2126]`}>
            <h3 className={`font-black flex items-center gap-2 text-sm text-white uppercase tracking-wider`}><ClipboardList size={18} className={T.copper}/> Target Date:</h3>
            <input type="date" value={prepDate} onChange={e=>setPrepDate(e.target.value)} className="p-1.5 bg-[#12161A] border border-[#2A353D] rounded-lg outline-none text-sm font-bold text-[#D4A381] shadow-inner"/>
          </div>
          <form onSubmit={handleAddPrep} className={`${T.card} p-3 flex flex-col sm:flex-row gap-3 items-center bg-[#1A2126]`}>
            <input type="text" value={text} onChange={e=>setText(e.target.value)} className="flex-1 w-full p-2 bg-[#12161A] border border-[#2A353D] rounded-xl text-sm outline-none font-medium text-white placeholder-slate-500" placeholder="Add prep item..." required/>
            <div className="flex w-full sm:w-auto gap-3 items-center">
              <select value={station} onChange={e=>setStation(e.target.value)} className="w-full sm:w-32 p-2 text-xs font-bold bg-[#12161A] border border-[#2A353D] rounded-xl outline-none text-white">{displayStations.map(s => <option key={s} value={s}>{s}</option>)}</select> 
              <label className={`flex items-center gap-2 text-[10px] uppercase tracking-widest font-bold ${T.muted} cursor-pointer`}><input type="checkbox" checked={isMaster} onChange={e=>setIsMaster(e.target.checked)} className="w-4 h-4 accent-[#8F6040] bg-[#12161A] border-[#2A353D] rounded"/> Master</label>
              <button className={`${T.btn} py-2 px-4`}><Plus size={18}/></button>
            </div>
          </form>
          
          <div className={`${T.card} overflow-hidden`}>
            {Object.entries(groupedPrep).map(([stationName, items]) => (
              <div key={stationName}>
                <div className={T.th}><span>{stationName} Station</span><span className="float-right text-slate-500">{items.filter(i => (i.isMaster ? !!i.completedDates?.[prepDate] : i.isCompleted)).length}/{items.length} Done</span></div>
                <div className={`divide-y ${T.border}`}>
                  {items.map(i=>{
                    const isDone = i.isMaster ? !!i.completedDates?.[prepDate] : i.isCompleted; 
                    const doneBy = i.isMaster ? i.completedDates?.[prepDate] : i.completedBy; 
                    const qty = i.qty ?? 1;
                    const isSelected = selectedPreps.includes(i.id);
                    
                    return (
                    <div key={i.id} className={`${T.row} ${isSelected ? 'bg-[#12161A]' : ''} flex items-center gap-2`}>
                      <input type="checkbox" checked={isSelected} onChange={() => toggleSelection(i.id)} className="w-5 h-5 rounded accent-[#8F6040] bg-[#12161A] border-[#2A353D] flex-shrink-0 cursor-pointer" />
                      <div className="flex-1 min-w-0"><span className={`text-sm font-bold ${isDone?'line-through text-slate-500':'text-white'}`}>{i.text}</span> {doneBy && <span className={`text-[9px] font-black text-emerald-500 bg-emerald-900/20 border border-emerald-900/50 px-1.5 py-0.5 rounded ml-2`}>✓ {doneBy}</span>} {i.isMaster&&<span className="block text-[9px] font-black text-slate-500 uppercase mt-0.5">Master Task</span>}</div>
                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        <div className={`flex items-center bg-[#12161A] rounded-lg border ${T.border} h-8`}><button onClick={async ()=> await updateDoc(doc(db, "prepItems", i.id), { qty: Math.max(0, qty - 1) })} className="w-6 h-full font-bold text-white hover:bg-[#1A2126]">-</button><span className="w-5 text-center text-xs font-bold text-[#D4A381]">{qty}</span><button onClick={async ()=> await updateDoc(doc(db, "prepItems", i.id), { qty: qty + 1 })} className="w-6 h-full font-bold text-white hover:bg-[#1A2126]">+</button></div>
                        <button onClick={()=>togglePrepStatus(i)} className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold shadow-sm ${isDone?'bg-[#12161A] text-slate-500 border border-[#2A353D]':`${T.grad} text-slate-900`}`}>{isDone ? <Repeat size={14}/> : <Check size={16}/>}</button>
                        <button onClick={()=>{ deleteDoc(doc(db,"prepItems",i.id)); }} className="text-slate-500 hover:text-red-500 p-1.5"><Trash2 size={16}/></button>
                      </div>
                    </div>
                  )})}
                </div>
              </div>
            ))}
          </div>
          <div className={`fixed bottom-0 left-0 right-0 p-4 bg-[#161D22] border-t ${T.border} z-50 backdrop-blur-md bg-opacity-95`}>
            <div className="max-w-2xl mx-auto flex gap-3">
              <button onClick={() => { 
                  const sel = activePrep.filter(i=>selectedPreps.includes(i.id)); 
                  if(sel.length===0)return; 
                  const toP=[]; 
                  sel.forEach(i=>{for(let j=0;j<(i.qty ?? 1);j++)toP.push({...i, printId:`${i.id}-${j}`});}); 
                  setLabelsToPrint({items:toP, prepDate}); 
              }} disabled={selectedPreps.length===0} className={`flex-1 ${T.btn} disabled:opacity-50 flex items-center justify-center gap-2`}><ClipboardList size={18}/> Print Selected</button>
              
              <button onClick={async () => { 
                  const sel = activePrep.filter(i=>selectedPreps.includes(i.id)); 
                  for(const item of sel){ 
                      if(item.isMaster){ 
                          const dts={...(item.completedDates||{})}; 
                          dts[prepDate]=appUser.name; 
                          await updateDoc(doc(db,"prepItems",item.id),{completedDates:dts}); 
                      } else {
                          await updateDoc(doc(db,"prepItems",item.id),{isCompleted:true, completedBy:appUser.name}); 
                      }
                  } 
                  setSelectedPreps([]);
              }} disabled={selectedPreps.length===0} className={`flex-1 ${T.btn} disabled:opacity-50 flex items-center justify-center gap-2`}><Check size={18}/> Mark Done</button>
            </div>
          </div>
  
      </div>
      )}

      {subTab !== 'prep' && subTab !== 'line-check' && <div className="animate-[slideIn_0.2s_ease-out]">{renderTasks(subTab)}</div>}
    </div>
  );
};

// --- INVENTORY, VENDORS, & WASTE TRACKER ---
const TabInventory = ({ addToast, appUser }) => {
  const inventoryItems = useLiveCollection('inventoryItems', appUser?.restaurantId);
  const vendors = useLiveCollection('vendors', appUser?.restaurantId);
  const wasteLogs = useLiveCollection('wasteLogs', appUser?.restaurantId);
  const [invTab, setInvTab] = useState('count');
const [searchTerm, setSearchTerm] = useState(''); 
  const [groupBy, setGroupBy] = useState('Category');
  const weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  
  // Fetch invoices securely directly inside this tab
  const invoices = useLiveCollection('invoices', appUser?.restaurantId);
  const [viewInvoice, setViewInvoice] = useState(null);

  // Inventory Form
  const [newItemName, setNewItemName] = useState(''); const [newItemCat, setNewItemCat] = useState(''); const [newItemCode, setNewItemCode] = useState(''); const [newItemSupplier, setNewItemSupplier] = useState(''); const [newItemPackSize, setNewItemPackSize] = useState('1 CS'); const [newItemYield, setNewItemYield] = useState('1'); const [newItemPrice, setNewItemPrice] = useState(''); 
  const [editItem, setEditItem] = useState(null); 
  const [orderOverrides, setOrderOverrides] = useState({}); 
  const [confirmModal, setConfirmModal] = useState({ isOpen: false, vendorId: null, items: [] });
  
  // Vendor Form
  const [vName, setVName] = useState(''); const [vRep, setVRep] = useState(''); const [vPhone, setVPhone] = useState(''); const [vEmail, setVEmail] = useState(''); const [vDays, setVDays] = useState([]); const [vTime, setVTime] = useState('');
  const [editVendor, setEditVendor] = useState(null);

  // Waste Form States
  const [wItemId, setWItemId] = useState(''); 
  const [wQty, setWQty] = useState(''); 
  const [wReason, setWReason] = useState('Dropped / Spilled');
  const [editWaste, setEditWaste] = useState(null);
  const [wSearchTerm, setWSearchTerm] = useState(''); // Search filter for selecting items to burn
  const [wasteSearch, setWasteSearch] = useState(''); // Search filter for looking up past burn logs

  // AI Invoice Scanner State
  const [isScanningInvoice, setIsScanningInvoice] = useState(false);
  const [scannedInvoice, setScannedInvoice] = useState(null);

  // Master Permission Check for Inventory Tabs
  const hasInvPerms = appUser?.isAdmin || appUser?.permissions?.inventory || appUser?.permissions?.team;

  // --- LOGIC ---
  const handleAddItem = async (e) => { e.preventDefault(); if (!newItemName.trim() || !newItemSupplier) return addToast('Error', 'Name and Vendor required.'); await addDoc(collection(db, "inventoryItems"), { name: newItemName.trim(), category: newItemCat || 'Other', pfgCode: newItemCode.trim(), supplierId: newItemSupplier, packSize: newItemPackSize.trim(), yieldQty: parseInt(newItemYield) || 1, price: parseFloat(newItemPrice) || 0, parLevel: 0, currentStock: 0, pendingQty: 0, isStarred: false, lastOrderedDate: null, restaurantId: appUser.restaurantId }); setNewItemName(''); setNewItemCode(''); setNewItemPrice(''); setNewItemYield('1'); addToast('Inventory Updated', 'Item cataloged.'); };
  const handleSaveEdit = async (e) => { e.preventDefault(); await updateDoc(doc(db, "inventoryItems", editItem.id), { name: editItem.name.trim(), category: editItem.category || 'Other', pfgCode: (editItem.pfgCode || '').trim(), supplierId: editItem.supplierId, packSize: editItem.packSize, yieldQty: parseInt(editItem.yieldQty) || 1, price: parseFloat(editItem.price) || 0 }); setEditItem(null); addToast('Item Updated', 'Master file overwritten.'); };
  const updateStock = async (id, newStock) => await updateDoc(doc(db, "inventoryItems", id), { currentStock: Math.max(0, parseFloat(newStock) || 0) });
  const updatePar = async (id, newPar) => await updateDoc(doc(db, "inventoryItems", id), { parLevel: Math.max(0, parseFloat(newPar) || 0) });
  const handleOrderChange = (id, change, currentQty) => setOrderOverrides(prev => ({ ...prev, [id]: Math.max(0, currentQty + change) }));
  
  const handleAddVendor = async (e) => { e.preventDefault(); if(!vName.trim()) return; await addDoc(collection(db, "vendors"), { name: vName.trim(), rep: vRep.trim(), phone: vPhone.trim(), email: vEmail.trim(), cutOffDays: vDays, cutOffTime: vTime, restaurantId: appUser.restaurantId }); setVName(''); setVRep(''); setVPhone(''); setVEmail(''); setVDays([]); setVTime(''); addToast('Vendor Added', 'Directory updated.'); };
const handleSaveVendorEdit = async (e) => { e.preventDefault(); await updateDoc(doc(db, "vendors", editVendor.id), { name: editVendor.name, rep: editVendor.rep, phone: editVendor.phone, email: editVendor.email, cutOffDays: editVendor.cutOffDays || [], cutOffTime: editVendor.cutOffTime || '', ediEndpoint: editVendor.ediEndpoint || '' }); setEditVendor(null); addToast('Vendor Updated', 'Profile saved.'); };  const toggleVendorDay = (day, isEdit = false) => { if (isEdit) { const d = editVendor.cutOffDays || []; setEditVendor({...editVendor, cutOffDays: d.includes(day) ? d.filter(x=>x!==day) : [...d, day]}); } else { setVDays(vDays.includes(day) ? vDays.filter(x=>x!==day) : [...vDays, day]); } };

const handleLogWaste = async (e) => {
    e.preventDefault(); 
    if(!wItemId || !wQty) return; 
    
    const item = inventoryItems.find(i => i.id === wItemId); 
    if(!item) return;

    // 1. Get the raw inputs
    const unitsWasted = parseFloat(wQty); 
    const yieldPerCase = parseFloat(item.yieldQty) > 0 ? parseFloat(item.yieldQty) : 1; 
    const pricePerCase = parseFloat(item.price) || 0;

    // 2. Calculate individual unit metrics
    const pricePerUnit = pricePerCase / yieldPerCase;
    const totalCostLost = pricePerUnit * unitsWasted;
    
    // 3. Calculate how much of a case to deduct from the main stock
    const stockDeduction = unitsWasted / yieldPerCase; 

    // 4. Save to Database
    await addDoc(collection(db, "wasteLogs"), { 
      itemId: item.id, 
      itemName: item.name, 
      qty: unitsWasted, 
      costLost: totalCostLost, 
      reason: wReason, 
      loggedBy: appUser.name, 
      date: getToday(), 
      timestamp: new Date().toISOString(), 
      restaurantId: appUser.restaurantId 
    });

    await updateDoc(doc(db, "inventoryItems", item.id), { 
      currentStock: Math.max(0, (item.currentStock || 0) - stockDeduction) 
    });

    setWItemId(''); setWQty(''); setWSearchTerm(''); 
    addToast('Burn Logged', `$${totalCostLost.toFixed(2)} (${unitsWasted} units) deducted from stock.`);
  };

  const handleDeleteWaste = async (log) => {
    if (!window.confirm(`Delete burn log for ${log.itemName} and restore stock?`)) return;
    const item = inventoryItems.find(i => i.id === log.itemId);
    if (item) {
       const yieldDivider = parseFloat(item.yieldQty) || 1;
       const stockRestoration = (parseFloat(log.qty) || 0) / yieldDivider;
       await updateDoc(doc(db, "inventoryItems", item.id), { currentStock: Math.max(0, (item.currentStock||0) + stockRestoration) });
    }
    await deleteDoc(doc(db, "wasteLogs", log.id));
    addToast('Log Deleted', 'Stock restored successfully.');
  };

 const handleSaveWasteEdit = async (e) => {
    e.preventDefault();
    const log = editWaste;
    const item = inventoryItems.find(i => i.id === log.itemId);
    
    if (item) {
       const originalLog = wasteLogs.find(w => w.id === log.id);
       const oldQty = parseFloat(originalLog.qty) || 0;
       const newQty = parseFloat(log.qty) || 0;
       
       const yieldPerCase = parseFloat(item.yieldQty) > 0 ? parseFloat(item.yieldQty) : 1;
       const pricePerCase = parseFloat(item.price) || 0;
       const pricePerUnit = pricePerCase / yieldPerCase;

       const stockDifference = (newQty - oldQty) / yieldPerCase; 
       const newCostLost = pricePerUnit * newQty;

       await updateDoc(doc(db, "inventoryItems", item.id), { 
         currentStock: Math.max(0, (item.currentStock || 0) - stockDifference) 
       });
       await updateDoc(doc(db, "wasteLogs", log.id), { 
         qty: newQty, 
         reason: log.reason, 
         costLost: newCostLost 
       });
    } else {
       await updateDoc(doc(db, "wasteLogs", log.id), { qty: log.qty, reason: log.reason });
    }
    
    setEditWaste(null);
    addToast('Log Updated', 'Burn log and stock adjusted.');
  };

  const itemsToOrder = inventoryItems.filter(i => { const override = orderOverrides[i.id]; return override !== undefined ? override > 0 : (i.currentStock || 0) < (i.parLevel || 0); });
  const vendorsWithDeficits = vendors.filter(v => itemsToOrder.some(i => i.supplierId === v.id));
  const pendingVendors = vendors.filter(v => inventoryItems.some(i => i.supplierId === v.id && (i.pendingQty || 0) > 0));

  const handleReviewOrder = (vendorId) => {
    const list = itemsToOrder.filter(i => i.supplierId === vendorId).map(item => { const deficit = Math.max(0, (item.parLevel||0) - (item.currentStock||0)); const qty = orderOverrides[item.id] !== undefined ? orderOverrides[item.id] : Math.ceil(deficit); return { ...item, orderQty: qty }; }).filter(i => i.orderQty > 0);
    if (list.length === 0) return addToast('Order Empty', `No deficits for this vendor.`);
    setConfirmModal({ isOpen: true, vendorId, items: list });
  };

const executeOrder = async (method) => {
    const { vendorId, items } = confirmModal; const vendor = vendors.find(v => v.id === vendorId);
    
    let bodyText = items.map(i => `${i.orderQty}x ${i.pfgCode ? `[${i.pfgCode}] ` : ''}${i.name} (${i.packSize})`).join('%0D%0A');
    let fullText = `Order via 86chaos%0D%0A%0D%0A${bodyText}`;

    // UNIVERSAL FAILSAFE: Always copy to clipboard in the background just in case
    try { await navigator.clipboard.writeText(decodeURIComponent(fullText)); } catch (e) { console.log(e); }

    if (method === 'csv') {
      let csvContent = "data:text/csv;charset=utf-8,Qty,Code,Name,Pack Size\n" + items.map(i => `${i.orderQty},"${i.pfgCode||''}","${i.name}","${i.packSize||''}"`).join("\n");
      const link = document.createElement("a"); link.setAttribute("href", encodeURI(csvContent)); link.setAttribute("download", `Order_${(vendor?.name||'Vendor').replace(/\s+/g,'_')}_${getToday()}.csv`);
      document.body.appendChild(link); link.click(); document.body.removeChild(link);
      addToast('Exported', 'Order downloaded as Spreadsheet.');
    } else if (method === 'email') {
      const emailUrl = `mailto:${vendor?.email||''}?subject=Cheers Order&body=${fullText}`;
      if (emailUrl.length > 2000) { addToast('📋 Order Copied!', 'List is huge! We opened email, just tap and PASTE.'); window.location.href = `mailto:${vendor?.email||''}?subject=Cheers Order (Paste From Clipboard)`; } 
      else { window.location.href = emailUrl; }
    } else if (method === 'sms') {
      const smsUrl = `sms:${vendor?.phone||''}?body=${fullText}`;
      if (smsUrl.length > 2000) { addToast('📋 Order Copied!', 'List is huge! We opened SMS, just tap and PASTE.'); window.location.href = `sms:${vendor?.phone||''}`; } 
      else { window.location.href = smsUrl; }
    } else if (method === 'edi') {
      
      // 1. Check for Endpoint
      if (!vendor?.ediEndpoint) {
        return addToast('Missing Config', 'Please add an EDI API Webhook URL in the Vendor Settings first.');
      }
      
      addToast('Transmitting', `Establishing secure handshake with ${vendor.name}...`);
      
      // 2. Compile Machine-Readable Payload
      const ediPayload = {
        restaurantId: appUser.restaurantId,
        timestamp: new Date().toISOString(),
        items: items.map(i => ({ sku: i.pfgCode || 'UNKNOWN', quantity: i.orderQty, packSize: i.packSize }))
      };

      // 3. Transmit (Currently simulating the API call)
      try {
        await new Promise(resolve => setTimeout(resolve, 1500));
        console.log(`[EDI SIMULATION] Payload sent to ${vendor.ediEndpoint}:`, ediPayload);
        addToast('EDI Success', `Order securely injected into ${vendor.name}'s system.`);
      } catch (err) {
        addToast('EDI Failure', 'Connection timed out. Retrying...');
        return; // Abort stock updates on failure so the user can try again
      }

    } else {
      addToast('Copied', 'Order list copied to clipboard!');
    }
    
    // Update Pending Stock
    for (const item of items) { await updateDoc(doc(db, "inventoryItems", item.id), { pendingQty: item.orderQty, lastOrderedQty: item.orderQty, lastOrderedDate: getToday() }); }
    setOrderOverrides({}); setConfirmModal({ isOpen: false, vendorId: null, items: [] });
  };

  const handleReceiveDelivery = async (vendorId) => {
    const itemsToReceive = inventoryItems.filter(i => i.supplierId === vendorId && (i.pendingQty || 0) > 0);
    for (const item of itemsToReceive) {
      await updateDoc(doc(db, "inventoryItems", item.id), { currentStock: (parseFloat(item.currentStock) || 0) + (parseFloat(item.pendingQty) || 0), pendingQty: 0 });
    }
    addToast('Delivery Accepted', `Stock automatically updated for ${itemsToReceive.length} items.`);
  };

  const handleUpdatePendingQty = async (itemId, newQty) => {
    await updateDoc(doc(db, "inventoryItems", itemId), { pendingQty: Math.max(0, parseInt(newQty) || 0) });
  };

  const handleCancelDelivery = async (vendorId) => {
    if (!window.confirm("Cancel this dispatched order? This will clear all pending incoming stock for this vendor.")) return;
    const itemsToCancel = inventoryItems.filter(i => i.supplierId === vendorId && (i.pendingQty || 0) > 0);
    for (const item of itemsToCancel) {
      await updateDoc(doc(db, "inventoryItems", item.id), { pendingQty: 0 });
    }
    addToast('Order Canceled', 'Pending quantities cleared.');
  };

  // --- CSV INVENTORY UPLOAD ---
  const handleCSVUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!window.confirm(`Upload ${file.name} to your inventory?`)) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target.result;
        const rows = text.split('\n').filter(row => row.trim());
        let addedCount = 0;
        for (let i = 1; i < rows.length; i++) {
          const cols = rows[i].split(/(?!\B"[^"]*),(?![^"]*"\B)/).map(c => c.trim().replace(/^"|"$/g, ''));
          if (cols.length < 2) continue; 
          
          const name = cols[0];
          const category = cols[1] || 'Other';
          const code = cols[2] || '';
          const packSize = cols[3] || '1 CS';
          const yieldQty = parseFloat(cols[4]) || 1;
          const price = parseFloat(cols[5]) || 0;
          const vendorName = cols[6] || 'Unassigned Vendor';

          let vId = '';
          let existingVendor = vendors.find(v => v.name.toLowerCase() === vendorName.toLowerCase());
          
          if (existingVendor) {
            vId = existingVendor.id;
          } else {
            const newVRef = await addDoc(collection(db, "vendors"), { name: vendorName, rep: "", email: "", phone: "", restaurantId: appUser.restaurantId });
            vId = newVRef.id;
            vendors.push({id: vId, name: vendorName}); 
          }

          await addDoc(collection(db, "inventoryItems"), {
            name, category, pfgCode: code, packSize, yieldQty, price, parLevel: 0,
            lastOrderedQty: 0, lastOrderedDate: null, supplierId: vId, currentStock: 0, pendingQty: 0, isStarred: false, restaurantId: appUser.restaurantId
          });
          addedCount++;
        }
        addToast("Upload Complete", `Successfully imported ${addedCount} items.`);
      } catch (err) {
        addToast("Error", "Failed to parse CSV file. Ensure it matches the exact template format.");
      }
    };
    reader.readAsText(file);
    e.target.value = ''; 
  };

// --- INVOICE SCANNER (NOW WITH COMPRESSION) ---
  const handleScanInvoice = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setIsScanningInvoice(true);
    addToast('Scanning Invoice', 'Compressing image and extracting data...');

    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target.result;
      img.onload = async () => {
        // Force compression so Vercel doesn't crash on payloads > 4.5MB
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 1200;
        let scaleSize = 1;
        if (img.width > MAX_WIDTH) scaleSize = MAX_WIDTH / img.width;
        canvas.width = img.width * scaleSize;
        canvas.height = img.height * scaleSize;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

        const base64Compressed = canvas.toDataURL('image/jpeg', 0.8);
        const base64Data = base64Compressed.split(',')[1];

        try {
          const response = await secureFetch('/api/scan-invoice', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ fileBase64: base64Data, mimeType: 'image/jpeg' })
          });

          // Prevent the "Unexpected token A" HTML crash
          const contentType = response.headers.get("content-type");
          if (!contentType || !contentType.includes("application/json")) {
             throw new Error("Vercel Server Error: Payload too large or backend crashed.");
          }

          const data = await response.json();
          if (!response.ok) throw new Error(data.error || 'Failed to scan invoice.');
          
          const reconciledItems = (data.lineItems || []).map(item => {
             const match = inventoryItems.find(inv => 
                inv.name.toLowerCase() === item.itemName.toLowerCase() || 
                (inv.pfgCode && item.itemName.includes(inv.pfgCode))
             );
             return { ...item, matchedItemId: match ? match.id : "" };
          });

          setScannedInvoice({ ...data, lineItems: reconciledItems });
          addToast('Success', 'Invoice extracted! Please verify matched items.');
        } catch (err) {
          addToast('Error', err.message);
        } finally {
          setIsScanningInvoice(false);
        }
      };
    };
    e.target.value = '';
  };

  const handleApproveInvoice = async () => {
     try {
       // 1. Log the invoice record for history
       await addDoc(collection(db, "invoices"), {
         ...scannedInvoice,
         restaurantId: appUser.restaurantId,
         processedAt: new Date().toISOString(),
         processedBy: appUser.name
       });

       // 2. Resolve Vendor (Auto-Create if Missing)
       let vId = '';
       let existingVendor = vendors.find(v => v.name.toLowerCase() === (scannedInvoice.vendorName || '').toLowerCase());
       
       if (existingVendor) {
          vId = existingVendor.id;
       } else if (scannedInvoice.vendorName) {
          const newVRef = await addDoc(collection(db, "vendors"), { 
            name: scannedInvoice.vendorName, 
            rep: "", email: "", phone: "", 
            restaurantId: appUser.restaurantId 
          });
          vId = newVRef.id;
       }

       // 3. Loop through and apply stock updates OR create new items
       let updateCount = 0;
       let newCount = 0;
       
for (const item of scannedInvoice.lineItems) {
          // Catch every possible key name the AI might use for the SKU/Product Code
          const incomingCode = item.productCode || item.sku || item.itemNumber || item.pfgCode || item.code || item.itemCode || '';

if (item.matchedItemId === 'CREATE_NEW') {
             // Smart Auto-Categorizer
             const n = (item.itemName || '').toLowerCase();
             let autoCat = 'Other';
             if (n.includes('beef') || n.includes('chicken') || n.includes('pork') || n.includes('steak') || n.includes('bacon') || n.includes('sausage') || n.includes('turkey')) autoCat = 'Meat';
             else if (n.includes('lettuce') || n.includes('tomato') || n.includes('onion') || n.includes('potato') || n.includes('apple') || n.includes('lemon') || n.includes('lime') || n.includes('pepper') || n.includes('produce')) autoCat = 'Produce';
             else if (n.includes('milk') || n.includes('cheese') || n.includes('cream') || n.includes('butter') || n.includes('yogurt') || n.includes('dairy')) autoCat = 'Dairy';
             else if (n.includes('bread') || n.includes('bun') || n.includes('roll') || n.includes('tortilla') || n.includes('dough')) autoCat = 'Bakery';
             else if (n.includes('fish') || n.includes('shrimp') || n.includes('salmon') || n.includes('crab') || n.includes('seafood')) autoCat = 'Seafood';
             else if (n.includes('fry') || n.includes('fries') || n.includes('frozen') || n.includes('ice')) autoCat = 'Frozen';
             else if (n.includes('box') || n.includes('cup') || n.includes('napkin') || n.includes('fork') || n.includes('towel') || n.includes('lid') || n.includes('straw') || n.includes('container') || n.includes('bag') || n.includes('foil') || n.includes('wrap')) autoCat = 'Supplies';
             else if (n.includes('beer') || n.includes('wine') || n.includes('soda') || n.includes('juice') || n.includes('syrup') || n.includes('water') || n.includes('tea') || n.includes('coffee')) autoCat = 'Beverage';

             await addDoc(collection(db, "inventoryItems"), {
                name: item.itemName,
                category: autoCat, 
                pfgCode: incomingCode, 
                supplierId: vId,
                packSize: item.packSize || '1 CS',
                yieldQty: 1, 
                price: parseFloat(item.unitPrice) || 0,
                parLevel: 0,
                currentStock: parseFloat(item.quantity) || 0,
                pendingQty: 0,
                isStarred: false,
                lastOrderedDate: null,
                restaurantId: appUser.restaurantId
             });
             newCount++;
          } else if (item.matchedItemId) {
             const invItem = inventoryItems.find(i => i.id === item.matchedItemId);
             if (invItem) {
                const addedStock = parseFloat(item.quantity) || 0;
                const updates = { 
                   currentStock: (parseFloat(invItem.currentStock) || 0) + addedStock 
                };
                
                // If the item doesn't have a product code yet, but the invoice found one, save it
                if (!invItem.pfgCode && incomingCode) {
                   updates.pfgCode = incomingCode;
                }

                await updateDoc(doc(db, "inventoryItems", invItem.id), updates);
                updateCount++;
             }
          }
       }

       addToast('Invoice Processed', `Updated ${updateCount} items and added ${newCount} new items.`);
       setScannedInvoice(null);
     } catch(e) {
       addToast('Error', 'Failed to process invoice updates.');
     }
  };

const groupedItems = inventoryItems.filter(i => (i.name || '').toLowerCase().includes(searchTerm.toLowerCase()) || (i.pfgCode && i.pfgCode.includes(searchTerm))).reduce((acc, item) => { 
    const key = groupBy === 'Vendor' ? (vendors.find(v=>v.id===item.supplierId)?.name || 'Unassigned Vendor') : (item.category || 'Uncategorized');
    if (!acc[key]) acc[key] = []; acc[key].push(item); return acc; 
  }, {});
  const orderTotal = confirmModal.items.reduce((sum, item) => sum + ((item.price||0) * item.orderQty), 0);

  return (
    <div className="max-w-5xl mx-auto space-y-4 pb-24">
      
      {/* INVOICE RECONCILIATION MODAL */}
      <Modal isOpen={!!scannedInvoice} onClose={() => setScannedInvoice(null)} title="Reconcile & Approve Invoice">
        {scannedInvoice && (
          <div className="space-y-4">
            <div className="flex justify-between items-center bg-[#12161A] p-3 rounded-xl border border-[#2A353D]">
              <div>
                <div className="font-black text-white text-lg">{scannedInvoice.vendorName}</div>
                <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{scannedInvoice.invoiceDate}</div>
              </div>
<div className="text-xl font-black text-emerald-400">${Number(scannedInvoice.invoiceTotal || 0).toFixed(2)}</div>
            </div>
            
            <div className="flex justify-between items-center mt-2 mb-1">
              <p className="text-[10px] uppercase font-bold text-slate-400 tracking-widest pl-1">Stock Matcher</p>
              <div className="flex gap-2">
                <button type="button" onClick={() => { const newItems = scannedInvoice.lineItems.map(i => ({...i, matchedItemId: ''})); setScannedInvoice({...scannedInvoice, lineItems: newItems}); }} className="text-[9px] bg-[#1A2126] text-slate-400 border border-[#2A353D] hover:text-white px-2 py-1 rounded font-black uppercase tracking-widest transition-colors shadow-sm">
                  Clear All
                </button>
                <button type="button" onClick={() => { const newItems = scannedInvoice.lineItems.map(i => ({...i, matchedItemId: i.matchedItemId || 'CREATE_NEW'})); setScannedInvoice({...scannedInvoice, lineItems: newItems}); }} className="text-[9px] bg-blue-900/20 text-blue-400 border border-blue-900/50 hover:bg-blue-900/40 px-2 py-1 rounded font-black uppercase tracking-widest transition-colors shadow-sm">
                  Mark Unmatched as New
                </button>
              </div>
            </div>

            <div className="max-h-[50vh] overflow-y-auto custom-scrollbar border border-[#2A353D] rounded-xl divide-y divide-[#2A353D]">
              {(scannedInvoice.lineItems || []).map((item, idx) => (
                <div key={idx} className="p-3 bg-[#1A2126] flex flex-col gap-3">
                  <div className="flex justify-between items-start">
                    <div>
<div className="font-bold text-white text-sm flex items-center gap-1.5">
  {item.productCode && <span className="text-[#D4A381] font-black">[{item.productCode}]</span>}
  {item.itemName}
</div>                      <div className="text-[9px] text-[#D4A381] font-black uppercase tracking-widest mt-0.5">
                        {item.quantity} {item.packSize} @ ${Number(item.unitPrice || 0).toFixed(2)}/ea
                      </div>
                    </div>
                    <div className="font-black text-slate-300">${Number(item.totalPrice || 0).toFixed(2)}</div>
                  </div>
                  
                  {/* RECONCILIATION DROPDOWN */}
                  <select 
                    value={item.matchedItemId} 
                    onChange={(e) => {
                       const newItems = [...scannedInvoice.lineItems];
                       newItems[idx].matchedItemId = e.target.value;
                       setScannedInvoice({...scannedInvoice, lineItems: newItems});
                    }}
                    className={`${T.input} py-2 text-xs font-bold outline-none cursor-pointer ${item.matchedItemId === 'CREATE_NEW' ? 'border-blue-500/50 text-blue-400 bg-blue-900/10' : item.matchedItemId ? 'border-emerald-500/50 text-emerald-400 bg-emerald-900/10' : 'border-orange-500/50 text-orange-400 bg-orange-900/10'}`}
                  >
                    <option value="">-- Do Not Import / Skip --</option>
                    <option value="CREATE_NEW">➕ Add as New Item</option>
                    {inventoryItems.map(inv => (
                      <option key={inv.id} value={inv.id}>{inv.name}</option>
                    ))}
                  </select>
                </div>
              ))}
            </div>

            <button onClick={handleApproveInvoice} className={`w-full ${T.btn} py-3`}>Approve & Update Stock</button>
          </div>
        )}
      </Modal>

      {/* VIEW PAST INVOICE DETAILS MODAL */}
      <Modal isOpen={!!viewInvoice} onClose={() => setViewInvoice(null)} title="Invoice Details">
        {viewInvoice && (
          <div className="space-y-4">
            <div className="flex justify-between items-center bg-[#12161A] p-3 rounded-xl border border-[#2A353D]">
              <div>
                <div className="font-black text-white text-lg">{viewInvoice.vendorName}</div>
                <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{viewInvoice.invoiceDate}</div>
              </div>
              <div className="text-xl font-black text-emerald-400">${Number(viewInvoice.invoiceTotal || 0).toFixed(2)}</div>
            </div>
            
            <div className="max-h-60 overflow-y-auto custom-scrollbar border border-[#2A353D] rounded-xl divide-y divide-[#2A353D]">
              {(viewInvoice.lineItems || []).map((item, idx) => (
                <div key={idx} className="p-2.5 bg-[#1A2126] flex justify-between items-center">
                  <div>
                    <div className="font-bold text-white text-sm">{item.itemName}</div>
                    <div className="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                      {item.quantity} {item.packSize} @ ${Number(item.unitPrice || 0).toFixed(2)}/ea
                    </div>
                    {item.matchedItemId && item.matchedItemId !== 'CREATE_NEW' && <div className="text-[8px] text-emerald-500 font-black uppercase mt-1">Matched to Inventory</div>}
                    {item.matchedItemId === 'CREATE_NEW' && <div className="text-[8px] text-blue-400 font-black uppercase mt-1">Added as New Item</div>}
                  </div>
                  <div className="font-black text-slate-300">${Number(item.totalPrice || 0).toFixed(2)}</div>
                </div>
              ))}
            </div>
            <button onClick={() => setViewInvoice(null)} className={`w-full ${T.btnAlt} py-3`}>Close</button>
          </div>
        )}
      </Modal>

      <Modal isOpen={confirmModal.isOpen} onClose={() => setConfirmModal({ isOpen: false, vendorId: null, items: [] })} title={`Review Order: ${vendors.find(v=>v.id===confirmModal.vendorId)?.name}`}>
         <div className="space-y-4">
           <div className={`max-h-60 overflow-y-auto border ${T.border} rounded-xl divide-y divide-[#2A353D]`}>{confirmModal.items.map(item => (<div key={item.id} className="p-3 flex justify-between items-center bg-[#12161A]"><div><span className="font-bold text-sm block text-white">{item.name}</span><span className={`text-xs ${T.muted}`}>{item.packSize}</span><div className="text-[9px] text-[#D4A381] mt-0.5 uppercase tracking-widest font-black">Est: ${((item.price||0) * item.orderQty).toFixed(2)}</div></div><div className={`font-black ${T.copper} text-lg`}>{item.orderQty}</div></div>))}</div>
           <div className="flex justify-between items-center bg-[#1A2126] p-3 rounded-xl border border-[#2A353D]"><span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Estimated Total</span><span className="text-lg font-black text-emerald-400">${orderTotal.toFixed(2)}</span></div>
<div className="grid grid-cols-2 gap-2">
<button onClick={() => executeOrder('edi')} className={`w-full col-span-2 bg-blue-900/20 text-blue-400 font-black tracking-widest uppercase border border-blue-900/50 hover:bg-blue-900/40 transition-all flex items-center justify-center gap-2 py-3 text-xs rounded-xl shadow-[0_0_10px_rgba(59,130,246,0.1)]`}>
                <Globe size={16}/> Direct EDI Sync
                <span className="ml-2 bg-blue-900/30 text-blue-400 border border-blue-500/50 text-[8px] px-1.5 py-0.5 rounded-md uppercase tracking-widest font-black shadow-[0_0_8px_rgba(59,130,246,0.2)]">Beta</span>
              </button>              <button onClick={() => executeOrder('email')} className={`w-full ${T.btn} flex items-center justify-center gap-2 py-2 text-xs`}><Send size={16}/> Email</button>
              <button onClick={() => executeOrder('sms')} className={`w-full ${T.btn} flex items-center justify-center gap-2 py-2 text-xs`}><MessageSquare size={16}/> Text</button>
             <button onClick={() => executeOrder('csv')} className={`w-full bg-[#12161A] text-slate-300 border border-[#2A353D] font-bold rounded-xl hover:text-emerald-400 transition-all px-2 py-2 text-xs flex items-center justify-center gap-2`}><Package size={16}/> CSV Export</button>
             <button onClick={() => executeOrder('copy')} className={`w-full bg-[#12161A] text-slate-300 border border-[#2A353D] font-bold rounded-xl hover:text-[#D4A381] transition-all px-2 py-2 text-xs flex items-center justify-center gap-2`}><ClipboardList size={16}/> Copy List</button>
           </div>
         </div>
      </Modal>

      <Modal isOpen={!!editVendor} onClose={() => setEditVendor(null)} title="Edit Vendor">
        {editVendor && (
          <form onSubmit={handleSaveVendorEdit} className="space-y-3">
            <div className="grid grid-cols-2 gap-3"><input type="text" value={editVendor.name} onChange={e=>setEditVendor({...editVendor, name: e.target.value})} className={T.input} required placeholder="Company Name"/><input type="text" value={editVendor.rep || ''} onChange={e=>setEditVendor({...editVendor, rep: e.target.value})} className={T.input} placeholder="Rep Name"/></div>
      <div className="grid grid-cols-2 gap-3"><input type="tel" value={editVendor.phone || ''} onChange={e=>setEditVendor({...editVendor, phone: e.target.value})} className={T.input} placeholder="Phone"/><input type="email" value={editVendor.email || ''} onChange={e=>setEditVendor({...editVendor, email: e.target.value})} className={T.input} placeholder="Email"/></div>
            <div>
              <label className={T.label}>Direct EDI / API Webhook URL</label>
              <input type="url" value={editVendor.ediEndpoint || ''} onChange={e=>setEditVendor({...editVendor, ediEndpoint: e.target.value})} className={`${T.input} border-blue-900/50 focus:border-blue-500`} placeholder="https://api.sysco.com/v1/orders..." />
            </div>
            <div>
              <label className={T.label}>Order Cut-Off Time</label>
              <input type="time" value={editVendor.cutOffTime || ''} onChange={e=>setEditVendor({...editVendor, cutOffTime: e.target.value})} className={T.input}/>
            </div>
            <div>
              <label className={T.label}>Order Cut-Off Days</label>
              <div className="flex flex-wrap gap-2 mt-1">{weekDays.map(d=><button type="button" key={d} onClick={()=>toggleVendorDay(d, true)} className={`px-3 py-1 rounded-lg text-xs font-bold border transition-colors ${editVendor.cutOffDays?.includes(d) ? 'bg-[#D4A381] text-slate-900 border-[#D4A381]' : 'bg-[#12161A] text-slate-400 border-[#2A353D] hover:text-white'}`}>{d.substring(0,3)}</button>)}</div>
            </div>
            <button type="submit" className={`w-full ${T.btn} mt-2`}>Save Vendor Details</button>
          </form>
        )}
      </Modal>

      <div className={`flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b ${T.border} pb-3`}>
        <h2 className="text-2xl font-black flex items-center gap-2 text-white"><ClipboardList size={24} className={T.copper}/> Inventory</h2>
        <div className={`bg-[#12161A] p-1 rounded-xl flex flex-wrap border ${T.border} w-full sm:w-auto`}>
          <button onClick={() => setInvTab('count')} className={`px-4 py-1.5 rounded-lg text-xs font-bold capitalize whitespace-nowrap transition-all flex-1 sm:flex-none ${invTab === 'count' ? `${T.grad} text-slate-900 shadow-sm` : 'text-slate-400 hover:text-white'}`}>count</button>
          {hasInvPerms && <button onClick={() => setInvTab('order')} className={`px-4 py-1.5 rounded-lg text-xs font-bold capitalize whitespace-nowrap transition-all flex-1 sm:flex-none ${invTab === 'order' ? `${T.grad} text-slate-900 shadow-sm` : 'text-slate-400 hover:text-white'}`}>order</button>}
          {hasInvPerms && <button onClick={() => setInvTab('manage')} className={`px-4 py-1.5 rounded-lg text-xs font-bold capitalize whitespace-nowrap transition-all flex-1 sm:flex-none ${invTab === 'manage' ? `${T.grad} text-slate-900 shadow-sm` : 'text-slate-400 hover:text-white'}`}>manage</button>}
          {hasInvPerms && <button onClick={() => setInvTab('vendors')} className={`px-4 py-1.5 rounded-lg text-xs font-bold capitalize whitespace-nowrap transition-all flex-1 sm:flex-none ${invTab === 'vendors' ? `${T.grad} text-slate-900 shadow-sm` : 'text-slate-400 hover:text-white'}`}>vendors</button>}
          {hasInvPerms && <button onClick={() => setInvTab('invoices')} className={`px-4 py-1.5 rounded-lg text-xs font-bold capitalize whitespace-nowrap transition-all flex-1 sm:flex-none ${invTab === 'invoices' ? `${T.grad} text-slate-900 shadow-sm` : 'text-slate-400 hover:text-white'}`}>🧾 Invoices</button>}
<button onClick={() => setInvTab('waste')} className={`px-4 py-1.5 rounded-lg text-xs font-bold capitalize whitespace-nowrap transition-all flex items-center justify-center gap-1 flex-1 sm:flex-none ${invTab === 'waste' ? `bg-red-500/20 text-red-500 shadow-sm border border-red-500/50` : 'text-slate-400 hover:text-red-400'}`}>
            🚨 Burn Log <span className="ml-1 bg-red-900/30 text-red-400 border border-red-500/50 text-[8px] px-1.5 py-0.5 rounded-md uppercase tracking-widest font-black shadow-[0_0_8px_rgba(239,68,68,0.2)]">Beta</span>
          </button>        </div>
      </div>

{invTab === 'count' && (
        <div className="space-y-4 animate-[slideIn_0.2s_ease-out]">
          <div className="flex flex-col sm:flex-row gap-3">
            <input type="text" placeholder="Search product or code..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className={`${T.input} flex-1`} />
            <select value={groupBy} onChange={e => setGroupBy(e.target.value)} className={`${T.input} sm:w-48 font-bold`}>
              <option value="Category">Group by Category</option>
              <option value="Vendor">Group by Vendor</option>
            </select>
          </div>
          {Object.entries(groupedItems).sort(([a], [b]) => a.localeCompare(b)).map(([category, items]) => (
            <div key={category} className="space-y-2">
              <h4 className={`text-base font-black border-b ${T.border} pb-0.5 uppercase tracking-wide text-slate-400`}>{category}</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">{items.map(item => (
                  <div key={item.id} className={`${T.card} p-2 flex items-center justify-between gap-2`}>
                    <div className="flex-1 min-w-0"><div className="font-bold text-white text-sm truncate">{item.name}</div><div className={`text-[9px] font-bold ${T.muted} uppercase`}>{vendors.find(v=>v.id===item.supplierId)?.name || 'No Vendor'}   {item.packSize || '1 CS'}   YIELD: {item.yieldQty||1}</div></div>
                    <div className={`flex items-center gap-2 bg-[#12161A] p-1 rounded-md border ${T.border} flex-shrink-0`}>
                      <div className="flex flex-col items-center"><span className={`text-[8px] font-bold ${T.muted} uppercase`}>PAR</span><input type="number" min="0" value={item.parLevel} onChange={(e) => updatePar(item.id, e.target.value)} disabled={!hasInvPerms} className={`w-8 text-center font-bold border rounded py-0.5 outline-none text-xs bg-[#1A2126] text-white border-[#2A353D]`} /></div>
                      <div className={`h-6 w-px bg-[#2A353D]`}></div>
                      <div className="flex flex-col items-center"><span className={`text-[8px] font-bold ${T.muted} uppercase`}>STOCK</span><div className="flex items-center gap-1"><button onClick={() => updateStock(item.id, (item.currentStock||0) - 1)} className={`w-5 h-5 flex items-center justify-center bg-[#1A2126] border ${T.border} rounded font-bold text-white hover:text-[#D4A381]`}>-</button><span className={`w-6 text-center font-black text-sm ${(item.currentStock||0) < (item.parLevel||0) ? 'text-red-500' : 'text-white'}`}>{Number(item.currentStock||0).toFixed(2).replace(/\.00$/, '')}</span><button onClick={() => updateStock(item.id, (item.currentStock||0) + 1)} className={`w-5 h-5 flex items-center justify-center bg-[#1A2126] border ${T.border} rounded font-bold text-white hover:text-[#D4A381]`}>+</button></div></div>
                    </div>
                  </div>
                ))}</div>
            </div>
          ))}
        </div>
      )}

      {hasInvPerms && invTab === 'order' && (
        <div className="space-y-4 animate-[slideIn_0.2s_ease-out]">
          
          {pendingVendors.length > 0 && (
            <div className="mb-6 space-y-4">
              <h3 className="text-sm font-black text-emerald-400 border-b border-[#2A353D] pb-2 uppercase tracking-widest">Inbound Deliveries</h3>
              {pendingVendors.map(vendor => {
                 const vItems = inventoryItems.filter(i => i.supplierId === vendor.id && (i.pendingQty || 0) > 0);
                 return (
                   <div key={`pending-${vendor.id}`} className={`${T.card} overflow-hidden border-emerald-900/50`}>
                     <div className={`p-4 bg-[#12161A] border-b ${T.border} flex justify-between items-center`}>
                       <h3 className="font-black text-lg text-white">{vendor.name} Delivery</h3>
                       <span className={`bg-emerald-900/20 border border-emerald-500/50 text-emerald-400 px-3 py-1 rounded-full font-black text-[10px] uppercase`}>{vItems.length} Pending</span>
                     </div>
                     <div className="p-4 space-y-2">
                       {vItems.map(item => (
                          <div key={item.id} className="flex justify-between items-center text-sm font-bold text-slate-300">
                            <span className="truncate pr-4">{item.name} <span className="text-[10px] text-slate-500 font-normal">({item.packSize})</span></span>
                            <div className="flex items-center gap-2">
                              <span className="text-emerald-400 font-black">+</span>
                              <input type="number" min="0" value={item.pendingQty} onChange={(e) => handleUpdatePendingQty(item.id, e.target.value)} className="w-16 bg-[#1A2126] border border-[#2A353D] text-emerald-400 font-black text-center py-1 rounded outline-none" />
                            </div>
                          </div>
                       ))}
                     </div>
                     <div className={`p-4 bg-[#12161A] border-t ${T.border} flex gap-2`}>
                       <button onClick={() => handleReceiveDelivery(vendor.id)} className={`flex-1 bg-emerald-600/20 hover:bg-emerald-600 border border-emerald-500/50 text-emerald-400 hover:text-white font-black py-2 rounded-xl transition-colors`}>✅ Accept & Add</button>
                       <button onClick={() => handleCancelDelivery(vendor.id)} className={`px-4 bg-red-900/20 hover:bg-red-900 border border-red-500/50 text-red-400 hover:text-white font-black py-2 rounded-xl transition-colors`} title="Cancel Order"><X size={18}/></button>
                     </div>
                   </div>
                 )
              })}
            </div>
          )}

          {vendorsWithDeficits.length === 0 ? <div className={`${T.card} p-8 text-center text-slate-400 font-bold`}>No deficit alerts.</div> : vendorsWithDeficits.map(vendor => {
              const vendorItems = itemsToOrder.filter(i => i.supplierId === vendor.id);
              return (
                <div key={vendor.id} className={`${T.card} overflow-hidden`}>
                  <div className={`p-4 bg-[#12161A] border-b ${T.border} flex justify-between items-center`}><h3 className="font-black text-lg text-white">{vendor.name} Order</h3><span className={`bg-[#1A2126] border ${T.border} ${T.copper} px-3 py-1 rounded-full font-black text-[10px] uppercase`}>{vendorItems.length} Items</span></div>
                  <table className="w-full text-left">
                    <tbody className={`divide-y ${T.border}`}>{vendorItems.map(item => {
                      const deficit = Math.max(0, (item.parLevel||0) - (item.currentStock||0));
                      const currentOrder = orderOverrides[item.id] !== undefined ? orderOverrides[item.id] : Math.ceil(deficit);
                      return (
                        <tr key={item.id} className={T.row}>
                          <td className="p-3"><span className="font-bold text-sm block text-white">{item.name}</span><span className={`text-[9px] font-bold ${T.muted} uppercase`}>Par: {item.parLevel||0}   Case: ${Number(item.price||0).toFixed(2)}</span></td>
                          <td className="p-3"><div className="flex items-center justify-end gap-1"><button onClick={()=>handleOrderChange(item.id, -1, currentOrder)} className={`w-8 h-8 rounded-lg bg-[#12161A] border ${T.border} font-bold text-white`}>-</button><input type="number" min="0" value={currentOrder} onChange={e=>setOrderOverrides(p=>({...p, [item.id]: parseInt(e.target.value)||0}))} className={`w-12 h-8 text-center font-black bg-[#12161A] border ${T.border} ${T.copper} rounded-lg outline-none`}/><button onClick={()=>handleOrderChange(item.id, 1, currentOrder)} className={`w-8 h-8 rounded-lg bg-[#12161A] border ${T.border} font-bold text-white`}>+</button></div></td>
                        </tr>
                      )
                    })}</tbody>
                  </table>
                  <div className={`p-4 bg-[#12161A] border-t ${T.border} text-right`}><button onClick={()=>handleReviewOrder(vendor.id)} className={`${T.btn} px-4 py-2 flex items-center justify-center gap-2 ml-auto`}><Check size={16}/> Dispatch</button></div>
                </div>
              )
            })
          }
        </div>
      )}

      {hasInvPerms && invTab === 'manage' && (
        <div className="space-y-4 animate-[slideIn_0.2s_ease-out]">
          <Modal isOpen={!!editItem} onClose={() => setEditItem(null)} title="Edit Item">
             {editItem && (
               <form onSubmit={handleSaveEdit} className="space-y-3">
                 <div className="grid grid-cols-2 gap-3">
                   <div className="col-span-2 sm:col-span-1">
                     <label className={T.label}>Product Number / SKU</label>
                     <input type="text" value={editItem.pfgCode || ''} onChange={e => setEditItem({...editItem, pfgCode: e.target.value})} className={T.input} />
                   </div>
                   <div className="col-span-2 sm:col-span-1">
                     <label className={T.label}>Name</label>
                     <input type="text" value={editItem.name} onChange={e => setEditItem({...editItem, name: e.target.value})} className={T.input} required />
                   </div>
                 </div>
                 <div className="grid grid-cols-2 gap-3">
                   <div>
                     <label className={T.label}>Category</label>
                     <select value={editItem.category || 'Produce'} onChange={e => setEditItem({...editItem, category: e.target.value})} className={T.input}>
                       {['Produce', 'Meat', 'Seafood', 'Dairy', 'Bakery', 'Frozen', 'Dry Goods', 'Supplies', 'Beverage', 'Other'].map(c=><option key={c} value={c}>{c}</option>)}
                     </select>
                   </div>
                   <div>
                     <label className={T.label}>Vendor</label>
                     <select value={editItem.supplierId || ''} onChange={e => setEditItem({...editItem, supplierId: e.target.value})} className={T.input} required>
                       <option value="">Select...</option>
                       {vendors.map(v=><option key={v.id} value={v.id}>{v.name}</option>)}
                     </select>
                   </div>
                 </div>
                 <div className="grid grid-cols-2 gap-3">
                   <div>
                     <label className={T.label}>Case Price ($)</label>
                     <input type="number" step="0.01" value={editItem.price || ''} onChange={e => setEditItem({...editItem, price: e.target.value})} className={T.input} />
                   </div>
                   <div>
                     <label className={T.label}>Units per Case (Yield)</label>
                     <input type="number" min="1" value={editItem.yieldQty || 1} onChange={e => setEditItem({...editItem, yieldQty: e.target.value})} className={T.input} required />
                   </div>
                 </div>
                 <button type="submit" className={`w-full ${T.btn}`}>Save Changes</button>
               </form>
             )}
          </Modal>

          <div className="flex flex-col gap-3 mb-6">
            
            {/* INVOICE SCANNER: Split Camera & Upload */}
            <div className={`flex bg-[#12161A] border border-[#2A353D] rounded-xl overflow-hidden shadow-sm h-16 ${isScanningInvoice ? 'opacity-50 pointer-events-none' : ''}`}>
               <label className="w-20 flex items-center justify-center cursor-pointer hover:bg-[#1A2126] transition-colors border-r border-[#2A353D] text-[#D4A381]" title="Take Photo">
                  {isScanningInvoice ? <Loader2 className="animate-spin" size={24} /> : <Camera size={24} />}
                  <input type="file" accept="image/*,application/pdf" capture="environment" onChange={handleScanInvoice} className="hidden" disabled={isScanningInvoice} />
               </label>
               <label className="flex-1 flex items-center justify-center cursor-pointer hover:bg-[#1A2126] transition-colors text-[#D4A381] font-black uppercase tracking-widest text-[11px] sm:text-xs" title="Upload Photo or PDF">
                  <span>📄 Scan Invoice (PDF/Photo)</span>
                  <input type="file" accept="image/*,application/pdf" onChange={handleScanInvoice} className="hidden" disabled={isScanningInvoice} />
               </label>
            </div>

            {/* CSV IMPORT */}
            <label className={`flex items-center justify-center gap-2 bg-[#12161A] text-slate-300 border border-[#2A353D] hover:bg-[#1A2126] font-black uppercase tracking-widest h-16 rounded-xl shadow-lg transition-all cursor-pointer`}>
              <span className="text-[11px] sm:text-xs">📊 Import CSV</span>
              <input type="file" accept=".csv" onChange={handleCSVUpload} className="hidden" />
            </label>

          </div>

          <form onSubmit={handleAddItem} className={`${T.card} p-4 space-y-3 bg-[#1A2126]`}>
            <h3 className="text-sm font-black uppercase text-[#D4A381] tracking-widest">Add New Item</h3>
            <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
              <input type="text" placeholder="Prod # / SKU" value={newItemCode} onChange={e=>setNewItemCode(e.target.value)} className={`${T.input} col-span-2 sm:col-span-1 py-1.5 text-xs`} />
              <input type="text" placeholder="Item Name..." value={newItemName} onChange={e=>setNewItemName(e.target.value)} className={`${T.input} col-span-2 py-1.5 text-xs`} required/>
              <select value={newItemCat} onChange={e=>setNewItemCat(e.target.value)} className={`${T.input} col-span-2 sm:col-span-1 py-1.5 text-xs`}><option disabled value="">Category...</option>{['Produce', 'Meat', 'Seafood', 'Dairy', 'Bakery', 'Frozen', 'Dry Goods', 'Supplies', 'Beverage', 'Other'].map(c=><option key={c} value={c}>{c}</option>)}</select>
              <select value={newItemSupplier} onChange={e=>setNewItemSupplier(e.target.value)} className={`${T.input} col-span-2 sm:col-span-1 py-1.5 text-xs`} required><option value="">Vendor...</option>{vendors.map(v=><option key={v.id} value={v.id}>{v.name}</option>)}</select>
              <input type="number" step="0.01" placeholder="Case $" value={newItemPrice} onChange={e=>setNewItemPrice(e.target.value)} className={`${T.input} col-span-1 py-1.5 text-xs`}/>
              <input type="number" min="1" placeholder="Yield" value={newItemYield} onChange={e=>setNewItemYield(e.target.value)} className={`${T.input} col-span-1 py-1.5 text-xs`} required/>
            </div>
            <div className="flex justify-end mt-2">
              <button type="submit" className={`w-full sm:w-auto ${T.btn} py-2 px-6`}><Plus size={18} className="inline mr-2"/> Add to Master List</button>
            </div>
          </form>

          {/* SEARCH BAR */}
          <div className="relative w-full">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[#D4A381]" size={20}/>
            <input type="text" placeholder="Search master list by name or product number..." value={searchTerm} onChange={(e)=>setSearchTerm(e.target.value)} className={`${T.input} pl-12`}/>
          </div>

          <div className={`${T.card} divide-y ${T.border}`}>{inventoryItems.filter(i => (i.name || '').toLowerCase().includes(searchTerm.toLowerCase()) || (i.pfgCode && i.pfgCode.includes(searchTerm))).map(item => (<div key={item.id} className={`${T.row} flex justify-between items-center`}><div className="flex-1 min-w-0"><div className="font-bold text-white text-sm truncate">{item.name} <span className="text-[10px] text-slate-500 font-normal">{item.pfgCode ? `[${item.pfgCode}]` : ''}</span></div><div className="text-[10px] text-[#D4A381] font-black uppercase mt-0.5 tracking-widest">Case: ${Number(item.price||0).toFixed(2)}   Yield: {item.yieldQty||1}</div></div><div className="flex gap-2"><button onClick={()=>setEditItem(item)} className="p-2 text-slate-400 hover:text-white"><Edit size={16}/></button><button onClick={() => { if(window.confirm(`Are you sure you want to delete ${item.name}?`)) deleteDoc(doc(db,"inventoryItems",item.id)); }} className="p-2 text-slate-400 hover:text-red-500"><Trash2 size={16}/></button></div></div>))}</div>
        </div>
      )}

      {hasInvPerms && invTab === 'vendors' && (
        <div className="space-y-4 animate-[slideIn_0.2s_ease-out]">
          <form onSubmit={handleAddVendor} className={`${T.card} p-4 space-y-3 bg-[#1A2126]`}>
            <h3 className="text-sm font-black uppercase text-[#D4A381] tracking-widest">Add Vendor</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3"><input type="text" placeholder="Company Name..." value={vName} onChange={e=>setVName(e.target.value)} className={T.input} required/><input type="text" placeholder="Rep Name..." value={vRep} onChange={e=>setVRep(e.target.value)} className={T.input}/><input type="tel" placeholder="Phone (For SMS Orders)" value={vPhone} onChange={e=>setVPhone(e.target.value)} className={T.input}/><input type="email" placeholder="Email (For PDF Orders)" value={vEmail} onChange={e=>setVEmail(e.target.value)} className={T.input}/></div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div><label className={T.label}>Cut-Off Time</label><input type="time" value={vTime} onChange={e=>setVTime(e.target.value)} className={T.input}/></div>
              <div><label className={T.label}>Cut-Off Days</label><div className="flex flex-wrap gap-1 mt-1">{weekDays.map(d=><button type="button" key={d} onClick={()=>toggleVendorDay(d)} className={`px-2 py-1 rounded-md text-[10px] font-bold border transition-colors ${vDays.includes(d) ? 'bg-[#D4A381] text-slate-900 border-[#D4A381]' : 'bg-[#12161A] text-slate-400 border-[#2A353D]'}`}>{d.substring(0,3)}</button>)}</div></div>
            </div>
            <button type="submit" className={`w-full ${T.btn} py-2`}>Save Vendor</button>
          </form>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">{vendors.map(v => (<div key={v.id} className={`${T.card} p-4`}><div className="flex justify-between items-start"><h4 className="font-black text-white text-lg">{v.name}</h4><button onClick={()=>setEditVendor(v)} className="text-slate-400 hover:text-white"><Edit size={14}/></button></div><div className={`text-xs font-bold ${T.muted} mt-1 space-y-1`}><p>Rep: {v.rep || 'N/A'}</p><p>Phone: {v.phone || 'N/A'}</p><p>Email: {v.email || 'N/A'}</p><p className="text-[#D4A381] mt-2">Cut-Off: {v.cutOffDays?.length > 0 ? v.cutOffDays.join(', ') : 'None'} {v.cutOffTime ? `@ ${v.cutOffTime}` : ''}</p></div><button onClick={()=>deleteDoc(doc(db,"vendors",v.id))} className="mt-4 text-[10px] uppercase font-black tracking-widest text-red-500 hover:text-red-400">Remove Vendor</button></div>))}</div>
        </div>
      )}

      {hasInvPerms && invTab === 'invoices' && (
        <div className="space-y-4 animate-[slideIn_0.2s_ease-out]">
          <div className={`${T.card} overflow-hidden`}>
            <div className={`bg-[#12161A] p-4 border-b ${T.border} flex justify-between items-center`}>
              <h3 className="font-black text-sm text-white flex items-center gap-2">Invoice History</h3>
              <span className="bg-[#1A2126] text-slate-400 px-2 py-1 rounded text-[10px] font-black uppercase tracking-widest border border-[#2A353D]">{invoices.length} Total</span>
            </div>
            <div className={`divide-y ${T.border} max-h-[60vh] overflow-y-auto custom-scrollbar`}>
              {invoices.length === 0 ? (
                <div className="p-8 text-center text-slate-500 font-bold">No invoices logged yet.</div>
              ) : (
                invoices.sort((a,b) => new Date(b.processedAt || 0) - new Date(a.processedAt || 0)).map(inv => (
                  <div key={inv.id} className={`${T.row} flex justify-between items-center p-4`}>
                    <div>
                      <div className="font-black text-white text-base">{inv.vendorName}</div>
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Inv Date: {inv.invoiceDate}</div>
                      <div className="text-[9px] text-slate-500 mt-1">Processed by {inv.processedBy} on {new Date(inv.processedAt).toLocaleDateString()}</div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-emerald-400 font-black text-lg">${Number(inv.invoiceTotal || 0).toFixed(2)}</div>
                      <button onClick={() => setViewInvoice(inv)} className="bg-[#12161A] border border-[#2A353D] text-slate-300 hover:text-white px-3 py-1.5 rounded-lg text-xs font-bold transition-colors">View</button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {invTab === 'waste' && (
        <div className="space-y-4 animate-[slideIn_0.2s_ease-out]">
          
          <Modal isOpen={!!editWaste} onClose={() => setEditWaste(null)} title="Edit Burn Log">
            {editWaste && (
              <form onSubmit={handleSaveWasteEdit} className="space-y-3">
                <div><label className={T.label}>Item</label><input type="text" value={editWaste.itemName} disabled className={`${T.input} opacity-50 cursor-not-allowed`} /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className={T.label}>Qty Wasted</label><input type="number" min="1" value={editWaste.qty} onChange={e=>setEditWaste({...editWaste, qty: e.target.value})} className={T.input} required/></div>
                  <div><label className={T.label}>Reason</label><select value={editWaste.reason} onChange={e=>setEditWaste({...editWaste, reason: e.target.value})} className={T.input}><option>Dropped / Spilled</option><option>Expired / Bad Quality</option><option>Cooked Incorrectly</option><option>Comped</option></select></div>
                </div>
                <button type="submit" className={`w-full ${T.btn} mt-2`}>Update & Adjust Stock</button>
              </form>
            )}
          </Modal>

          <form onSubmit={handleLogWaste} className={`${T.card} p-4 space-y-3 bg-[#1A2126]`}>
<h3 className="text-sm font-black uppercase text-red-400 tracking-widest flex items-center gap-2">
              🚨 The Burn Log
              <span className="bg-red-900/30 text-red-400 border border-red-500/50 text-[8px] px-1.5 py-0.5 rounded-md uppercase tracking-widest font-black shadow-[0_0_8px_rgba(239,68,68,0.2)]">Beta</span>
            </h3>            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-start">
              
              {/* THE FILTERABLE DROPDOWN */}
              <div className="space-y-2">
                <input type="text" placeholder="Type to filter inventory..." value={wSearchTerm} onChange={e=>setWSearchTerm(e.target.value)} className={`${T.input} py-2 text-xs border-red-900/30 focus:border-red-500`} />
                <select value={wItemId} onChange={e=>setWItemId(e.target.value)} className={T.input} required>
                  <option value="">Select Item to Burn...</option>
                  {inventoryItems
                    .filter(i => (i.name||'').toLowerCase().includes((wSearchTerm||'').toLowerCase()) || (i.pfgCode||'').toLowerCase().includes((wSearchTerm||'').toLowerCase()))
                    .map(i=><option key={i.id} value={i.id}>{i.name}</option>)}
                </select>
              </div>

              <div>
                <input type="number" min="0" step="any" placeholder="Qty Wasted (Individual Units)..." value={wQty} onChange={e=>setWQty(e.target.value)} className={T.input} required/>
                <span className="text-[9px] text-slate-500 font-bold block mt-1 uppercase tracking-widest">Input individual units, not cases</span>
              </div>
              
              <select value={wReason} onChange={e=>setWReason(e.target.value)} className={T.input}>
                <option>Dropped / Spilled</option>
                <option>Expired / Bad Quality</option>
                <option>Cooked Incorrectly</option>
                <option>Comped</option>
              </select>
            </div>
            <button type="submit" className={`w-full bg-red-900/50 hover:bg-red-900 border border-red-500/50 text-white font-black tracking-widest uppercase text-sm py-2 rounded-xl transition-colors mt-2`}>
              Log Waste & Deduct Stock
            </button>
          </form>
          
          {/* SEARCH BAR */}
          <div className="relative w-full mb-4">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-red-400" size={20}/>
            <input type="text" placeholder="Search logs by item, reason, person, or date..." value={wasteSearch} onChange={(e)=>setWasteSearch(e.target.value)} className={`${T.input} pl-12 border-red-900/30 focus:border-red-500/50`}/>
          </div>

          <div className={`${T.card} divide-y ${T.border}`}>
            <div className={T.th}><span>{wasteSearch ? 'Search Results' : "Today's Burn"}</span></div>
            {wasteLogs.filter(w => wasteSearch ? (w.itemName+w.reason+w.loggedBy+w.date).toLowerCase().includes(wasteSearch.toLowerCase()) : w.date === getToday()).sort((a,b) => new Date(b.timestamp) - new Date(a.timestamp)).map(w => (
              <div key={w.id} className={`${T.row} flex justify-between items-center`}>
                <div className="flex-1"> 
                  <span className="font-bold text-white text-sm block">{w.qty}x {w.itemName}</span>
                  <span className={`text-[9px] font-bold ${T.muted} uppercase`}>{w.date} • {w.reason}   By {w.loggedBy}</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="font-black text-red-400 text-sm">-${w.costLost?.toFixed(2)}</div>
                  <div className="flex gap-1 border-l border-[#2A353D] pl-3 ml-1">
                    <button onClick={() => setEditWaste({...w})} className="p-1.5 text-slate-400 hover:text-white transition-colors"><Edit size={14}/></button>
                    <button onClick={() => handleDeleteWaste(w)} className="p-1.5 text-slate-400 hover:text-red-500 transition-colors"><Trash2 size={14}/></button>
                  </div>
                </div>
              </div>
            ))}
            {wasteLogs.filter(w => wasteSearch ? (w.itemName+w.reason+w.loggedBy+w.date).toLowerCase().includes(wasteSearch.toLowerCase()) : w.date === getToday()).length === 0 && <div className="p-4 text-center text-slate-400 font-bold text-sm">No waste logs found.</div>}
          </div>
        </div>
      )}
    </div>
  );
};

// --- RECIPE BOOK ---
const TabRecipes = ({ appUser, addToast }) => {
  const recipes = useLiveCollection('recipes', appUser?.restaurantId);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCat, setFilterCat] = useState('All'); 
  const [isFormOpen, setIsFormOpen] = useState(false); 
  const [activeRecipe, setActiveRecipe] = useState(null); 
  const [yieldMult, setYieldMult] = useState(1);
  const [editingRecipeId, setEditingRecipeId] = useState(null);
  const [isScanning, setIsScanning] = useState(false);

  // --- SCREEN WAKE LOCK ENGINE ---
  const [isAwake, setIsAwake] = useState(false);
  const [wakeLock, setWakeLock] = useState(null);

  const toggleWakeLock = async () => {
    if (!isAwake) {
      try {
        if ('wakeLock' in navigator) {
          const lock = await navigator.wakeLock.request('screen');
          setWakeLock(lock);
          setIsAwake(true);
          addToast('Screen Awake', 'Screen will stay on. Perfect for messy hands.');
          
          // Browsers automatically release the lock if the user switches tabs/minimizes
          lock.addEventListener('release', () => { setIsAwake(false); setWakeLock(null); });
        } else {
          addToast('Error', 'Screen Wake Lock is not supported on this device/browser.');
        }
      } catch (err) { addToast('Error', err.message); }
    } else {
      if (wakeLock) {
        await wakeLock.release();
        setWakeLock(null);
      }
      setIsAwake(false);
      addToast('Screen Normal', 'Screen sleep timeout restored.');
    }
  };

  const handleScanRecipe = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setIsScanning(true);
    addToast('Scanning', 'Optimizing and reading recipe...');

    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target.result;
      img.onload = async () => {
        // Compress the image on the device BEFORE sending it to Vercel/Gemini
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 1200; // Drops a massive photo down to ~200KB instantly
        let scaleSize = 1;
        if (img.width > MAX_WIDTH) {
           scaleSize = MAX_WIDTH / img.width;
        }
        canvas.width = img.width * scaleSize;
        canvas.height = img.height * scaleSize;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        
        const base64Compressed = canvas.toDataURL('image/jpeg', 0.8);
        const base64Data = base64Compressed.split(',')[1];

        try {
          // THIS IS THE CRITICAL BLOCK. It MUST explicitly say POST.
          const response = await secureFetch('/api/scan', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ imageBase64: base64Data })
          });

          // Prevent the "Unexpected token A" HTML crash
          const contentType = response.headers.get("content-type");
          if (!contentType || !contentType.includes("application/json")) {
             throw new Error("Vercel Server Error: Payload too large or backend crashed.");
          }

          const data = await response.json();
          if (!response.ok) throw new Error(data.error || 'Failed to scan recipe.');

          setTitle(data.title || '');
          setPrepTime(data.prepTime || '--');
          setYieldAmt(data.yieldAmt || '--');
          setIngredients(data.ingredients || '');
          setInstructions(data.instructions || '');
          
          setIsFormOpen(true);
          addToast('Success', 'Recipe extracted! Please review.');
        } catch (err) {
          addToast('Error', err.message);
        } finally {
          setIsScanning(false);
        }
      };
    };
    e.target.value = ''; // Reset input so you can scan the same file again if needed
  };
  
  const parseAndMultiply = (text, mult) => { if (mult === 1) return text; const match = text.trim().match(/^(\d+\s+\d+\/\d+|\d+\/\d+|\d*\.?\d+)\s+(.*)/); if (!match) return text; let numStr = match[1], rest = match[2], val = 0; if (numStr.includes('/')) { const parts = numStr.split(' '); if (parts.length === 2) { const [n, d] = parts[1].split('/'); val = parseFloat(parts[0]) + (parseFloat(n) / parseFloat(d)); } else { const [n, d] = numStr.split('/'); val = parseFloat(n) / parseFloat(d); } } else { val = parseFloat(numStr); } let finalVal = val * mult; let cleanVal = Number.isInteger(finalVal) ? finalVal.toString() : finalVal.toFixed(2); if (cleanVal.endsWith('.50')) cleanVal = cleanVal.replace('.50', ' 1/2').trim(); else if (cleanVal.endsWith('.25')) cleanVal = cleanVal.replace('.25', ' 1/4').trim(); else if (cleanVal.endsWith('.75')) cleanVal = cleanVal.replace('.75', ' 3/4').trim(); else if (cleanVal.endsWith('.33')) cleanVal = cleanVal.replace('.33', ' 1/3').trim(); else if (cleanVal.endsWith('.67')) cleanVal = cleanVal.replace('.67', ' 2/3').trim(); if (cleanVal.startsWith('0 ')) cleanVal = cleanVal.substring(2); return `${cleanVal} ${rest}`; };
  
  const [title, setTitle] = useState(''); 
  const [category, setCategory] = useState('Sauce/Dressing'); 
  const [prepTime, setPrepTime] = useState(''); 
  const [yieldAmt, setYieldAmt] = useState(''); 
  const [ingredients, setIngredients] = useState('');
 
  const [instructions, setInstructions] = useState('');
  const categories = ['All', 'Sauce/Dressing', 'Meat Prep', 'Appetizer', 'Entree', 'Side', 'Dessert', 'Cocktail'];

  const resetForm = () => {
    setTitle(''); setCategory('Sauce/Dressing'); setPrepTime(''); setYieldAmt(''); setIngredients(''); setInstructions(''); setEditingRecipeId(null);
  };

  const handleEdit = () => {
    setTitle(activeRecipe.title);
    setCategory(activeRecipe.category || 'Sauce/Dressing');
    setPrepTime(activeRecipe.prepTime === '--' ? '' : activeRecipe.prepTime);
    setYieldAmt(activeRecipe.yieldAmt === '--' ? '' : activeRecipe.yieldAmt);
    setIngredients(activeRecipe.ingredients);
    setInstructions(activeRecipe.instructions);
    setEditingRecipeId(activeRecipe.id);
    setActiveRecipe(null);
    setIsFormOpen(true);
  };

  const handleSave = async (e) => { 
    e.preventDefault(); 
    if (!title.trim() || !ingredients.trim() || !instructions.trim()) return addToast('Error', 'Missing fields.'); 
    try { 
      if (editingRecipeId) {
        await updateDoc(doc(db, "recipes", editingRecipeId), { 
          title: title.trim(), category, prepTime: prepTime.trim() || '--', yieldAmt: yieldAmt.trim() || '--', ingredients: ingredients.trim(), instructions: instructions.trim(), lastUpdated: new Date().toISOString() 
        }); 
        addToast('Recipe Updated', `${title} updated successfully.`); 
      } else {
        await addDoc(collection(db, "recipes"), { 
          title: title.trim(), category, prepTime: prepTime.trim() || '--', yieldAmt: yieldAmt.trim() || '--', ingredients: ingredients.trim(), instructions: instructions.trim(), authorName: appUser.name, authorId: appUser.id, lastUpdated: new Date().toISOString(), restaurantId: appUser.restaurantId 
        }); 
        addToast('Recipe Saved', `${title} added to the book.`); 
      }
      setIsFormOpen(false); 
      resetForm();
    } catch (err) { addToast('Error', 'Could not save.'); } 
  };
  
  const handleDelete = async (id) => { if (!window.confirm("Delete recipe?")) return; await deleteDoc(doc(db, "recipes", id)); setActiveRecipe(null); addToast('Deleted', 'Recipe removed.'); };
  
  const handleInjectLegacyRecipes = async () => {
    const legacyData = [
      {
        title: "French Onion Dip", category: "Sauce/Dressing", prepTime: "10 mins", yieldAmt: "--",
        ingredients: "2 Packs French Onion Dip\n3 Cups Cottage Cheese\n3 Cups Sour Cream",
        instructions: "Combine all ingredients.\nUse Vita Mix, leave a little chunky."
      },
      {
        title: "Chili", category: "Entree", prepTime: "1 hour", yieldAmt: "--",
        ingredients: "2 (5lb) Beef logs\nPeppers/Onion\n3 cans Tomato Soup (Basement)\n4 cans Tomato Juice (Basement)\n1 can Chili Bean (Basement)\n1 can Diced Tomato (Basement)\n2 (4oz) cups Chili powder\n1 (4oz) cup Kosher salt\n1 (2oz) cup pepper\n1 (2oz) cup garlic granulated\n1 (2oz) cup oregano\n1 (2oz) cup Italian\n1/2 (2oz) cup red pep flakes",
        instructions: "Brown the beef logs and drain grease.\nSauté peppers and onions.\nCombine beef, sautéed veggies, tomato soup, tomato juice, chili beans, and diced tomatoes in a large pot.\nStir in all seasonings (chili powder, salt, pepper, garlic, oregano, italian, red pepper flakes).\nSimmer until flavors are thoroughly combined."
      },
      {
        title: "Beer Dip", category: "Appetizer", prepTime: "15 mins", yieldAmt: "--",
        ingredients: "2 Bottles Miller Light\n1 package Ranch Seasoning\n1 package Softened Cream Cheese\n3 Cups Shredded Cheese",
        instructions: "Whisk together the Miller Light and Ranch Seasoning.\nHand mix the beer/ranch mixture with the softened cream cheese until whippy.\nFold in the shredded cheese to the mixture. Make sure it is properly mixed to the bottom."
      },
      {
        title: "Beer Cheese", category: "Sauce/Dressing", prepTime: "30 mins", yieldAmt: "--",
        ingredients: "1 lb Butter\n1 lb Flour\n1/2 Tablespoon Dry mustard powder\n1/2 Tablespoon Onion powder\n1/2 Tablespoon Garlic granulated\n1/2 Tablespoon Pepper\n1 Tablespoon Salt\n1 Pint Spotted Cow\n1 gallon milk\n80 slices american (Two Blocks)\n8 cups shredded cheddar",
        instructions: "Start with a gallon of milk over a double boiler.\nIn a separate pot, melt the butter. Once melted, add the flour and all seasonings (mustard, onion, garlic, pepper, salt). Whisk together to make a roux.\nOnce combined, add the pint of Spotted Cow to the roux and mix well.\nOnce the milk is steaming, add your roux and mix thoroughly.\nImmediately after, add the American and cheddar cheeses and mix thoroughly.\nTake off heat and cool down."
      },
      {
        title: "Cheesy Potato Bacon Soup", category: "Side", prepTime: "45 mins", yieldAmt: "2 White Buckets",
        ingredients: "1 White Bucket Peeled Potatoes\n1 1/2 Budlight Pitchers Water\n1 Bag Cheese Mix\n1 Gallon Milk\n1 Bag Bacon Bits\n1 Block American Cheese\n1 Tablespoon granulated garlic\n1 Tablespoon granulated onion\n1 Tablespoon Kosher Salt\n1/2 Tablespoon Black pepper",
        instructions: "Put peeled potatoes through potato slicer and dice small. Boil, then drain.\nUse metal pot for double boiler. Use second metal pot on top.\nBring 1 1/2 Budlight pitchers of water to a steam.\nWhisk 1 bag of cheese mix into the steaming water.\nAdd 1 gallon milk, 1 bag bacon bits, and all seasonings (garlic, onion, salt, pepper).\nGradually add American cheese block by slice. Heat until cheese is thoroughly combined.\nSplit the boiled potatoes and the cheese sauce evenly between two white buckets."
      }
    ];

    let count = 0;
    for (const recipe of legacyData) {
      if (!recipes.find(r => r.title === recipe.title)) {
        await addDoc(collection(db, "recipes"), { ...recipe, authorName: "System", authorId: "system", lastUpdated: new Date().toISOString(), restaurantId: appUser.restaurantId });
        count++;
      }
    }
    addToast('Import Complete', `Injected ${count} legacy recipes.`);
  };

  const filteredRecipes = recipes.filter(r => { const matchesSearch = r.title.toLowerCase().includes(searchTerm.toLowerCase()) || r.ingredients.toLowerCase().includes(searchTerm.toLowerCase()); const matchesCat = filterCat === 'All' || r.category === filterCat; return matchesSearch && matchesCat; }).sort((a,b) => a.title.localeCompare(b.title));

  // Determine if the current user has permission to edit/delete the viewed recipe
  const canManageRecipes = appUser?.isAdmin || appUser?.permissions?.team || appUser?.permissions?.prep || appUser?.isSuperAdmin || appUser?.email?.toLowerCase() === MASTER_ADMIN_EMAIL.toLowerCase();
  const canModifyRecipe = activeRecipe && (canManageRecipes || appUser?.id === activeRecipe.authorId);

  return (
    <div className="max-w-6xl mx-auto space-y-4 pb-12 animate-[slideIn_0.2s_ease-out] recipe-compact">
      
      {/* THE NEW SLEEK CONTROL PANEL */}
      <div className="bg-[#1A2126] border border-[#2A353D] rounded-2xl shadow-lg overflow-hidden mb-4">
        {/* Search / Filter Area */}
        <div className="p-3 sm:p-4 flex flex-col md:flex-row gap-3 border-b border-[#2A353D] bg-[#12161A]/50">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18}/>
            <input 
              type="text" 
              placeholder="Search specs or ingredients..." 
              value={searchTerm} 
              onChange={(e)=>setSearchTerm(e.target.value)} 
              className="w-full bg-[#0B0E11] border border-[#2A353D] text-white text-sm font-medium rounded-xl pl-11 pr-4 py-3 outline-none focus:border-[#D4A381] transition-colors shadow-inner"
            />
          </div>
          <div className="relative md:w-64 shrink-0">
            <select 
              value={filterCat} 
              onChange={(e)=>setFilterCat(e.target.value)} 
              className="w-full bg-[#0B0E11] border border-[#2A353D] text-white text-sm font-bold rounded-xl px-4 py-3 outline-none focus:border-[#D4A381] transition-colors appearance-none shadow-inner cursor-pointer"
            >
              {categories.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <ChevronRight className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none rotate-90" size={16}/>
          </div>
        </div>

        {/* Action Buttons Area */}
        <div className="p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
          
          {/* Left Side Actions (Screen Lock / Import) */}
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button 
              onClick={toggleWakeLock} 
              className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-[11px] font-black uppercase tracking-widest transition-all border ${isAwake ? 'bg-amber-900/20 text-amber-400 border-amber-900/50 shadow-[0_0_10px_rgba(251,191,36,0.1)]' : 'bg-[#12161A] text-slate-400 border-[#2A353D] hover:text-amber-400 hover:border-amber-900/50'}`}
              title="Keep Screen On"
            >
              <Sun size={16} className={isAwake ? 'animate-pulse' : ''} />
              <span className="hidden sm:inline">{isAwake ? 'Screen Locked' : 'Keep Awake'}</span>
              <span className="sm:hidden">Awake</span>
            </button>

            {appUser?.email?.toLowerCase() === MASTER_ADMIN_EMAIL.toLowerCase() && (
              <button onClick={handleInjectLegacyRecipes} className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-[11px] font-black uppercase tracking-widest bg-[#12161A] text-slate-400 border border-[#2A353D] hover:text-emerald-400 transition-all">
                <Package size={16} /> <span className="hidden sm:inline">Import</span>
              </button>
            )}
          </div>

          {/* Right Side Actions (AI Scan & New Spec) */}
          {canManageRecipes && (
            <div className="flex flex-wrap sm:flex-nowrap items-center gap-3 w-full sm:w-auto">
              
              {/* Unified Scan/Upload Button */}
              <div className={`flex w-full sm:w-auto bg-[#12161A] border border-[#2A353D] rounded-xl overflow-hidden shadow-sm ${isScanning ? 'opacity-50 pointer-events-none' : ''}`}>
                 <label className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 cursor-pointer hover:bg-[#1A2126] transition-colors border-r border-[#2A353D] text-slate-300 hover:text-[#D4A381]" title="Take Photo">
                    {isScanning ? <Loader2 className="animate-spin" size={16} /> : <Camera size={16} />}
                    <span className="text-[11px] font-black uppercase tracking-widest sm:hidden">Photo</span>
                    <input type="file" accept="image/*" capture="environment" onChange={handleScanRecipe} className="hidden" disabled={isScanning} />
                 </label>
                 <label className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 cursor-pointer hover:bg-[#1A2126] transition-colors text-slate-300 hover:text-[#D4A381]" title="Upload File">
                    <span className="text-[11px] font-black uppercase tracking-widest">Upload File</span>
                    <input type="file" accept="image/*" onChange={handleScanRecipe} className="hidden" disabled={isScanning} />
                 </label>
              </div>

              {/* Primary CTA */}
              <button onClick={() => { resetForm(); setIsFormOpen(true); }} className={`w-full sm:w-auto bg-gradient-to-r from-[#C59373] to-[#8F6040] hover:from-[#D4A381] hover:to-[#A37050] text-slate-900 shadow-lg px-6 py-2.5 rounded-xl text-[11px] font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all`}>
                <Plus size={16}/> New Spec
              </button>
            </div>
          )}
        </div>
      </div>

      {/* RECIPE GRID */}
      {filteredRecipes.length === 0 ? (
        <div className={`text-center py-24 px-4 border border-dashed border-[#2A353D] bg-[#1A2126]/50 rounded-3xl`}>
          <div className="bg-[#12161A] w-20 h-20 mx-auto rounded-full flex items-center justify-center border border-[#2A353D] mb-4 shadow-inner">
            <ChefHat className={T.copper} size={32}/>
          </div>
          <h3 className="text-lg font-black text-white">No specs found.</h3>
          <p className="text-sm font-medium text-slate-500 mt-2">Try adjusting your search or category filter.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {filteredRecipes.map(r => (
            <div key={r.id} onClick={() => { setActiveRecipe(r); setYieldMult(1); }} className="recipe-card-v13 group relative bg-[#1A2126] rounded-lg border border-[#2A353D] hover:border-[#D4A381]/50 overflow-hidden flex flex-col h-full cursor-pointer transition-all duration-200 hover:shadow-[0_8px_24px_rgba(0,0,0,0.24)]">
              
              {/* Card Header Pattern */}
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-[#C59373] to-[#8F6040] opacity-20 group-hover:opacity-100 transition-opacity"></div>
              
              <div className="p-2.5 flex flex-col flex-grow">
                <div className="flex justify-between items-start mb-1.5">
                  <span className="text-[8px] font-black uppercase tracking-widest bg-[#12161A] text-[#D4A381] border border-[#2A353D] px-2 py-0.5 rounded shadow-sm">
                    {r.category}
                  </span>
                  <div className="w-6 h-6 rounded-full bg-[#12161A] border border-[#2A353D] flex items-center justify-center text-slate-400 group-hover:text-[#D4A381] group-hover:bg-[#1A2126] transition-all">
                    <ChevronRight size={13} />
                  </div>
                </div>
                
                <h3 className="text-[15px] font-black text-white mb-1 leading-tight group-hover:text-[#D4A381] transition-colors line-clamp-2">
                  {r.title}
                </h3>
                
                <div className="mt-auto pt-2">
                  <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 bg-[#12161A] p-1.5 rounded-md border border-[#2A353D]">
                    <div className="flex items-center gap-2 min-w-0">
                      <Clock size={12} className="text-slate-500 shrink-0"/> 
                      <span className="truncate">{r.prepTime}</span>
                    </div>
                    <div className="w-px h-4 bg-[#2A353D] shrink-0 mx-2"></div>
                    <div className="flex items-center gap-2 min-w-0">
                      <Scale size={12} className="text-slate-500 shrink-0"/> 
                      <span className="truncate">Yield: {r.yieldAmt}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      
      <Modal isOpen={!!activeRecipe} onClose={() => setActiveRecipe(null)} title="Spec Sheet">
        {activeRecipe && (
          <div className="space-y-6">
            <div className={`border-b ${T.border} pb-4`}><h2 className="text-2xl font-black text-white leading-tight mb-2">{activeRecipe.title}</h2><div className={`flex flex-wrap gap-2 text-xs font-bold ${T.muted}`}><span className={`bg-[#12161A] border ${T.border} px-2 py-1 rounded-md`}>{activeRecipe.category}</span><span className={`bg-[#12161A] border ${T.border} px-2 py-1 rounded-md flex items-center gap-1`}><Clock size={12}/> {activeRecipe.prepTime}</span><span className={`bg-[#12161A] border ${T.border} px-2 py-1 rounded-md flex items-center gap-1 ${yieldMult !== 1 ? T.copper : ''}`}><Scale size={12}/> Yield: {parseAndMultiply(activeRecipe.yieldAmt, yieldMult)}</span></div></div>
            <div className={`flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#12161A] p-3 rounded-xl border ${T.border} mb-6`}><span className={`text-[10px] font-black uppercase ${T.muted} tracking-widest`}>Yield Multiplier</span><div className={`flex bg-[#1A2126] rounded-lg p-1 border ${T.border}`}>{[0.5, 1, 2, 4].map(m => (<button key={m} onClick={() => setYieldMult(m)} className={`px-4 py-1.5 text-xs font-black rounded-md transition-all ${yieldMult === m ? `${T.grad} text-slate-900` : `text-slate-500 hover:text-white`}`}>{m}x</button>))}</div></div>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
              <div className="md:col-span-2 space-y-3"><h4 className={`text-[10px] font-black ${T.muted} uppercase tracking-widest border-b ${T.border} pb-1`}>Ingredients <span className={`lowercase ml-1 ${yieldMult !== 1 ? T.copper : ''}`}>({yieldMult}x)</span></h4><ul className="space-y-2 text-sm font-bold text-slate-300">{activeRecipe.ingredients.split('\n').map((ing, i) => ing.trim() && <li key={i} className="flex items-start gap-2"><div className={`w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0 ${yieldMult !== 1 ? 'bg-[#D4A381]' : 'bg-slate-500'}`}/><span>{parseAndMultiply(ing, yieldMult)}</span></li>)}</ul></div>
              <div className="md:col-span-3 space-y-3"><h4 className={`text-[10px] font-black ${T.muted} uppercase tracking-widest border-b ${T.border} pb-1`}>Method</h4><div className="space-y-3 text-sm font-medium text-slate-300">{activeRecipe.instructions.split('\n').map((step, i) => step.trim() && <p key={i} className="leading-relaxed"><strong className="text-white mr-1">{i+1}.</strong>{step}</p>)}</div></div>
            </div>
            
            <div className={`flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pt-6 border-t ${T.border} mt-6`}>
              <div className={`text-[10px] font-bold ${T.muted}`}>
                Added by {activeRecipe.authorName} <br/> 
                {activeRecipe.lastUpdated && <span className="opacity-70">Updated: {new Date(activeRecipe.lastUpdated).toLocaleDateString()}</span>}
              </div>
              
              {canModifyRecipe && (
                <div className="flex gap-2 w-full sm:w-auto">
                  <button onClick={handleEdit} className="flex-1 sm:flex-none flex justify-center items-center gap-1 text-xs font-bold text-blue-400 hover:text-blue-300 bg-[#12161A] border border-[#2A353D] px-4 py-2 rounded-lg transition-colors"><Edit size={14}/> Edit</button>
                  <button onClick={() => handleDelete(activeRecipe.id)} className="flex-1 sm:flex-none flex justify-center items-center gap-1 text-xs font-bold text-red-500 hover:text-red-400 bg-[#12161A] border border-[#2A353D] px-4 py-2 rounded-lg transition-colors"><Trash2 size={14}/> Delete</button>
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>
      
      <Modal isOpen={isFormOpen} onClose={() => setIsFormOpen(false)} title={editingRecipeId ? "Edit Spec" : "Add New Spec"}>
        <form onSubmit={handleSave} className="space-y-4">
          <div><label className={T.label}>Recipe Title</label><input type="text" value={title} onChange={(e)=>setTitle(e.target.value)} className={T.input} required placeholder="e.g. House Ranch"/></div>
          <div className="grid grid-cols-3 gap-3"><div><label className={T.label}>Category</label><select value={category} onChange={(e)=>setCategory(e.target.value)} className={T.input}>{categories.slice(1).map(c=><option key={c} value={c}>{c}</option>)}</select></div><div><label className={T.label}>Prep Time</label><input type="text" value={prepTime} onChange={(e)=>setPrepTime(e.target.value)} className={T.input} placeholder="e.g. 15 mins"/></div><div><label className={T.label}>Yield</label><input type="text" value={yieldAmt} onChange={(e)=>setYieldAmt(e.target.value)} className={T.input} placeholder="e.g. 4 Quarts"/></div></div>
          <div><label className={T.label}>Ingredients (One per line)</label><textarea value={ingredients} onChange={(e)=>setIngredients(e.target.value)} rows="5" className={T.input} required placeholder="1 Cup Mayo&#10;1/2 Cup Buttermilk&#10;1 Tbsp Dill"/></div>
          <div><label className={T.label}>Method / Instructions (One step per line)</label><textarea value={instructions} onChange={(e)=>setInstructions(e.target.value)} rows="5" className={T.input} required placeholder="Combine mayo and buttermilk in cambro.&#10;Whisk in dry seasoning.&#10;Label and date."/></div>
          <button type="submit" className={`w-full ${T.btn}`}>{editingRecipeId ? "Update Recipe" : "Save Recipe"}</button>
        </form>
      </Modal>
    </div>
  );
};

// --- TIME OFF REQUESTS ---
const TabTimeOff = ({ timeOffRequests, appUser, users, addToast, events = [] }) => {
  const [calMonth, setCalMonth] = useState(getToday().substring(0, 7)); 
  const [selectedDates, setSelectedDates] = useState([]); 
  const [isPartial, setIsPartial] = useState(false); 
  const [startTime, setStartTime] = useState('09:00'); 
  const [endTime, setEndTime] = useState('17:00');

  const myRequests = timeOffRequests.filter(r => r.userId === appUser.id).sort((a,b) => new Date(a.date) - new Date(b.date)); 
  const myFutureRequests = myRequests.filter(r => r.date >= getToday());
  const allFutureRequests = timeOffRequests.filter(r => r.date >= getToday()).sort((a,b) => new Date(a.date) - new Date(b.date));
  
  const monthDays = Array.from({length: getDaysInMonth(calMonth)}).map((_, i) => `${calMonth}-${String(i+1).padStart(2, '0')}`); 
  const firstDayOffset = new Date(calMonth+'-01T12:00:00').getDay();

const monthEvents = events.filter(e => e.type === 'special_event' && e.date?.startsWith(calMonth));
  const changeMonth = (offset) => { 
    const d = new Date(calMonth + '-01T12:00:00'); d.setMonth(d.getMonth() + offset); setCalMonth(d.toISOString().substring(0, 7)); 
  };

  const handleToggleDate = (d) => { 
    if (d < getToday()) return addToast('Locked', 'Cannot request past dates.'); 
    
    const existingReq = myRequests.find(r => r.date === d); 
    if (existingReq) { 
      if (window.confirm(`Cancel your time-off request for ${formatDisplayDate(d)}?`)) {
        deleteDoc(doc(db, "timeOffRequests", existingReq.id));
        addToast('Canceled', 'Time off request removed.');
      }
      return; 
    } 
    
    setSelectedDates(prev => prev.includes(d) ? prev.filter(x => x !== d) : [...prev, d]); 
  };
  
  const handleSubmit = async (e) => { 
    e.preventDefault(); 
    if (selectedDates.length === 0) return addToast('Error', 'Select days on the calendar first.'); 
    if (isPartial && (!startTime || !endTime)) return addToast('Error', 'Please set partial times.'); 
    
    const currentMonth = getToday().substring(0, 7);

    for (const d of selectedDates) { 
      const reqMonth = d.substring(0, 7);
      const needsApproval = reqMonth <= currentMonth;

      await addDoc(collection(db, "timeOffRequests"), { 
        userId: appUser.id, userName: appUser.name, date: d, isPartial, startTime: isPartial ? startTime : null, endTime: isPartial ? endTime : null, submittedAt: new Date().toISOString(), restaurantId: appUser.restaurantId,
        status: needsApproval ? 'pending' : 'approved'
      }); 
    } 
    addToast('Recorded', `Logged ${selectedDates.length} days off.`); 
    setSelectedDates([]); 
    setIsPartial(false); 
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {appUser?.isAdmin && (
        <div className={`${T.card} overflow-hidden mb-6`}>
          <div className={`bg-[#12161A] p-3 border-b ${T.border} flex justify-between items-center`}>
            <h3 className="font-black text-sm text-white flex items-center gap-2"><Shield size={14} className="text-red-500"/> Master Override Log</h3>
            <span className={`text-[10px] font-bold ${T.muted}`}>Approve or delete requests.</span>
          </div>
          <div className={`max-h-48 overflow-y-auto custom-scrollbar divide-y ${T.border}`}>
            {allFutureRequests.length === 0 && <div className={`p-4 text-center text-xs font-bold ${T.muted}`}>No upcoming time off for any staff.</div>}
            {allFutureRequests.map(r => (
              <div key={r.id} className={T.row}>
                <div className="flex-1">
                  <div className="font-black text-sm text-white leading-tight">{r.userName}</div>
          <div className={`text-[10px] font-bold ${T.muted} mt-0.5 flex flex-wrap items-center gap-2`}>
                    {formatDisplayDate(r.date)} {r.isPartial && <span className={`text-[#D4A381] bg-[#12161A] border ${T.border} px-1 rounded`}>({formatShortTime(r.startTime)} - {formatShortTime(r.endTime)})</span>}
                    {r.status === 'pending' && <span className="bg-orange-900/40 text-orange-400 border border-orange-900/50 px-1.5 py-0.5 rounded uppercase tracking-widest text-[8px]">Pending</span>}
                    {r.submittedAt && <span className="text-slate-500 border-l border-[#2A353D] pl-2 ml-1">Req: {new Date(r.submittedAt).toLocaleString([], {month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'})}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {r.status === 'pending' && (
                    <button onClick={() => updateDoc(doc(db, "timeOffRequests", r.id), { status: 'approved' })} className="text-slate-400 hover:text-emerald-500 p-1.5 bg-[#12161A] border border-[#2A353D] rounded"><Check size={14}/></button>
                  )}
                  <button onClick={() => { if(window.confirm("Force delete this request?")) deleteDoc(doc(db,"timeOffRequests",r.id)); }} className="text-slate-400 hover:text-red-500 p-1.5 bg-[#12161A] border border-[#2A353D] rounded"><Trash2 size={14}/></button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className={`md:col-span-2 ${T.card} overflow-hidden`}>
          <div className={`bg-[#12161A] p-3 border-b ${T.border} flex justify-between items-center`}>
            <button onClick={() => changeMonth(-1)} className={T.btnAlt}><ChevronLeft size={16}/></button>
            <h3 className="font-black text-base text-white tracking-tight">{formatDisplayMonth(calMonth)}</h3>
            <button onClick={() => changeMonth(1)} className={T.btnAlt}><ChevronRight size={16}/></button>
          </div>
          <div className={`grid grid-cols-7 border-t ${T.border}`}>
            {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d=><div key={d} className={`py-1.5 text-center text-[9px] font-black ${T.copper} uppercase border-b border-[#2A353D] bg-[#12161A]`}>{d}</div>)}
            {Array.from({length: firstDayOffset}).map((_,i) => <div key={`empty-${i}`} className={`p-1 border-b border-r ${T.border} bg-[#1A2126] min-h-[45px]`} />)}
            {monthDays.map(d => {
              const isSelected = selectedDates.includes(d); 
              const existingReq = myRequests.find(r => r.date === d); 
              const isPast = d < getToday();
              const holiday = getHoliday(d);
              const dayEvents = monthEvents.filter(e => e.date === d);

              return (
                <div key={d} onClick={() => !isPast && handleToggleDate(d)} className={`p-1 border-b border-r ${T.border} min-h-[50px] flex flex-col items-center justify-start pt-1 transition-colors ${isPast ? 'bg-[#12161A]/50 opacity-50 cursor-not-allowed' : existingReq ? 'bg-red-900/10 cursor-pointer hover:bg-red-900/20 border border-red-900/30 shadow-inner' : isSelected ? 'bg-[#8F6040]/20 border border-[#C59373] cursor-pointer shadow-inner' : 'hover:bg-[#12161A] cursor-pointer'}`}>
                  <span className={`text-xs font-black ${isSelected ? T.copper : existingReq ? 'text-red-400' : 'text-slate-300'}`}>{parseInt(d.split('-')[2])}</span>
                  
                  {holiday && <span className="text-[6px] sm:text-[7px] text-amber-500 font-bold uppercase text-center leading-tight mt-0.5 px-0.5">{holiday}</span>}
                  {dayEvents.map(ev => (
                    <span key={ev.id} className="text-[6px] sm:text-[7px] text-blue-400 font-bold uppercase text-center leading-tight mt-0.5 px-0.5 w-full truncate" title={ev.title}>
                      {ev.title}
                    </span>
                  ))}

                  {existingReq && <span className={`text-[7px] font-black uppercase mt-auto mb-1 ${existingReq.status === 'pending' ? 'text-orange-400' : 'text-red-500'}`}>{existingReq.status === 'pending' ? 'Pend' : 'Off'}</span>}
                  {isSelected && <Check size={10} className={`mt-auto mb-1 ${T.copper}`}/>}
                </div>
              )
            })}
          </div>
        </div>

        <div className="md:col-span-1">
          <div className={`${T.card} p-4 sm:p-5 sticky top-20`}>
            <h3 className="font-black text-base mb-1 text-white">Log Availability</h3>
            <p className={`text-[10px] font-bold ${T.muted} mb-4 leading-tight`}>Tap days on the calendar to mark yourself unavailable.</p>
            <form onSubmit={handleSubmit} className="space-y-4">
              <label className={`flex items-center gap-2 text-xs font-bold text-slate-300 cursor-pointer p-2.5 bg-[#12161A] rounded-xl border ${T.border}`}>
                <input type="checkbox" checked={isPartial} onChange={e=>setIsPartial(e.target.checked)} className="w-4 h-4 rounded bg-[#1A2126] border-[#2A353D] accent-[#8F6040]" />
                Partial Day Only?
              </label>
              {isPartial && (
              <div className="grid grid-cols-2 gap-3">
                    <div>
                        <label className={T.label}>Start Time</label>
                        <input type="time" value={startTime} onChange={e=>setStartTime(e.target.value)} className={T.input} required />
                    </div>
                    <div>
                        <label className={T.label}>End Time</label>
                        <input type="time" value={endTime} onChange={e=>setEndTime(e.target.value)} className={T.input} required />
                    </div>
                </div>
              )}
              <button type="submit" disabled={selectedDates.length === 0} className={`w-full ${T.btn} disabled:opacity-50 disabled:cursor-not-allowed`}>Submit {selectedDates.length > 0 ? `(${selectedDates.length})` : ''}</button>
            </form>

            <div className="mt-6 pt-6 border-t border-[#2A353D]">
              <h3 className="font-black text-sm text-white mb-3">My Pending Requests</h3>
              <div className="space-y-2 max-h-60 overflow-y-auto custom-scrollbar">
                {myFutureRequests.length === 0 && <div className="text-xs font-bold text-slate-500 text-center py-2 border border-dashed border-[#2A353D] rounded-xl">No upcoming requests.</div>}
                {myFutureRequests.map(r => (
                  <div key={r.id} className="flex items-center justify-between bg-[#12161A] p-2.5 rounded-xl border border-[#2A353D] hover:border-[#D4A381]/50 transition-colors">
                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-2">
                        {formatDisplayDate(r.date)}
                        {r.status === 'pending' && <span className="bg-orange-900/40 text-orange-400 border border-orange-900/50 px-1 rounded uppercase tracking-widest text-[8px]">Pending</span>}
                      </div>
             {r.isPartial ? (
                        <div className="text-[9px] text-[#D4A381] font-black uppercase tracking-wider mt-0.5">{formatShortTime(r.startTime)} - {formatShortTime(r.endTime)}</div>
                      ) : (
                        <div className="text-[9px] text-red-400 font-black uppercase tracking-wider mt-0.5">Full Day Off</div>
                      )}
                      {r.submittedAt && <div className="text-[9px] font-bold text-slate-500 mt-1">Submitted: {new Date(r.submittedAt).toLocaleString([], {month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'})}</div>}
                    </div>
                    <button
                      type="button"
                      onClick={() => { if(window.confirm(`Cancel your request for ${formatDisplayDate(r.date)}?`)) deleteDoc(doc(db,"timeOffRequests",r.id)); }}
                      className="text-slate-400 hover:text-red-500 p-2 transition-colors bg-[#1A2126] rounded-lg border border-[#2A353D]"
                    >
                      <Trash2 size={14}/>
                    </button>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};


const MapClickListener = ({ setLat, setLon }) => {
  useMapEvents({
    click(e) {
      setLat(e.latlng.lat);
      setLon(e.latlng.lng);
    },
  });
  return null;
};

// --- THE EXPANDED SETTINGS COMMAND CENTER ---
const TabSettings = ({ appUser, addToast, users = [], clientData = {} }) => {  const [subTab, setSubTab] = useState('profile');
  const [newOwnerId, setNewOwnerId] = useState('');

  // --- Profile State ---
  const [name, setName] = useState(appUser?.name || '');
  const [phone, setPhone] = useState(appUser?.phone || '');
  const [photoURL, setPhotoURL] = useState(appUser?.photoURL || '');

  // --- Preferences State ---
  const prefs = appUser?.preferences || {};
  const [defaultTab, setDefaultTab] = useState(prefs.defaultTab || (appUser?.isAdmin ? 'schedule' : 'published'));
  const [timeFormat, setTimeFormat] = useState(prefs.timeFormat || '12h');
  const [uiDensity, setUiDensity] = useState(prefs.uiDensity || 'compact');
  const [recipeDensity, setRecipeDensity] = useState(prefs.recipeDensity || 'tight');
  const [messageView, setMessageView] = useState(prefs.messageView || 'ops');
  const [motionMode, setMotionMode] = useState(prefs.motionMode || 'normal');
  const [showMorningBrief, setShowMorningBrief] = useState(prefs.showMorningBrief ?? true);
  const [payPeriod, setPayPeriod] = useState(prefs.payPeriod || 'Bi-Weekly'); 
  const [payPeriodStart, setPayPeriodStart] = useState(prefs.payPeriodStart || 'Monday');
  
  // --- Notification State ---
  const [notifSchedule, setNotifSchedule] = useState(prefs.notifSchedule ?? true);
  const [notifMessages, setNotifMessages] = useState(prefs.notifMessages ?? true);
  const [notifTrades, setNotifTrades] = useState(prefs.notifTrades ?? true);
  const [notifReminders, setNotifReminders] = useState(prefs.notifReminders ?? false);
  const [reminderTime, setReminderTime] = useState(prefs.reminderTime || '120'); 

  // --- Advanced SaaS Notification States ---
  const [notifLevel, setNotifLevel] = useState(prefs.notifLevel || 'all');
  const [keywords, setKeywords] = useState(prefs.keywords || '');
  const [muteOnDaysOff, setMuteOnDaysOff] = useState(prefs.muteOnDaysOff ?? false);
  const [dndEnabled, setDndEnabled] = useState(prefs.dndEnabled ?? false);
  const [dndStart, setDndStart] = useState(prefs.dndStart || '22:00');
  const [dndEnd, setDndEnd] = useState(prefs.dndEnd || '08:00');

  // --- System Config State (Admin Only) ---
  const sys = appUser?.systemSettings || {};
  const [sysGeofence, setSysGeofence] = useState(sys.geofence ?? false);
  const [sysAddress, setSysAddress] = useState(sys.address || '');
  const [sysLat, setSysLat] = useState(sys.lat || '');
  const [sysLon, setSysLon] = useState(sys.lon || '');
  const [sysRadius, setSysRadius] = useState(sys.geofenceRadius || '300');
  const [sysBreaks, setSysBreaks] = useState(sys.breaks ?? false); 
  const [sysTips, setSysTips] = useState(sys.tips ?? true);
  const [sysTrades, setSysTrades] = useState(sys.trades ?? true);
  const [sysAutoApprove, setSysAutoApprove] = useState(sys.autoApprove ?? false);
  const [sysSameRoleTrades, setSysSameRoleTrades] = useState(sys.sameRoleTrades ?? true);
  const [sysBlockEarly, setSysBlockEarly] = useState(sys.blockEarly ?? true);
  const [sysGracePeriod, setSysGracePeriod] = useState(sys.gracePeriod || '5'); 
  const [sysOvertime, setSysOvertime] = useState(sys.overtime || '40'); 
  const [sysWageAccess, setSysWageAccess] = useState(sys.wageAccess || []);
  const [sysEnableIpWhitelist, setSysEnableIpWhitelist] = useState(sys.enableIpWhitelist ?? false);
  const [sysIpWhitelist, setSysIpWhitelist] = useState(sys.ipWhitelist || '');

const handleEnableNotifications = async () => {
    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        
        // --- NEW: THE SMART TARGET LOCK ---
        const activeVapidKey = window.location.hostname === 'app.86chaos.com' 
          ? 'BJzM9xVnkPwLB6aq588ZHhekjqI_Z-xpInDquX_nknrDhew8ytFZbCA22uFN4iSKP_YvGV0sPH9M6aBzGCA9AcU' // Production
          : 'BO6mdu87G4ICBRZjY5e6mpsvCXdpV32TEyyJzJeQHZ4QXolGNsa6ncvgVAzRxIKihx83AxHS36aCtr--XzE45bc'; // Testing Sandbox

        const currentToken = await getToken(messaging, { 
          vapidKey: activeVapidKey 
        });
        
        if (currentToken) {
          await updateDoc(doc(db, "users", appUser.id), { fcmToken: currentToken });
          addToast('Success', 'Push notifications enabled for this device.');
        }
      } else {
        addToast('Denied', 'You blocked notifications in your browser settings.');
      }
    } catch (error) {
      console.error(error);
      addToast('Error', 'Could not enable notifications.');
    }
  };

  const handleGeocodeAddress = async () => {
    if (!sysAddress.trim()) return addToast('Error', 'Please enter a full address first.');
    addToast('Locating...', 'Searching map database...');
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(sysAddress)}`);
      const data = await res.json();
      if (data && data.length > 0) {
        setSysLat(parseFloat(data[0].lat).toFixed(4));
        setSysLon(parseFloat(data[0].lon).toFixed(4));
        addToast('Found', 'Coordinates locked in.');
      } else {
        addToast('Error', 'Address not found. Try adding city and state.');
      }
    } catch (err) { addToast('Error', 'Failed to reach map service.'); }
  };

  // --- Role Management State (Admin Only) ---
  const [newRoleName, setNewRoleName] = useState('');
  const [newPrepCat, setNewPrepCat] = useState('');
  const dbPrepCats = useLiveCollection('prepCategories', appUser?.restaurantId);
  const [editingRoleId, setEditingRoleId] = useState(null);
  const dbRoles = useLiveCollection('roles', appUser?.restaurantId);
  const DEFAULT_ROLES = ['General Manager', 'Manager', 'Chef', 'Sous Chef', 'Line Cook', 'Prep Cook', 'Bartender', 'Server', 'Host', 'Dishwasher'];
  
  const displayRoles = dbRoles.length > 0 
    ? [...dbRoles].sort((a,b) => a.name.localeCompare(b.name)) 
    : DEFAULT_ROLES.map(r => ({ id: r, name: r, isDefault: true }));

  // --- Image Upload Engine ---
  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) return addToast('File Too Large', 'Please select an image under 5MB.');

    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target.result;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 250;
        const scaleSize = MAX_WIDTH / img.width;
        canvas.width = MAX_WIDTH;
        canvas.height = img.height * scaleSize;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        setPhotoURL(canvas.toDataURL('image/jpeg', 0.8));
      };
    };
  };

  const handleSaveProfile = async (e) => {
    e.preventDefault();
    try {
      await updateDoc(doc(db, "users", appUser.id), { name: name.trim(), phone: phone.trim(), photoURL: photoURL.trim() });
      addToast('Profile Saved', 'Your information has been updated.');
    } catch (err) { addToast('Error', 'Failed to save profile.'); }
  };

  const handleSavePrefs = async (e) => {
    e.preventDefault();
    try {
      await updateDoc(doc(db, "users", appUser.id), {
        preferences: { 
          ...prefs, defaultTab, timeFormat, payPeriod, payPeriodStart,
          notifSchedule, notifMessages, notifTrades, notifReminders, reminderTime,
          notifLevel, keywords, muteOnDaysOff, dndEnabled, dndStart, dndEnd,
          uiDensity, recipeDensity, messageView, motionMode, showMorningBrief
        }
      });
      addToast('Preferences Saved', 'Your personal app settings are locked in.');
    } catch (err) { addToast('Error', 'Failed to save preferences.'); }
  };

  const handleSaveSystem = async (e) => {
    e.preventDefault();
    try {
      const targetId = appUser?.restaurantId || 'legacy-sandbox';
      await setDoc(doc(db, "restaurants", targetId), {
        systemSettings: { 
          geofence: sysGeofence, address: sysAddress, lat: parseFloat(sysLat) || 0, lon: parseFloat(sysLon) || 0, geofenceRadius: parseInt(sysRadius) || 300,
          breaks: sysBreaks, tips: sysTips, trades: sysTrades, autoApprove: sysAutoApprove, sameRoleTrades: sysSameRoleTrades, blockEarly: sysBlockEarly, gracePeriod: sysGracePeriod, overtime: sysOvertime,
          wageAccess: sysWageAccess, enableIpWhitelist: sysEnableIpWhitelist, ipWhitelist: sysIpWhitelist
        }
      }, { merge: true });
      addToast('System Saved', 'Global workspace configurations updated.');
    } catch (err) { addToast('Error', err.message); }
  };

  const handlePasswordReset = async () => {
    try {
      await sendPasswordResetEmail(auth, appUser.email);
      addToast('Email Sent', 'Check your inbox for the password reset link.');
    } catch (err) { addToast('Error', err.message); }
  };

  const handleAddRole = async (e) => {
    e.preventDefault();
    if(!newRoleName.trim()) return;
    if (dbRoles.length === 0) {
      for (const r of DEFAULT_ROLES) await addDoc(collection(db, "roles"), { name: r, restaurantId: appUser.restaurantId });
    }
    await addDoc(collection(db, "roles"), { name: newRoleName.trim(), restaurantId: appUser.restaurantId });
    setNewRoleName('');
    addToast('Role Added', 'New role is now available.');
  };

  const handleSaveRoleEdit = async (role, newName) => {
    if (!newName.trim() || newName.trim() === role.name) {
      setEditingRoleId(null);
      return;
    }
    setEditingRoleId(null);
    if (role.isDefault) {
       for (const r of DEFAULT_ROLES) {
         if (r === role.name) {
           await addDoc(collection(db, "roles"), { name: newName.trim(), restaurantId: appUser.restaurantId });
         } else {
           await addDoc(collection(db, "roles"), { name: r, restaurantId: appUser.restaurantId });
         }
       }
    } else {
       await updateDoc(doc(db, "roles", role.id), { name: newName.trim() });
    }
    addToast('Role Updated', 'Role name changed.');
  };

  const handleDeleteRole = async (role) => {
    if (!window.confirm(`Delete role: ${role.name}?`)) return;
    if (role.isDefault) {
      for (const r of DEFAULT_ROLES) {
        if (r !== role.name) await addDoc(collection(db, "roles"), { name: r, restaurantId: appUser.restaurantId });
      }
    } else {
      await deleteDoc(doc(db, "roles", role.id));
    }
    addToast('Role Deleted', 'Role removed from roster options.');
  };

const Toggle = ({ label, desc, checked, onChange, disabled = false }) => (
    <label className={`flex items-center justify-between p-3 bg-[#12161A] border ${T.border} rounded-xl ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:bg-[#1A2126]'} transition-colors`}>
      <div className="pr-3">
        <div className="text-xs font-bold text-white">{label}</div>
        <div className={`text-[9px] font-medium ${T.muted} mt-0.5 leading-snug`}>{desc}</div>
      </div>
      <div className="relative flex-shrink-0">
        <input type="checkbox" checked={checked} onChange={onChange} disabled={disabled} className="sr-only" />
        <div className={`block w-10 h-6 rounded-full transition-colors ${checked ? 'bg-[#8F6040]' : 'bg-[#2A353D]'}`}></div>
        <div className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${checked ? 'transform translate-x-4' : ''}`}></div>
      </div>
    </label>
  );
  

  return (
    <div className="max-w-4xl mx-auto space-y-4 pb-24 animate-[slideIn_0.2s_ease-out]">
<div className={`grid ${appUser?.isAdmin ? 'grid-cols-2 sm:flex sm:flex-wrap' : 'grid-cols-3'} gap-2 border-b border-[#2A353D] mb-4 pb-2`}>
        {['profile', 'preferences', 'alerts'].concat(appUser?.isAdmin ? ['workspace', 'integrations'] : []).map((tab) => (
<button type="button" key={tab} onClick={() => {
            if (tab === 'integrations' && appUser?.planType !== 'Enterprise') {
              return addToast('Locked', 'Upgrade to Enterprise to unlock POS & Payroll Integrations.');
            }
            setSubTab(tab);
          }} className={`px-2 sm:px-5 py-2 text-[10px] font-black rounded-xl uppercase tracking-widest transition-all sm:flex-1 flex items-center justify-center gap-1 ${subTab === tab ? `${T.grad} text-slate-900 shadow-md` : 'bg-[#1A2126] text-slate-400 hover:text-white'} ${(tab === 'integrations' && appUser?.planType !== 'Enterprise') ? 'opacity-50 border border-[#2A353D] cursor-not-allowed' : ''}`}>
            {(tab === 'integrations' && appUser?.planType !== 'Enterprise') ? '🔒 Integrations' : tab}
            {tab === 'integrations' && <span className="ml-1 bg-blue-900/30 text-blue-400 border border-blue-500/50 text-[8px] px-1.5 py-0.5 rounded-md uppercase tracking-widest font-black shadow-[0_0_8px_rgba(59,130,246,0.2)]">Beta</span>}
          </button>
        ))}
      </div>

      {subTab === 'profile' && (
        <div className="space-y-3">
          <div className={`${T.card} p-3 sm:p-5`}>
            <div className="flex items-center gap-4 mb-4 pb-4 border-b border-[#2A353D]">
              <div className="relative group cursor-pointer">
                <img src={getAvatar(name, photoURL)} alt="Profile" className={`w-14 h-14 rounded-full border-2 border-[#D4A381] object-cover shadow-lg bg-[#12161A]`} />
                <label className="absolute inset-0 flex items-center justify-center bg-black/60 rounded-full opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                  <Edit size={16} className="text-white" />
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                </label>
              </div>
              <div>
                <h2 className="text-lg font-black text-white leading-tight">{name || 'Staff Member'}</h2>
                <div className={`text-[9px] font-black uppercase tracking-widest ${T.copper} mt-0.5`}>{appUser.role} {appUser.isAdmin && '| Admin'}</div>
                <label className="text-[9px] uppercase font-bold text-slate-400 mt-1 block cursor-pointer hover:text-white transition-colors">
                  Tap photo to upload <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                </label>
              </div>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div><label className={T.label}>Full Name</label><input type="text" value={name} onChange={e => setName(e.target.value)} className={`${T.input} py-2 text-sm`} required /></div>
                <div><label className={T.label}>Phone Number</label><input type="tel" value={phone} onChange={e => setPhone(e.target.value)} className={`${T.input} py-2 text-sm`} /></div>
              </div>
              <div>
                <label className={T.label}>Profile Picture URL</label>
                <input type="text" value={photoURL} onChange={e => setPhotoURL(e.target.value)} className={`${T.input} py-2 text-sm`} placeholder="Paste image link here or use the upload button above..." />
              </div>
              <div><label className={T.label}>Email Address (Cannot change)</label><input type="email" value={appUser?.email} disabled className={`${T.input} py-2 text-sm opacity-50 cursor-not-allowed`} /></div>
              <button type="submit" className={`w-full ${T.btn} py-2`}>Save Profile</button>
            </form>
          </div>
          <div className={`${T.card} p-3 sm:p-5 bg-red-900/10 border-red-900/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3`}>
             <div>
               <h3 className="text-xs font-black text-red-500 uppercase tracking-widest mb-1">Security</h3>
               <p className="text-[10px] text-slate-400 font-medium">Get a secure password reset link.</p>
             </div>
             <button type="button" onClick={handlePasswordReset} className="w-full sm:w-auto bg-[#12161A] text-red-400 border border-red-900/50 hover:bg-red-900/30 font-bold px-4 py-2 rounded-xl transition-colors text-xs whitespace-nowrap">Reset Password</button>
          </div>
        </div>
      )}

      {subTab === 'preferences' && (
        <div className="space-y-4">
          <form onSubmit={handleSavePrefs} className={`${T.card} p-3 sm:p-5 space-y-4`}>
            <div>
              <h2 className="text-base font-black text-white mb-3 border-b border-[#2A353D] pb-2">App Experience</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className={T.label}>Default Startup Tab</label>
                  <select value={defaultTab} onChange={e => setDefaultTab(e.target.value)} className={`${T.input} py-2 text-sm`}>
                    <option value="published">My Schedule</option>
                    <option value="messages">Message Board</option>
                    <option value="events">Event Calendar</option>
                    <option value="team">Team Roster</option>
                    {appUser?.isAdmin || appUser?.permissions?.ops ? <option value="ops">Ops Command Center</option> : null}
                    {appUser?.role === 'Kitchen' || appUser?.isAdmin ? <option value="prep">Prep List</option> : null}
                    {appUser?.role === 'Kitchen' || appUser?.isAdmin ? <option value="recipes">Recipe Book</option> : null}
                    {appUser?.isAdmin && <option value="inventory">Inventory & Orders</option>}
                    {appUser?.isAdmin && <option value="schedule">Master Schedule</option>}
                    {appUser?.isAdmin && <option value="sales">Sales Ledger</option>}
                    {appUser?.isAdmin && <option value="maintenance">Maintenance Log</option>}
                  </select>
                </div>
                <div>
                  <label className={T.label}>Time Format</label>
                  <select value={timeFormat} onChange={e => setTimeFormat(e.target.value)} className={`${T.input} py-2 text-sm`}>
                    <option value="12h">12-Hour (AM/PM)</option>
                    <option value="24h">24-Hour (Military)</option>
                  </select>
                </div>
                <div>
                  <label className={T.label}>Interface Density</label>
                  <select value={uiDensity} onChange={e => setUiDensity(e.target.value)} className={`${T.input} py-2 text-sm`}>
                    <option value="ultra">Ultra Compact</option>
                    <option value="compact">Compact</option>
                    <option value="comfortable">Comfortable</option>
                  </select>
                </div>
                <div>
                  <label className={T.label}>Recipe Card Density</label>
                  <select value={recipeDensity} onChange={e => setRecipeDensity(e.target.value)} className={`${T.input} py-2 text-sm`}>
                    <option value="tight">Tight Cards</option>
                    <option value="standard">Standard Cards</option>
                    <option value="detail">Detail Heavy</option>
                  </select>
                </div>
                <div>
                  <label className={T.label}>Message Board Style</label>
                  <select value={messageView} onChange={e => setMessageView(e.target.value)} className={`${T.input} py-2 text-sm`}>
                    <option value="ops">Professional Ops Feed</option>
                    <option value="social">Social Feed</option>
                    <option value="compact">Compact Log</option>
                  </select>
                </div>
                <div>
                  <label className={T.label}>Animation Level</label>
                  <select value={motionMode} onChange={e => setMotionMode(e.target.value)} className={`${T.input} py-2 text-sm`}>
                    <option value="normal">Normal Cockpit Glow</option>
                    <option value="reduced">Reduced Motion</option>
                    <option value="quiet">Quiet Mode</option>
                  </select>
                </div>
              </div>
              <label className="mt-3 flex items-center gap-2 p-2.5 bg-[#12161A] rounded-xl border border-[#2A353D] cursor-pointer hover:bg-[#1A2126] transition-colors">
                <input type="checkbox" checked={showMorningBrief} onChange={e => setShowMorningBrief(e.target.checked)} className="w-4 h-4 accent-[#8F6040]" />
                <span className="text-xs font-bold text-slate-300">Show Morning Brief / Ops summary first when available</span>
              </label>
            </div>
            {appUser?.isAdmin && (
              <div className="pt-2">
                <h2 className="text-base font-black text-emerald-400 mb-3 border-b border-[#2A353D] pb-2">Payroll Settings</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className={T.label}>Default Pay Period</label>
                    <select value={payPeriod} onChange={e => setPayPeriod(e.target.value)} className={`${T.input} py-2 text-sm`}>
                      <option value="Weekly">Weekly</option>
                      <option value="Bi-Weekly">Bi-Weekly</option>
                      <option value="Semi-Monthly">Semi-Monthly</option>
                      <option value="Monthly">Monthly</option>
                    </select>
                  </div>
                  <div>
                    <label className={T.label}>Work Week Starts On</label>
                    <select value={payPeriodStart} onChange={e => setPayPeriodStart(e.target.value)} className={`${T.input} py-2 text-sm`}>
                      {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(d => <option key={d} value={d}>{d}</option>)}
                    </select>
                  </div>
                </div>
              </div>
            )}
            <button type="submit" className={`w-full ${T.btn} py-2`}>Save Preferences</button>
          </form>

          {appUser?.isAdmin && (
            <div className={`${T.card} p-3 sm:p-5 space-y-3 animate-[slideIn_0.2s_ease-out]`}>
              <div>
                <h2 className="text-base font-black text-white mb-1">Roster Roles</h2>
                <p className="text-[10px] text-slate-400 font-medium mb-3">Add, edit, or remove job titles.</p>
                <form onSubmit={handleAddRole} className="flex flex-col sm:flex-row gap-2 mb-3">
                  <input type="text" value={newRoleName} onChange={e=>setNewRoleName(e.target.value)} placeholder="New Role Name..." className={`${T.input} py-2 text-sm`} required />
                  <button type="submit" className={`${T.btn} py-2 whitespace-nowrap`}><Plus size={16} className="inline mr-1"/> Add Role</button>
                </form>
                <div className="flex flex-wrap gap-2">
                  {displayRoles.map(role => (
                    <div key={role.id} className="flex items-center gap-2 bg-[#12161A] border border-[#2A353D] px-2 py-1 rounded-lg shadow-sm">
                      {editingRoleId === role.id ? (
                        <input type="text" autoFocus defaultValue={role.name} onBlur={(e) => handleSaveRoleEdit(role, e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSaveRoleEdit(role, e.target.value)} className="bg-transparent text-white text-[10px] font-bold outline-none border-b border-[#D4A381] w-20" />
                      ) : (
                        <span className="text-[10px] font-bold text-slate-300">{role.name}</span>
                      )}
                      <div className="flex gap-1 border-l border-[#2A353D] pl-1.5 ml-0.5">
                        <button type="button" onClick={() => setEditingRoleId(role.id)} className="text-slate-500 hover:text-[#D4A381]"><Edit size={10}/></button>
                        <button type="button" onClick={() => handleDeleteRole(role)} className="text-slate-500 hover:text-red-500"><Trash2 size={10}/></button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            <div className="pt-4 mt-4 border-t border-[#2A353D]">
                <h2 className="text-base font-black text-white mb-2">Prep Stations</h2>
                <div className="flex gap-2 mb-3">
                  <input type="text" value={newPrepCat} onChange={e=>setNewPrepCat(e.target.value)} placeholder="New Station..." className={`${T.input} py-2 text-sm`} />
                  <button type="button" onClick={async () => { 
                    if(!newPrepCat.trim()) return; 
                    if (dbPrepCats.length === 0) {
                      for (const c of ['Grill', 'Fry', 'Salad/Cold', 'Expo', 'Prep Table']) await addDoc(collection(db, "prepCategories"), { name: c, restaurantId: appUser.restaurantId });
                    }
                    await addDoc(collection(db, "prepCategories"), { name: newPrepCat.trim(), restaurantId: appUser.restaurantId }); 
                    setNewPrepCat(''); 
                  }} className={`${T.btn} py-2 whitespace-nowrap`}>Add Station</button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {(dbPrepCats.length > 0 ? [...dbPrepCats] : ['Grill', 'Fry', 'Salad/Cold', 'Expo', 'Prep Table'].map(c => ({id: c, name: c, isDefault: true}))).sort((a,b) => a.name.localeCompare(b.name)).map(cat => (
                    <div key={cat.id} className="flex items-center gap-2 bg-[#12161A] border border-[#2A353D] px-2 py-1 rounded-lg shadow-sm">
                      <span className="text-[10px] font-bold text-slate-300">{cat.name}</span>
                      <button type="button" onClick={async () => { 
                        if(!window.confirm(`Delete ${cat.name}?`)) return; 
                        if(cat.isDefault) {
                          const defaults = ['Grill', 'Fry', 'Salad/Cold', 'Expo', 'Prep Table'].filter(c => c !== cat.name);
                          for (const c of defaults) await addDoc(collection(db, "prepCategories"), { name: c, restaurantId: appUser.restaurantId });
                        } else {
                          await deleteDoc(doc(db, "prepCategories", cat.id)); 
                        }
                      }} className="text-slate-500 hover:text-red-500 pl-1 border-l border-[#2A353D] ml-1"><Trash2 size={10}/></button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {subTab === 'alerts' && (
        <div className="space-y-4 animate-[slideIn_0.2s_ease-out]">
          <form onSubmit={handleSavePrefs} className={`${T.card} p-3 sm:p-5 space-y-5`}>
            
            {/* SLEEK CONNECTION STATUS BAR */}
            <div className="p-3 bg-[#0B0E11] border border-[#2A353D] rounded-xl flex justify-between items-center gap-3">
              <div>
                <div className="text-sm font-black text-white flex items-center gap-2">Device Connection</div>
                <div className="text-[9px] font-medium text-slate-400 mt-0.5 leading-snug">
                  Browser Status: {typeof window !== 'undefined' && typeof Notification !== 'undefined' ? (Notification.permission === 'granted' ? 'Allowed' : Notification.permission === 'denied' ? 'Blocked via Browser Settings' : 'Not Configured') : 'Not Supported'}
                </div>
              </div>
              {typeof window !== 'undefined' && typeof Notification !== 'undefined' && Notification.permission !== 'granted' && (
                <button onClick={handleEnableNotifications} type="button" className="px-4 py-2 bg-gradient-to-r from-[#C59373] to-[#8F6040] hover:opacity-80 text-slate-900 font-black text-[10px] uppercase tracking-widest rounded-lg transition-colors shadow-md whitespace-nowrap">
                  Connect Device
                </button>
              )}
              {typeof window !== 'undefined' && typeof Notification !== 'undefined' && Notification.permission === 'granted' && (
                <div className="px-3 py-1.5 bg-emerald-900/20 border border-emerald-900/50 text-emerald-500 font-black text-[10px] uppercase tracking-widest rounded-lg flex items-center gap-1">
                  <Check size={12}/> Connected
                </div>
              )}
            </div>

            <div>
              <h2 className="text-base font-black text-white mb-1"><Bell className={`inline mr-2 ${T.copper}`} size={16}/> Alerts & Routing</h2>
              <p className="text-[10px] text-slate-400 font-medium mb-4">Control exactly when and how 86 Chaos pings your device.</p>
              
              <div className="space-y-2 mb-6">
                <Toggle label="Schedule Publications" desc="Get alerted the exact second a new schedule goes live." checked={notifSchedule} onChange={e => setNotifSchedule(e.target.checked)} />
                <Toggle label="Shift Trade Board" desc="Notify me when someone posts a shift they need covered." checked={notifTrades} onChange={e => setNotifTrades(e.target.checked)} />
                <Toggle label="Smart Mute: Days Off" desc="Automatically silence all non-critical notifications if you are not scheduled to work today." checked={muteOnDaysOff} onChange={e => setMuteOnDaysOff(e.target.checked)} />
              </div>

              <h3 className="text-xs font-black uppercase text-[#D4A381] tracking-widest border-b border-[#2A353D] pb-1 mb-3">Message Board Rules</h3>
              <div className="space-y-3 mb-6">
                <select value={notifLevel} onChange={e => setNotifLevel(e.target.value)} className={T.input}>
                  <option value="all">Notify me for ALL new messages</option>
                  <option value="mentions">Only notify me for @mentions & Keywords</option>
                  <option value="critical">Only notify me for Critical Manager Alerts</option>
                </select>

                {notifLevel === 'mentions' && (
                  <div className="animate-[slideIn_0.2s_ease-out]">
                    <label className={T.label}>Keyword Alerts (Comma Separated)</label>
                    <input type="text" value={keywords} onChange={e => setKeywords(e.target.value)} placeholder="e.g. 86, emergency, VIP, cooler" className={`${T.input} text-sm`} />
                    <p className="text-[9px] text-slate-500 mt-1 font-bold">You will be pinged anytime someone types these exact words.</p>
                  </div>
                )}
              </div>

              <h3 className="text-xs font-black uppercase text-[#D4A381] tracking-widest border-b border-[#2A353D] pb-1 mb-3">Timing & Delays</h3>
              <div className="space-y-2">
                <div className={`p-3 bg-[#12161A] border ${T.border} rounded-xl`}>
                  <label className="flex items-center justify-between cursor-pointer group">
                    <div>
                      <div className="text-xs font-bold text-white group-hover:text-[#D4A381] transition-colors">Quiet Hours (Do Not Disturb)</div>
                      <div className={`text-[9px] font-medium ${T.muted} mt-0.5 leading-snug`}>Hold all non-critical notifications until morning.</div>
                    </div>
                    <div className="relative flex-shrink-0">
                      <input type="checkbox" checked={dndEnabled} onChange={e => setDndEnabled(e.target.checked)} className="sr-only" />
                      <div className={`block w-10 h-6 rounded-full transition-colors ${dndEnabled ? 'bg-[#8F6040]' : 'bg-[#2A353D]'}`}></div>
                      <div className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${dndEnabled ? 'transform translate-x-4' : ''}`}></div>
                    </div>
                  </label>
                  {dndEnabled && (
                    <div className="flex items-center gap-3 pt-3 mt-3 border-t border-[#2A353D] animate-[slideIn_0.2s_ease-out]">
                      <input type="time" value={dndStart} onChange={e => setDndStart(e.target.value)} className={`${T.input} py-1.5 text-xs text-center`} />
                      <span className="text-[9px] font-black text-slate-500 uppercase">TO</span>
                      <input type="time" value={dndEnd} onChange={e => setDndEnd(e.target.value)} className={`${T.input} py-1.5 text-xs text-center`} />
                    </div>
                  )}
                </div>

                <div className={`p-3 bg-[#12161A] border ${T.border} rounded-xl`}>
                  <label className="flex items-center justify-between cursor-pointer group">
                    <div>
                      <div className="text-xs font-bold text-white group-hover:text-[#D4A381] transition-colors">Pre-Shift Reminders</div>
                      <div className={`text-[9px] font-medium ${T.muted} mt-0.5 leading-snug`}>Automated ping before your scheduled clock-in time.</div>
                    </div>
                    <div className="relative flex-shrink-0">
                      <input type="checkbox" checked={notifReminders} onChange={e => setNotifReminders(e.target.checked)} className="sr-only" />
                      <div className={`block w-10 h-6 rounded-full transition-colors ${notifReminders ? 'bg-[#8F6040]' : 'bg-[#2A353D]'}`}></div>
                      <div className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${notifReminders ? 'transform translate-x-4' : ''}`}></div>
                    </div>
                  </label>
                  {notifReminders && (
                    <div className="flex items-center justify-between gap-3 pt-3 mt-3 border-t border-[#2A353D] animate-[slideIn_0.2s_ease-out]">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex-1">Minutes Before Shift:</span>
                      <input type="number" min="1" value={reminderTime} onChange={e => setReminderTime(e.target.value)} className={`${T.input} w-20 py-1 text-center text-xs font-black`} placeholder="120" />
                    </div>
                  )}
                </div>
              </div>

            </div>
            <button type="submit" className={`w-full ${T.btn} py-3 text-sm mt-4`}>Save Alert Preferences</button>
          </form>
        </div>
      )}

{subTab === 'workspace' && appUser?.isAdmin && (
        <form onSubmit={handleSaveSystem} className={`${T.card} p-3 sm:p-5 space-y-4 border-[#D4A381]/30 shadow-[0_0_15px_rgba(212,163,129,0.05)]`}>
          <div>
             <div className="flex items-center justify-between mb-1 border-b border-[#2A353D] pb-2">
               <h2 className="text-base font-black text-white"><Shield className={`inline mr-2 ${T.copper}`} size={16}/> Global Config</h2>
               <span className="bg-[#12161A] text-[#D4A381] border border-[#2A353D] px-2 py-0.5 rounded text-[8px] uppercase font-black tracking-widest">Master Controls</span>
             </div>
             
             <div className="mt-4 mb-2 text-[9px] font-black uppercase text-[#D4A381] tracking-widest">Time & Attendance Rules</div>
             <div className="space-y-2">
              <div onClickCapture={(e) => { if (appUser?.planType === 'Starter' || appUser?.planType === 'Pro') { e.stopPropagation(); e.preventDefault(); addToast('Locked', 'Upgrade to Elite to enforce Strict GPS Geofencing.'); } }}>
                <Toggle label={(appUser?.planType === 'Starter' || appUser?.planType === 'Pro') ? '🔒 Strict Geofencing (Elite)' : 'Strict Geofencing (Time Clock)'} desc="Block employees from clocking in if they are not within the GPS boundaries of the restaurant." checked={sysGeofence} onChange={e => setSysGeofence(e.target.checked)} disabled={appUser?.planType === 'Starter' || appUser?.planType === 'Pro'} />
              </div>
              {sysGeofence && appUser?.planType !== 'Starter' && appUser?.planType !== 'Pro' && (
                 <div className="p-3 bg-[#12161A] border border-[#2A353D] rounded-xl space-y-3 animate-[slideIn_0.2s_ease-out] ml-4">
                   <div>
                     <label className={T.label}>Street Address (To auto-find coordinates)</label>
                     <div className="flex gap-2">
                       <input type="text" value={sysAddress} onChange={e=>setSysAddress(e.target.value)} className={`${T.input} py-1.5 text-xs`} placeholder="e.g. 26 N State St, Chilton, WI"/>
                       <button type="button" onClick={handleGeocodeAddress} className={`${T.btn} py-1.5 px-4 text-xs whitespace-nowrap`}>Find GPS</button>
                     </div>
                   </div>
              <div className="grid grid-cols-3 gap-3 pt-3 border-t border-[#2A353D]">
                     <div><label className={T.label}>Latitude</label><input type="number" step="any" value={sysLat} onChange={e=>setSysLat(e.target.value)} className={`${T.input} py-1.5 text-xs`} placeholder="e.g. 44.0300"/></div>
                     <div><label className={T.label}>Longitude</label><input type="number" step="any" value={sysLon} onChange={e=>setSysLon(e.target.value)} className={`${T.input} py-1.5 text-xs`} placeholder="e.g. -88.1630"/></div>
                     <div><label className={T.label}>Radius (Feet)</label><input type="number" min="10" value={sysRadius} onChange={e=>setSysRadius(e.target.value)} className={`${T.input} py-1.5 text-xs`} placeholder="e.g. 300"/></div>
                   </div>

                   <div className="w-full h-80 mt-4 rounded-xl border border-[#2A353D] relative z-0 overflow-hidden shadow-inner">
                     <MapContainer 
                       center={[parseFloat(sysLat) || 44.0296, parseFloat(sysLon) || -88.1633]} 
                       zoom={17} 
                       style={{ height: '100%', width: '100%' }}
                     >
                       <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                       <MapClickListener 
                         setLat={(lat) => setSysLat(lat.toFixed(6))} 
                         setLon={(lon) => setSysLon(lon.toFixed(6))} 
                       />
                       {sysLat && sysLon && (
                         <Marker position={[parseFloat(sysLat), parseFloat(sysLon)]} icon={customMapIcon} />
                       )}
                       {sysLat && sysLon && sysRadius && (
                         <Circle 
                           center={[parseFloat(sysLat), parseFloat(sysLon)]} 
                           radius={parseInt(sysRadius) * 0.3048} 
                           pathOptions={{ color: '#ef4444', fillColor: '#ef4444', fillOpacity: 0.2 }} 
                         />
                       )}
                     </MapContainer>
                   </div>
                   <p className={`text-[10px] ${T.muted} font-bold uppercase tracking-widest mt-2 text-center`}>Click map to set geofence center</p>
                 </div>
               )}
               <div onClickCapture={(e) => { if (appUser?.planType === 'Starter') { e.stopPropagation(); e.preventDefault(); addToast('Locked', 'Upgrade to Pro to unlock Unpaid Break Tracking.'); } }}>
                 <Toggle label={appUser?.planType === 'Starter' ? '🔒 Unpaid Break Tracking (Pro)' : 'Unpaid Break Tracking'} desc="Allow staff to clock out for unpaid breaks during their shift." checked={sysBreaks} onChange={e => setSysBreaks(e.target.checked)} disabled={appUser?.planType === 'Starter'} />
               </div>
               <Toggle label="Block Early Clock-Ins" desc="Prevent staff from punching in before their grace period begins." checked={sysBlockEarly} onChange={e => setSysBlockEarly(e.target.checked)} />
               <div className={`p-3 bg-[#12161A] border ${T.border} rounded-xl flex justify-between items-center gap-3`}>
                 <div>
                   <div className="text-xs font-bold text-white">Clock-In Grace Period</div>
                   <div className={`text-[9px] font-medium ${T.muted} mt-0.5 leading-snug`}>How many minutes early staff can clock in.</div>
                 </div>
                 <input type="number" min="0" value={sysGracePeriod} onChange={e => setSysGracePeriod(e.target.value)} className={`${T.input} w-16 text-center font-black py-1.5 text-xs`} />
               </div>
             </div>

             <div className="mt-5 mb-2 text-[9px] font-black uppercase text-[#D4A381] tracking-widest">Shift Board Rules</div>
             <div className="space-y-2">
               <Toggle label="Enable Peer-to-Peer Trades" desc="Allow staff to post their shifts to the Trade Board for others to claim." checked={sysTrades} onChange={e => setSysTrades(e.target.checked)} />
               <Toggle label="Auto-Approve Shift Swaps" desc="If enabled, shift claims are approved instantly without manager intervention." checked={sysAutoApprove} disabled={!sysTrades} onChange={e => setSysAutoApprove(e.target.checked)} />
               <Toggle label="Role-Restricted Trades" desc="Staff can only claim shifts that match their assigned role." checked={sysSameRoleTrades} disabled={!sysTrades} onChange={e => setSysSameRoleTrades(e.target.checked)} />
             </div>

             <div className="mt-5 mb-2 text-[9px] font-black uppercase text-[#D4A381] tracking-widest">Labor & Payroll</div>
             <div className="space-y-2">
<div onClickCapture={(e) => { if (appUser?.planType === 'Starter' || appUser?.planType === 'Pro') { e.stopPropagation(); e.preventDefault(); addToast('Locked', 'Upgrade to Elite to unlock Mandatory Tip Declarations.'); } }}>
                 <Toggle label={(appUser?.planType === 'Starter' || appUser?.planType === 'Pro') ? '🔒 Mandatory Tip Declaration (Elite)' : 'Mandatory Tip Declaration'} desc="Force tipped employees to declare cash & credit tips before they can clock out." checked={sysTips} onChange={e => setSysTips(e.target.checked)} disabled={appUser?.planType === 'Starter' || appUser?.planType === 'Pro'} />
               </div>               
               <div onClickCapture={(e) => { if (appUser?.planType === 'Starter') { e.stopPropagation(); e.preventDefault(); addToast('Locked', 'Upgrade to Pro to set Overtime Alert Thresholds.'); } }} className={`p-3 bg-[#12161A] border ${T.border} rounded-xl flex justify-between items-center gap-3 ${appUser?.planType === 'Starter' ? 'opacity-50 cursor-not-allowed' : ''}`}>
                 <div>
                   <div className="text-xs font-bold text-white">{appUser?.planType === 'Starter' ? '🔒 Overtime Alert Threshold (Pro)' : 'Overtime Alert Threshold'}</div>
                   <div className={`text-[9px] font-medium ${T.muted} mt-0.5 leading-snug`}>Weekly hours before system flags a manager.</div>
                 </div>
                 <input type="number" min="1" disabled={appUser?.planType === 'Starter'} value={sysOvertime} onChange={e => setSysOvertime(e.target.value)} className={`${T.input} w-16 text-center font-black py-1.5 text-xs disabled:opacity-50`} />
               </div>
             </div>

             <div className="mt-5 mb-2 text-[9px] font-black uppercase text-[#D4A381] tracking-widest">Security & Access Control</div>
             <div className="space-y-2">
               <div onClickCapture={(e) => { if (appUser?.planType === 'Starter' || appUser?.planType === 'Pro') { e.stopPropagation(); e.preventDefault(); addToast('Locked', 'Upgrade to Elite to enforce Strict IP Whitelisting.'); } }}>
                 <Toggle label={(appUser?.planType === 'Starter' || appUser?.planType === 'Pro') ? '🔒 Strict IP Whitelisting (Elite)' : 'Strict IP Whitelisting'} desc="Only allow app access from specific IP addresses (e.g., the restaurant's secure Wi-Fi)." checked={sysEnableIpWhitelist} onChange={e => setSysEnableIpWhitelist(e.target.checked)} disabled={appUser?.planType === 'Starter' || appUser?.planType === 'Pro'} />
               </div>
               
               {sysEnableIpWhitelist && appUser?.planType !== 'Starter' && appUser?.planType !== 'Pro' && (
                 <div className="p-3 bg-[#12161A] border border-[#2A353D] rounded-xl animate-[slideIn_0.2s_ease-out] ml-4">
                   <label className={T.label}>Authorized IP Addresses (Comma Separated)</label>
                   <input type="text" value={sysIpWhitelist} onChange={e=>setSysIpWhitelist(e.target.value)} className={`${T.input} py-1.5 text-xs font-mono`} placeholder="e.g. 192.168.1.1, 10.0.0.5" />
                 </div>
               )}

               <div className="p-3 bg-[#12161A] border border-[#2A353D] rounded-xl mt-2">
                 <div className="text-xs font-bold text-white mb-1">Wage Visibility Exceptions</div>
                 <div className={`text-[9px] font-medium ${T.muted} mb-3 leading-snug`}>By default, only Full Admins can see hourly wages and labor costs. Select specific employees below to grant them exception access to view wages.</div>
                 <div className="max-h-40 overflow-y-auto custom-scrollbar space-y-1 bg-[#0B0E11] p-2 border border-[#2A353D] rounded-lg">
                   {users.filter(u => u.isActive !== false && !u.isAdmin).map(u => (
                     <label key={u.id} className="flex items-center gap-2 cursor-pointer hover:bg-[#1A2126] p-1.5 rounded transition-colors">
                       <input type="checkbox" checked={sysWageAccess.includes(u.id)} onChange={e => {
                         if (e.target.checked) setSysWageAccess([...sysWageAccess, u.id]);
                         else setSysWageAccess(sysWageAccess.filter(id => id !== u.id));
                       }} className="w-3.5 h-3.5 accent-[#8F6040] bg-[#12161A] border-[#2A353D]" />
                       <span className="text-[10px] font-bold text-slate-300">{u.name} <span className="text-slate-500 font-normal">({u.role})</span></span>
                     </label>
                   ))}
                   {users.filter(u => u.isActive !== false && !u.isAdmin).length === 0 && <div className="text-[10px] text-slate-500 text-center py-2">No non-admin staff available.</div>}
                 </div>
               </div>
             </div>

          </div>
          <button type="submit" className={`w-full ${T.btn} py-3 mt-4 text-sm`}>Save Global Workspace</button>
        </form>
      )}

      {/* --- TRANSFER OWNERSHIP ZONE --- */}
      {subTab === 'workspace' && (appUser?.email?.toLowerCase() === clientData?.ownerEmail?.toLowerCase() || appUser?.isSuperAdmin || appUser?.email?.toLowerCase() === 'geoffm1985@gmail.com') && (
        <form onSubmit={async (e) => {
          e.preventDefault();
          if (!newOwnerId) return addToast('Error', 'Select a new owner.');
          if (prompt(`CRITICAL: Type "TRANSFER" to hand over ownership of this workspace. You will lose master control.`) !== 'TRANSFER') return addToast('Aborted', 'Transfer canceled.');
          
          const newOwner = users.find(u => u.id === newOwnerId);
          try {
            await updateDoc(doc(db, "users", newOwner.id), { isAdmin: true });
            await updateDoc(doc(db, "restaurants", appUser.restaurantId), { ownerName: newOwner.name, ownerEmail: newOwner.email });
            addToast('Transferred', `Ownership transferred to ${newOwner.name}.`);
            setNewOwnerId('');
          } catch(err) { addToast('Error', err.message); }
        }} className={`${T.card} p-4 sm:p-5 mt-4 border-red-900/50 shadow-[0_0_15px_rgba(220,38,38,0.1)]`}>
           <div className="mb-3 border-b border-[#2A353D] pb-2">
             <h2 className="text-base font-black text-red-500">Transfer Ownership</h2>
             <p className="text-[10px] text-slate-400 font-medium leading-snug mt-1">Permanently transfer billing and master control to another active team member.</p>
           </div>
           <div className="flex flex-col sm:flex-row gap-3">
             <select value={newOwnerId} onChange={e => setNewOwnerId(e.target.value)} className={T.input} required>
               <option value="">Select New Owner...</option>
               {users.filter(u => u.isActive && u.id !== appUser.id).map(u => (
                 <option key={u.id} value={u.id}>{u.name} ({u.role})</option>
               ))}
             </select>
             <button type="submit" className="bg-red-900/20 text-red-500 font-black tracking-widest uppercase border border-red-900/50 rounded-xl px-6 py-3 hover:bg-red-900/40 transition-colors whitespace-nowrap">Transfer</button>
           </div>
        </form>
      )}

      {/* --- INTEGRATIONS ZONE --- */}
      {subTab === 'integrations' && appUser?.isAdmin && (
        <div className="space-y-6 animate-[slideIn_0.2s_ease-out]">
          
          <div className={`${T.card} p-4 sm:p-5 border-blue-900/50 shadow-[0_0_15px_rgba(59,130,246,0.05)]`}>
             <div className="mb-4 border-b border-[#2A353D] pb-2">
               <h2 className="text-base font-black text-blue-400">Point of Sale (POS) Sync</h2>
               <p className="text-[10px] text-slate-400 font-medium leading-snug mt-1">Automatically pull daily sales data directly into your Daily Ledger.</p>
             </div>
             <form onSubmit={async (e) => {
                e.preventDefault();
                await setDoc(doc(db, "restaurants", appUser.restaurantId), { integrations: { posProvider: e.target.posProvider.value, posApiKey: e.target.posApiKey.value } }, { merge: true });
                addToast('Saved', 'POS API Configuration Saved.');
             }} className="space-y-3">
               <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                 <div>
                   <label className={T.label}>POS Provider</label>
                   <select name="posProvider" defaultValue={clientData?.integrations?.posProvider || ''} className={T.input}>
                     <option value="">None / Manual Entry</option>
                     <option value="Square">Square</option>
                     <option value="Toast">Toast</option>
                     <option value="Clover">Clover</option>
                     <option value="TouchBistro">TouchBistro</option>
                   </select>
                 </div>
                 <div>
                   <label className={T.label}>Secure API Key / Access Token</label>
                   <input type="password" name="posApiKey" defaultValue={clientData?.integrations?.posApiKey || ''} className={T.input} placeholder="sk_live_..." />
                 </div>
               </div>
               <div className="p-3 bg-[#12161A] border border-[#2A353D] rounded-xl">
                 <label className={T.label}>Your Webhook URL (Paste this into your POS dashboard)</label>
                 <code className="text-[10px] text-emerald-400 break-all select-all block mt-1">https://app.86chaos.com/api/webhooks/pos-sync?tenant={appUser.restaurantId}</code>
               </div>
               <button type="submit" className="bg-blue-900/20 text-blue-400 font-black tracking-widest uppercase border border-blue-900/50 rounded-xl w-full py-3 hover:bg-blue-900/40 transition-colors">Connect POS</button>
             </form>
          </div>

          <div className={`${T.card} p-4 sm:p-5 border-emerald-900/50 shadow-[0_0_15px_rgba(16,185,129,0.05)]`}>
             <div className="mb-4 border-b border-[#2A353D] pb-2">
               <h2 className="text-base font-black text-emerald-500">Payroll Provider API</h2>
               <p className="text-[10px] text-slate-400 font-medium leading-snug mt-1">Sync approved timesheets directly to your payroll processor.</p>
             </div>
             <form onSubmit={async (e) => {
                e.preventDefault();
                await setDoc(doc(db, "restaurants", appUser.restaurantId), { integrations: { payrollProvider: e.target.payrollProvider.value, payrollApiKey: e.target.payrollApiKey.value } }, { merge: true });
                addToast('Saved', 'Payroll API Configuration Saved.');
             }} className="space-y-3">
               <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                 <div>
                   <label className={T.label}>Payroll Provider</label>
                   <select name="payrollProvider" defaultValue={clientData?.integrations?.payrollProvider || ''} className={T.input}>
                     <option value="">None / CSV Export Only</option>
                     <option value="Gusto">Gusto</option>
                     <option value="ADP">ADP Run</option>
                     <option value="Paychex">Paychex</option>
                     <option value="QuickBooks">QuickBooks Time</option>
                   </select>
                 </div>
                 <div>
                   <label className={T.label}>Secure API Key / Bearer Token</label>
                   <input type="password" name="payrollApiKey" defaultValue={clientData?.integrations?.payrollApiKey || ''} className={T.input} placeholder="eyJhbGciOiJIUzI1Ni..." />
                 </div>
               </div>
               <button type="submit" className="bg-emerald-900/20 text-emerald-400 font-black tracking-widest uppercase border border-emerald-900/50 rounded-xl w-full py-3 hover:bg-emerald-900/40 transition-colors">Connect Payroll</button>
             </form>
          </div>

        </div>
      )}

    </div>
  );
};


// --- MAINTENANCE LOG TAB ---
const TabMaintenance = ({ appUser, addToast }) => {
  const logs = useLiveCollection('maintenanceLogs', appUser?.restaurantId);
  const pmSchedules = useLiveCollection('pmSchedules', appUser?.restaurantId);
  
  const [subTab, setSubTab] = useState('issues'); // 'issues' or 'pm'
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isPmModalOpen, setIsPmModalOpen] = useState(false);
  
  // Reactive Form State
  const [equipment, setEquipment] = useState('');
  const [issue, setIssue] = useState('');
  const [urgency, setUrgency] = useState('Standard');
  const [status, setStatus] = useState('Reported');
  const [cost, setCost] = useState('');
  const [notes, setNotes] = useState('');
  const [editingLogId, setEditingLogId] = useState(null);

  // PM Form State
  const [pmTitle, setPmTitle] = useState('');
  const [pmEquipment, setPmEquipment] = useState('');
  const [pmDays, setPmDays] = useState('30');
  const [editingPmId, setEditingPmId] = useState(null);

  const resetForm = () => {
    setEquipment(''); setIssue(''); setUrgency('Standard'); 
    setStatus('Reported'); setCost(''); setNotes(''); setEditingLogId(null);
  };

  const resetPmForm = () => {
    setPmTitle(''); setPmEquipment(''); setPmDays('30'); setEditingPmId(null);
  };

  const handleEdit = (log) => {
    setEquipment(log.equipment); setIssue(log.issue); setUrgency(log.urgency);
    setStatus(log.status); setCost(log.cost || ''); setNotes(log.notes || '');
    setEditingLogId(log.id); setIsModalOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!equipment.trim() || !issue.trim()) return addToast('Error', 'Equipment and issue are required.');
    
    const payload = {
      equipment: equipment.trim(),
      issue: issue.trim(),
      urgency,
      status,
      cost: parseFloat(cost) || 0,
      notes: notes.trim(),
      restaurantId: appUser.restaurantId,
      lastUpdated: new Date().toISOString(),
      updatedBy: appUser.name
    };

    try {
      if (editingLogId) {
        if (status === 'Resolved' && logs.find(l => l.id === editingLogId)?.status !== 'Resolved') {
            payload.resolvedAt = new Date().toISOString();
        }
        await updateDoc(doc(db, "maintenanceLogs", editingLogId), payload);
        addToast('Updated', 'Maintenance log updated successfully.');
      } else {
        payload.reportedAt = new Date().toISOString();
        payload.reportedBy = appUser.name;
        await addDoc(collection(db, "maintenanceLogs"), payload);
        addToast('Logged', 'New equipment issue reported.');
      }
      setIsModalOpen(false); resetForm();
    } catch (err) { addToast('Error', err.message); }
  };

  // --- PM ENGINE LOGIC ---
  const handleSavePm = async (e) => {
    e.preventDefault();
    if(!pmTitle || !pmEquipment || !pmDays) return;
    const payload = {
      title: pmTitle.trim(),
      equipment: pmEquipment.trim(),
      frequencyDays: parseInt(pmDays) || 30,
      restaurantId: appUser.restaurantId,
      lastUpdatedBy: appUser.name
    };
    try {
      if (editingPmId) {
        await updateDoc(doc(db, "pmSchedules", editingPmId), payload);
        addToast('Updated', 'PM Schedule updated.');
      } else {
        payload.lastCompleted = getToday(); // Default to today on creation
        await addDoc(collection(db, "pmSchedules"), payload);
        addToast('Created', 'New PM Schedule active.');
      }
      setIsPmModalOpen(false); resetPmForm();
    } catch (err) { addToast('Error', err.message); }
  };

  const handleMarkPmDone = async (pm) => {
    if(!window.confirm(`Mark ${pm.title} as completed for today?`)) return;
    try {
      // 1. Update the PM tracker
      await updateDoc(doc(db, "pmSchedules", pm.id), { lastCompleted: getToday() });
      
      // 2. Auto-generate a historical paper trail in the main logs
      await addDoc(collection(db, "maintenanceLogs"), {
        equipment: pm.equipment,
        issue: `[PM COMPLETED] ${pm.title}`,
        urgency: 'Standard',
        status: 'Resolved',
        cost: 0,
        notes: `Routine Preventative Maintenance. Cycle: ${pm.frequencyDays} days.`,
        restaurantId: appUser.restaurantId,
        reportedAt: new Date().toISOString(),
        reportedBy: appUser.name,
        resolvedAt: new Date().toISOString(),
        updatedBy: appUser.name,
        lastUpdated: new Date().toISOString()
      });
      
      addToast('PM Completed', 'Schedule reset and historical log created.');
    } catch (e) { addToast('Error', e.message); }
  };

  const getStatusColor = (s) => {
    if (s === 'Reported') return 'text-orange-400 bg-orange-900/20 border-orange-900/50';
    if (s === 'In Progress' || s === 'Pending Parts') return 'text-blue-400 bg-blue-900/20 border-blue-900/50';
    if (s === 'Resolved') return 'text-emerald-400 bg-emerald-900/20 border-emerald-900/50';
    return 'text-slate-400 bg-slate-900/20 border-slate-700';
  };

  const getUrgencyColor = (u) => {
    if (u === 'Critical') return 'text-red-500 font-black animate-pulse';
    if (u === 'High') return 'text-orange-500 font-bold';
    return 'text-slate-400';
  };

  // Calculate Overdue PMs for the notification dot
  const todayMs = new Date(getToday()+'T12:00:00').getTime();
  const overdueCount = pmSchedules.filter(pm => {
    const lastMs = new Date(pm.lastCompleted+'T12:00:00').getTime();
    return (pm.frequencyDays - Math.floor((todayMs - lastMs) / 86400000)) <= 0;
  }).length;

  return (
    <div className="max-w-5xl mx-auto space-y-4 pb-24 animate-[slideIn_0.2s_ease-out]">
      
      {/* REACTIVE MODAL */}
      <Modal isOpen={isModalOpen} onClose={() => { setIsModalOpen(false); resetForm(); }} title={editingLogId ? "Update Maintenance Log" : "Report Equipment Issue"}>
        <form onSubmit={handleSave} className="space-y-4 max-h-[70vh] overflow-y-auto custom-scrollbar pr-2">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div><label className={T.label}>Equipment / Area</label><input type="text" value={equipment} onChange={e=>setEquipment(e.target.value)} className={T.input} placeholder="e.g. Walk-in Cooler, Fryer #1" required /></div>
            <div><label className={T.label}>Urgency Level</label><select value={urgency} onChange={e=>setUrgency(e.target.value)} className={T.input}><option value="Standard">Standard (Monitor)</option><option value="High">High (Needs Repair Soon)</option><option value="Critical">Critical (Down/Hazard)</option></select></div>
          </div>
          <div><label className={T.label}>Issue Description</label><textarea value={issue} onChange={e=>setIssue(e.target.value)} rows="2" className={T.input} placeholder="What is broken or acting up?" required></textarea></div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-[#2A353D]">
            <div><label className={T.label}>Current Status</label><select value={status} onChange={e=>setStatus(e.target.value)} className={T.input}><option value="Reported">Reported (Open)</option><option value="In Progress">In Progress</option><option value="Pending Parts">Pending Parts</option><option value="Resolved">Resolved / Fixed</option></select></div>
            <div><label className={T.label}>Repair Cost ($)</label><input type="number" step="0.01" min="0" value={cost} onChange={e=>setCost(e.target.value)} className={T.input} placeholder="Invoice or part cost..." /></div>
          </div>
          <div><label className={T.label}>Repair Notes / Vendor Used</label><input type="text" value={notes} onChange={e=>setNotes(e.target.value)} className={T.input} placeholder="e.g. Call Steve's HVAC, ordered part on Amazon" /></div>
          <button type="submit" className={`w-full ${T.btn} py-3 mt-2`}>{editingLogId ? 'Update Log' : 'Submit Report'}</button>
        </form>
      </Modal>

      {/* PM MODAL */}
      <Modal isOpen={isPmModalOpen} onClose={() => { setIsPmModalOpen(false); resetPmForm(); }} title={editingPmId ? "Edit PM Schedule" : "New Preventative Maintenance"}>
        <form onSubmit={handleSavePm} className="space-y-4">
          <div><label className={T.label}>Task Title</label><input type="text" value={pmTitle} onChange={e=>setPmTitle(e.target.value)} className={T.input} placeholder="e.g. Clean Hood Vents" required /></div>
          <div><label className={T.label}>Equipment / Area</label><input type="text" value={pmEquipment} onChange={e=>setPmEquipment(e.target.value)} className={T.input} placeholder="e.g. Grill Line" required /></div>
          <div><label className={T.label}>Frequency (In Days)</label><input type="number" min="1" value={pmDays} onChange={e=>setPmDays(e.target.value)} className={T.input} placeholder="e.g. 90 for quarterly" required /></div>
          <button type="submit" className={`w-full ${T.btn} py-3 mt-2`}>{editingPmId ? 'Update Schedule' : 'Start Countdown'}</button>
        </form>
      </Modal>

      <div className="flex flex-wrap gap-2 border-b border-[#2A353D] pb-3">
        <button onClick={() => setSubTab('issues')} className={`px-4 py-2 text-[10px] sm:text-xs font-black rounded-xl uppercase tracking-widest transition-all ${subTab === 'issues' ? `${T.grad} text-slate-900 shadow-md` : 'bg-[#1A2126] text-slate-400 hover:text-white'}`}>Reactive Repairs</button>
        <button onClick={() => setSubTab('pm')} className={`relative px-4 py-2 text-[10px] sm:text-xs font-black rounded-xl uppercase tracking-widest transition-all ${subTab === 'pm' ? `${T.grad} text-slate-900 shadow-md` : 'bg-[#1A2126] text-slate-400 hover:text-white'}`}>
          PM Schedules
          {overdueCount > 0 && <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white w-5 h-5 rounded-full flex items-center justify-center text-[10px] shadow-lg animate-pulse">{overdueCount}</span>}
        </button>
      </div>

      {subTab === 'issues' && (
        <div className="space-y-4 animate-[slideIn_0.2s_ease-out]">
          <div className="flex justify-between items-center bg-[#1A2126] p-4 rounded-2xl border border-[#2A353D] shadow-sm">
            <div>
              <h2 className="text-xl font-black text-white flex items-center gap-2"><Wrench className={T.copper} size={20}/> Logged Repairs</h2>
              <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mt-1">Track broken equipment and repair costs.</p>
            </div>
            <button onClick={() => setIsModalOpen(true)} className={`${T.btn} flex items-center gap-2 px-4 py-2 text-xs`}><Plus size={16}/> Report Issue</button>
          </div>

          <div className={`${T.card} overflow-hidden`}>
            <div className={T.th}>Active & Resolved Issues</div>
            <div className={`divide-y ${T.border}`}>
              {logs.length === 0 && <div className="p-8 text-center text-slate-500 font-bold text-sm">No maintenance issues logged.</div>}
              {logs.sort((a,b) => {
                  if (a.status !== 'Resolved' && b.status === 'Resolved') return -1;
                  if (a.status === 'Resolved' && b.status !== 'Resolved') return 1;
                  if (a.urgency === 'Critical' && b.urgency !== 'Critical') return -1;
                  if (b.urgency === 'Critical' && a.urgency !== 'Critical') return 1;
                  return new Date(b.lastUpdated || 0) - new Date(a.lastUpdated || 0);
              }).map(log => (
                <div key={log.id} className={`${T.row} flex flex-col md:flex-row justify-between md:items-center gap-4 ${log.status === 'Resolved' && !log.issue.includes('[PM') ? 'opacity-60 hover:opacity-100 transition-opacity' : ''}`}>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-white text-base">{log.equipment}</span>
                      <span className={`text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded border ${getStatusColor(log.status)}`}>{log.status}</span>
                      {log.issue.includes('[PM COMPLETED]') && <span className="text-[8px] font-black uppercase tracking-widest bg-blue-900/20 text-blue-400 px-2 py-0.5 rounded border border-blue-900/50">Auto-Logged PM</span>}
                      {log.status === 'Resolved' && log.cost > 0 && <span className="text-[8px] font-black uppercase tracking-widest bg-emerald-900/10 text-emerald-500 px-2 py-0.5 rounded border border-emerald-900/30">Cost: ${parseFloat(log.cost).toFixed(2)}</span>}
                    </div>
                    <div className={`text-sm font-medium mt-1 ${log.issue.includes('[PM') ? 'text-blue-300' : 'text-slate-300'}`}>{log.issue}</div>
                    <div className="text-[9px] font-bold uppercase tracking-widest text-slate-500 mt-2 flex gap-3 flex-wrap">
                      {!log.issue.includes('[PM') && <span className={getUrgencyColor(log.urgency)}>Priority: {log.urgency}</span>}
                      <span>Reported: {new Date(log.reportedAt).toLocaleDateString()} by {log.reportedBy}</span>
                      {log.notes && <span className="text-[#D4A381]">Notes: {log.notes}</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-1 md:self-end">
                    <button onClick={() => handleEdit(log)} className="p-2 text-slate-400 hover:text-[#D4A381] bg-[#12161A] rounded-lg border border-[#2A353D] transition-colors"><Edit size={14}/></button>
                    <button onClick={() => { if(window.confirm("Delete this log permanently?")) deleteDoc(doc(db,"maintenanceLogs",log.id)); }} className="p-2 text-slate-400 hover:text-red-500 bg-[#12161A] rounded-lg border border-[#2A353D] transition-colors"><Trash2 size={14}/></button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {subTab === 'pm' && (
        <div className="space-y-4 animate-[slideIn_0.2s_ease-out]">
          <div className="flex justify-between items-center bg-[#1A2126] p-4 rounded-2xl border border-[#2A353D] shadow-sm">
            <div>
              <h2 className="text-xl font-black text-white flex items-center gap-2"><Calendar className={T.copper} size={20}/> Preventative Schedules</h2>
              <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mt-1">Automated countdowns for recurring tasks.</p>
            </div>
            <button onClick={() => setIsPmModalOpen(true)} className={`${T.btn} flex items-center gap-2 px-4 py-2 text-xs`}><Plus size={16}/> New PM</button>
          </div>

          <div className={`${T.card} overflow-hidden`}>
            <div className={T.th}>Active PM Countdowns</div>
            <div className={`divide-y ${T.border}`}>
              {pmSchedules.length === 0 && <div className="p-8 text-center text-slate-500 font-bold text-sm">No preventative maintenance schedules set up.</div>}
              {pmSchedules.sort((a,b) => {
                const aDaysLeft = a.frequencyDays - Math.floor((todayMs - new Date(a.lastCompleted+'T12:00:00').getTime()) / 86400000);
                const bDaysLeft = b.frequencyDays - Math.floor((todayMs - new Date(b.lastCompleted+'T12:00:00').getTime()) / 86400000);
                return aDaysLeft - bDaysLeft;
              }).map(pm => {
                const lastMs = new Date(pm.lastCompleted+'T12:00:00').getTime();
                const daysSince = Math.floor((todayMs - lastMs) / 86400000);
                const daysLeft = pm.frequencyDays - daysSince;
                
                let statusColor = 'text-emerald-500 bg-emerald-900/20 border-emerald-900/50';
                let statusText = `${daysLeft} Days Left`;
                if (daysLeft <= 0) { statusColor = 'text-red-500 bg-red-900/20 border-red-900/50 animate-pulse'; statusText = `OVERDUE (${Math.abs(daysLeft)}d)`; }
                else if (daysLeft <= 7) { statusColor = 'text-orange-400 bg-orange-900/20 border-orange-900/50'; statusText = `DUE SOON (${daysLeft}d)`; }

                return (
                  <div key={pm.id} className={`${T.row} flex flex-col md:flex-row justify-between md:items-center gap-4`}>
                    <div className="flex-1">
                      <div className="font-bold text-white text-base">{pm.title}</div>
                      <div className="text-[10px] font-black uppercase tracking-widest text-[#D4A381] mt-0.5">{pm.equipment} • Every {pm.frequencyDays} Days</div>
                      <div className="text-[9px] text-slate-500 font-bold mt-1 uppercase tracking-widest">Last Done: {new Date(pm.lastCompleted+'T12:00:00').toLocaleDateString()}</div>
                    </div>
                    <div className="flex items-center gap-3 md:self-end">
                      <div className={`text-[10px] font-black uppercase tracking-widest px-3 py-1.5 rounded-lg border ${statusColor}`}>
                        {statusText}
                      </div>
                      <button onClick={() => handleMarkPmDone(pm)} className="bg-[#12161A] text-emerald-500 border border-[#2A353D] hover:bg-[#1A2126] hover:border-emerald-900/50 font-black text-[10px] uppercase tracking-widest px-3 py-1.5 rounded-lg transition-colors shadow-sm flex items-center gap-1">
                        <Check size={14}/> Mark Done
                      </button>
                      <div className="flex gap-1 border-l border-[#2A353D] pl-2 ml-1">
                        <button onClick={() => { setPmTitle(pm.title); setPmEquipment(pm.equipment); setPmDays(pm.frequencyDays.toString()); setEditingPmId(pm.id); setIsPmModalOpen(true); }} className="p-1.5 text-slate-400 hover:text-[#D4A381] transition-colors"><Edit size={14}/></button>
                        <button onClick={() => { if(window.confirm("Delete this PM Schedule?")) deleteDoc(doc(db,"pmSchedules",pm.id)); }} className="p-1.5 text-slate-400 hover:text-red-500 transition-colors"><Trash2 size={14}/></button>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};



// --- AUDIT LOGS TAB (Master Admin Only) ---
const TabAuditLog = ({ appUser }) => {
  const logs = useLiveCollection('auditLogs', appUser?.restaurantId);
  const isGeoff = appUser?.email?.toLowerCase() === 'geoffm1985@gmail.com';
  const sortedLogs = [...logs]
    .filter(log => isGeoff ? true : log.action !== 'APP_INSTALLED')
    .sort((a,b) => new Date(b.timestamp) - new Date(a.timestamp));

  return (
    <div className="max-w-4xl mx-auto space-y-4 pb-24 animate-[slideIn_0.2s_ease-out]">
      <div className={`${T.card} overflow-hidden`}>
        <div className={`bg-[#12161A] p-4 border-b ${T.border} flex justify-between items-center`}>
          <h2 className="text-lg font-black text-white flex items-center gap-2"><Shield className="text-red-500"/> System Audit Logs</h2>
          <span className={`bg-red-900/20 border border-red-500/50 text-red-500 px-3 py-1 rounded-full font-black text-[10px] uppercase tracking-widest`}>Master Admin View</span>
        </div>
        
        <div className={`divide-y ${T.border} max-h-[70vh] overflow-y-auto custom-scrollbar`}>
          {sortedLogs.length === 0 && <div className="p-8 text-center text-slate-500 font-bold">No security events logged yet.</div>}
          
          {sortedLogs.map(log => (
            <div key={log.id} className={`${T.row} flex flex-col sm:flex-row gap-2 sm:justify-between sm:items-center`}>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-bold text-white text-sm">{log.userName}</span>
                  <span className={`text-[9px] uppercase font-black tracking-widest bg-[#12161A] border ${T.border} text-red-400 px-2 py-0.5 rounded`}>{log.action}</span>
                </div>
                <div className="text-xs text-slate-300 font-medium">
                  {log.details} <span className="text-slate-500 ml-1">Target: [{log.target}]</span>
                </div>
              </div>
              <div className={`text-[10px] font-bold ${T.muted} whitespace-nowrap`}>
                {new Date(log.timestamp).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// --- SALES & TRENDS TAB ---

// ============================================================================
// OPS COMMAND CENTER
// A rescue-safe "kitchen brain" layer that ties existing modules together
// without forcing a folder refactor yet. Uses existing Firestore collections.
// ============================================================================
const TabOpsCenter = ({ currentDate, appUser, users = [], shifts = [], events = [], sales = [], timePunches = [], addToast }) => {
  const inventoryItems = useLiveCollection('inventoryItems', appUser?.restaurantId);
  const wasteLogs = useLiveCollection('wasteLogs', appUser?.restaurantId);
  const maintenanceLogs = useLiveCollection('maintenanceLogs', appUser?.restaurantId);
  const pmSchedules = useLiveCollection('pmSchedules', appUser?.restaurantId);
  const tasks = useLiveCollection('tasks', appUser?.restaurantId);
  const recipes = useLiveCollection('recipes', appUser?.restaurantId);

  const today = currentDate || getToday();
  const todayDate = new Date(today + 'T12:00:00');
  const yesterdayDate = new Date(todayDate);
  yesterdayDate.setDate(todayDate.getDate() - 1);
  const yesterday = formatDate(yesterdayDate);
  const todayName = todayDate.toLocaleDateString('en-US', { weekday: 'long' });
  const monthStr = getMonthStr(today);

  const sameDay = (date) => date === today;
  const openMaintenance = maintenanceLogs.filter(l => (l.status || 'Reported') !== 'Resolved');
  const criticalMaintenance = openMaintenance.filter(l => l.urgency === 'Critical' || l.urgency === 'High');
  const lowStockItems = inventoryItems
    .filter(i => Number(i.parLevel || 0) > 0 && Number(i.currentStock || 0) < Number(i.parLevel || 0))
    .sort((a, b) => ((Number(a.currentStock || 0) / Math.max(1, Number(a.parLevel || 1))) - (Number(b.currentStock || 0) / Math.max(1, Number(b.parLevel || 1)))));
  const pendingOrderItems = inventoryItems.filter(i => Number(i.pendingQty || 0) > 0);
  const todayWaste = wasteLogs.filter(w => w.date === today);
  const todayEvents = events.filter(e => (e.date || '').startsWith(today) || e.date === today);
  const importantEvents = todayEvents.filter(e => e.isImportant || (e.title || '').toLowerCase().includes('86'));
  const todayShifts = shifts.filter(s => s.date === today && s.isPublished).sort((a,b) => (a.startTime || '').localeCompare(b.startTime || ''));
  const activePunches = timePunches.filter(p => p.date === today && ['clocked_in', 'on_break'].includes(p.status));
  const yesterdaySales = sales.find(s => s.date === yesterday);
  const todaySales = sales.find(s => s.date === today);
  const monthSales = sales.filter(s => (s.date || '').startsWith(monthStr));

  const parseShiftHours = (start, end) => {
    if (!start || !end) return 0;
    const [sh, sm] = String(start).split(':').map(Number);
    let eh = 23; let em = 0;
    if (end !== 'CLOSE') {
      const parts = String(end).split(':').map(Number);
      eh = parts[0]; em = parts[1] || 0;
    }
    const startM = (sh * 60) + (sm || 0);
    let endM = (eh * 60) + (em || 0);
    if (endM <= startM) endM += 24 * 60;
    return Math.max(0, (endM - startM) / 60);
  };

  const punchHours = (p) => {
    if (!p.clockInTime) return 0;
    const end = p.clockOutTime ? new Date(p.clockOutTime) : new Date();
    const rawMins = (end - new Date(p.clockInTime)) / 60000;
    return Math.max(0, (rawMins - Number(p.breakMinutes || 0)) / 60);
  };

  const todayLaborCost = timePunches.filter(p => p.date === today).reduce((sum, p) => {
    const emp = users.find(u => u.id === p.employeeId);
    return sum + (punchHours(p) * Number(emp?.wage || 0));
  }, 0);

  const taskPeriodKey = (task, dateStr) => {
    if ((task.frequency || 'daily') === 'daily') return dateStr;
    if (task.frequency === 'weekly') {
      const d = new Date(dateStr + 'T12:00:00');
      const day = d.getDay();
      d.setDate(d.getDate() - day + (day === 0 ? -6 : 1));
      return formatDate(d);
    }
    if (task.frequency === 'monthly') return dateStr.substring(0, 7);
    return dateStr;
  };

  const taskIsDueToday = (task) => {
    if ((task.frequency || 'daily') === 'daily') return true;
    if (task.frequency === 'weekly') return !task.targetDay || task.targetDay === todayName;
    if (task.frequency === 'monthly') return String(task.targetDate || '1') === String(todayDate.getDate());
    return true;
  };

  const dueTasks = tasks.filter(taskIsDueToday);
  const doneTasks = dueTasks.filter(t => !!t.completions?.[taskPeriodKey(t, today)]);
  const openTasks = dueTasks.filter(t => !t.completions?.[taskPeriodKey(t, today)]);
  const taskPct = dueTasks.length ? Math.round((doneTasks.length / dueTasks.length) * 100) : 100;

  const todayMs = new Date(today + 'T12:00:00').getTime();
  const overduePm = pmSchedules.filter(pm => {
    if (!pm.lastCompleted) return true;
    const lastMs = new Date(pm.lastCompleted + 'T12:00:00').getTime();
    const daysSince = Math.floor((todayMs - lastMs) / 86400000);
    return (Number(pm.frequencyDays || 30) - daysSince) <= 0;
  });

  const avgMonthSales = monthSales.length ? monthSales.reduce((s, d) => s + Number(d.grossSales || 0), 0) / monthSales.length : 0;
  const sameWeekdaySales = sales.filter(s => {
    if (!s.date || s.date >= today) return false;
    return new Date(s.date + 'T12:00:00').getDay() === todayDate.getDay();
  }).slice(-8);
  const forecastSales = sameWeekdaySales.length
    ? sameWeekdaySales.reduce((sum, s) => sum + Number(s.grossSales || 0), 0) / sameWeekdaySales.length
    : avgMonthSales;

  const laborPct = todaySales?.grossSales ? Math.round((todayLaborCost / Math.max(1, Number(todaySales.grossSales))) * 1000) / 10 : null;
  const wasteCost = todayWaste.reduce((sum, w) => sum + Number(w.cost || 0), 0);

  const healthParts = [
    Math.max(0, 100 - (lowStockItems.length * 4)),
    Math.max(0, 100 - (openMaintenance.length * 8) - (criticalMaintenance.length * 10)),
    taskPct,
    Math.max(0, 100 - (todayWaste.length * 6)),
    laborPct === null ? 90 : Math.max(0, 100 - Math.max(0, laborPct - 25) * 4)
  ];
  const healthScore = Math.round(healthParts.reduce((a,b)=>a+b,0) / healthParts.length);

  const prepForecast = [
    { label: 'Forecast Sales', value: forecastSales ? `$${Math.round(forecastSales).toLocaleString()}` : 'Needs sales data', note: sameWeekdaySales.length ? 'Based on same weekdays' : 'Based on month average' },
    { label: 'Kitchen Coverage', value: `${todayShifts.filter(s => ['Kitchen','Cook','Line Cook','Prep Cook','Chef','Sous Chef'].includes(s.role)).length} scheduled`, note: `${todayShifts.length} total published shifts` },
    { label: 'Prep Pressure', value: forecastSales > avgMonthSales * 1.15 && avgMonthSales > 0 ? 'High' : forecastSales > 0 ? 'Normal' : 'Unknown', note: forecastSales > avgMonthSales * 1.15 && avgMonthSales > 0 ? 'Sales forecast is above normal' : 'No spike detected' },
    { label: 'Low Stock', value: `${lowStockItems.length} items`, note: lowStockItems.slice(0, 3).map(i => i.name).join(', ') || 'No par issues found' }
  ];

  const scheduleWarnings = users.map(u => {
    const weekShifts = shifts.filter(s => s.employeeId === u.id && s.isPublished && s.date >= today && s.date <= formatDate(new Date(todayDate.getTime() + 6 * 86400000)));
    const hours = weekShifts.reduce((sum, s) => sum + parseShiftHours(s.startTime, s.endTime), 0);
    const days = [...new Set(weekShifts.map(s => s.date))].length;
    if (hours >= 38) return `${u.name} is projected near overtime (${hours.toFixed(1)} hrs).`;
    if (days >= 6) return `${u.name} has ${days} scheduled days in the next week.`;
    return null;
  }).filter(Boolean).slice(0, 5);

  const recommendations = [
    lowStockItems.length > 0 ? `Order check: ${lowStockItems.slice(0, 3).map(i => i.name).join(', ')} ${lowStockItems.length > 3 ? `and ${lowStockItems.length - 3} more` : ''}.` : 'Inventory pars look clean right now.',
    criticalMaintenance.length > 0 ? `Maintenance first: ${criticalMaintenance[0].equipment} needs attention.` : 'No high priority equipment fires showing.',
    openTasks.length > 0 ? `Opening focus: ${openTasks.slice(0, 3).map(t => t.title).join(', ')}.` : 'Today\'s task list is buttoned up.',
    overduePm.length > 0 ? `Preventative maintenance overdue: ${overduePm.slice(0, 2).map(pm => pm.title).join(', ')}.` : 'Preventative maintenance countdowns are quiet.',
    scheduleWarnings.length > 0 ? scheduleWarnings[0] : 'No immediate schedule warnings detected.'
  ];

  const stockNeed = (item) => Math.max(0, Math.ceil(Number(item.parLevel || 0) - Number(item.currentStock || 0)));
  const urgent86Items = lowStockItems.filter(i => Number(i.currentStock || 0) <= 0 || (Number(i.parLevel || 0) > 0 && Number(i.currentStock || 0) / Math.max(1, Number(i.parLevel || 1)) <= 0.25));
  const suggestedPrepTasks = [
    ...lowStockItems.slice(0, 4).map(i => `Prep/order recovery: ${i.name} is below par by ${stockNeed(i)}.`),
    forecastSales > avgMonthSales * 1.15 && avgMonthSales > 0 ? 'High forecast: add backup proteins, fries, sauces, and expo garnish before rush.' : null,
    importantEvents.length > 0 ? `Event prep: review ${importantEvents.slice(0, 2).map(e => e.title).join(' / ')}.` : null,
    criticalMaintenance.length > 0 ? `Equipment watch: ${criticalMaintenance[0].equipment} needs manager follow-up.` : null,
    todayShifts.filter(s => ['Kitchen','Cook','Line Cook','Prep Cook','Chef','Sous Chef'].includes(s.role)).length < 2 ? 'Coverage risk: verify kitchen backup plan before peak service.' : null
  ].filter(Boolean).slice(0, 8);

  const handleBuildSmartOrder = async () => {
    const items = lowStockItems.filter(i => stockNeed(i) > 0);
    if (items.length === 0) return addToast('Smart Order', 'No below-par items found.');
    if (!window.confirm(`Build pending order quantities for ${items.length} below-par items?`)) return;
    try {
      await Promise.all(items.map(i => updateDoc(doc(db, 'inventoryItems', i.id), {
        pendingQty: Math.max(Number(i.pendingQty || 0), stockNeed(i)),
        lastSmartOrderDate: getToday(),
        lastSmartOrderBy: appUser?.name || 'Ops Command Center'
      })));
      await logAudit(appUser, 'SMART_ORDER_BUILT', 'inventoryItems', `Queued ${items.length} below-par items from Ops Command Center.`);
      addToast('Smart Order Built', `${items.length} item(s) queued for ordering.`);
    } catch (err) { addToast('Error', err.message); }
  };

  const handleCreateSmartPrepTasks = async () => {
    if (suggestedPrepTasks.length === 0) return addToast('Smart Prep', 'No smart prep tasks needed right now.');
    if (!window.confirm(`Create ${suggestedPrepTasks.length} smart prep task(s) for today?`)) return;
    try {
      const existingToday = new Set(tasks.filter(t => t.source === 'ops-smart-prep' && t.generatedForDate === today).map(t => t.title));
      const adds = suggestedPrepTasks
        .filter(title => !existingToday.has(title))
        .map(title => addDoc(collection(db, 'tasks'), {
          title,
          category: 'Smart Prep',
          frequency: 'daily',
          generatedForDate: today,
          generatedAt: new Date().toISOString(),
          source: 'ops-smart-prep',
          completions: {},
          restaurantId: appUser.restaurantId
        }));
      await Promise.all(adds);
      await logAudit(appUser, 'SMART_PREP_CREATED', 'tasks', `Created ${adds.length} smart prep tasks for ${today}.`);
      addToast('Smart Prep Created', `${adds.length} task(s) added to Prep & Tasks.`);
    } catch (err) { addToast('Error', err.message); }
  };

  const handlePost86Alert = async () => {
    if (urgent86Items.length === 0) return addToast('86 Radar', 'No urgent 86/low-stock items found.');
    const alertLines = urgent86Items.slice(0, 10).map(i => `• ${i.name}: ${Number(i.currentStock || 0)} on hand / par ${Number(i.parLevel || 0)}`);
    const text = `86 / Low Stock Watch:\n${alertLines.join('\n')}`;
    try {
      await addDoc(collection(db, 'events'), {
        date: new Date().toISOString(), title: text, type: 'note', author: appUser?.name || 'Ops Command Center', isImportant: true, restaurantId: appUser.restaurantId, replies: []
      });
      addToast('86 Alert Posted', 'Important low-stock alert posted to Message Board.');
    } catch (err) { addToast('Error', err.message); }
  };

  const handleMarkOpsReviewed = async () => {
    try {
      await logAudit(appUser, 'OPS_REVIEWED', 'ops', `Reviewed Ops Command Center for ${today}. Health score ${healthScore}/100.`);
      addToast('Ops Reviewed', 'Review logged to audit trail.');
    } catch (err) { addToast('Error', err.message); }
  };

  const timeline = [
    ...timePunches.filter(p => p.date === today).map(p => ({
      at: p.clockOutTime || p.clockInTime,
      type: p.clockOutTime ? 'Clock Out' : 'Clock In',
      title: `${p.employeeName || users.find(u => u.id === p.employeeId)?.name || 'Staff'} ${p.clockOutTime ? 'clocked out' : 'clocked in'}`,
      detail: p.status || ''
    })),
    ...todayWaste.map(w => ({ at: w.timestamp || today, type: 'Waste', title: `${w.itemName || 'Item'} wasted`, detail: `${w.qty || ''} ${w.reason || ''}` })),
    ...maintenanceLogs.filter(l => (l.reportedAt || '').startsWith(today) || (l.lastUpdated || '').startsWith(today)).map(l => ({ at: l.lastUpdated || l.reportedAt, type: 'Maintenance', title: l.equipment, detail: l.issue })),
    ...todayEvents.map(e => ({ at: e.date || e.timestamp || today, type: e.type || 'Event', title: e.title || 'Event', detail: e.author || '' })),
    ...todayShifts.slice(0, 12).map(s => ({ at: `${today}T${s.startTime || '00:00'}:00`, type: 'Scheduled', title: `${users.find(u => u.id === s.employeeId)?.name || 'Staff'} ${s.role || ''}`, detail: `${formatShortTime(s.startTime)} - ${formatShortTime(s.endTime)}` }))
  ].filter(x => x.at).sort((a,b) => new Date(b.at) - new Date(a.at)).slice(0, 18);

  const briefText = () => {
    const lines = [
      `Good morning, ${appUser?.name?.split(' ')[0] || 'team'}.`,
      `Restaurant health score: ${healthScore}/100.`,
      yesterdaySales ? `Yesterday sales: $${Number(yesterdaySales.grossSales || 0).toLocaleString()}.` : 'Yesterday sales are not entered yet.',
      todaySales ? `Today sales entered: $${Number(todaySales.grossSales || 0).toLocaleString()}.` : 'Today sales are not entered yet.',
      `Today: ${todayShifts.length} shifts, ${activePunches.length} currently clocked in.`,
      `Open tasks: ${openTasks.length}. Low-stock items: ${lowStockItems.length}. Open maintenance: ${openMaintenance.length}.`,
      `Top priority: ${recommendations.find(Boolean) || 'Keep service smooth.'}`
    ];
    return lines.join('\n');
  };

  const handlePostBrief = async () => {
    try {
      await addDoc(collection(db, 'events'), {
        date: new Date().toISOString(),
        title: briefText(),
        type: 'note',
        author: appUser?.name || 'Ops Command Center',
        isImportant: false,
        restaurantId: appUser.restaurantId,
        replies: []
      });
      addToast('Morning Brief Posted', 'Saved to the Message Board for the team.');
    } catch (err) {
      addToast('Error', err.message);
    }
  };

  const handleSeedKitchenOps = async () => {
    if (!window.confirm('Add the default end-all kitchen tasks and PM schedules? Existing matching titles will be skipped.')) return;
    const defaultTasks = [
      { title: 'Opening line check completed', category: 'General', frequency: 'daily' },
      { title: 'Cooler and freezer temps logged', category: 'General', frequency: 'daily' },
      { title: '86 list reviewed with FOH', category: 'General', frequency: 'daily' },
      { title: 'Fryer filter and oil quality checked', category: 'Cleaning', frequency: 'daily' },
      { title: 'Expo station stocked before rush', category: 'General', frequency: 'daily' },
      { title: 'Walk-in shelves wiped down', category: 'Cleaning', frequency: 'weekly', targetDay: 'Monday' },
      { title: 'Deep clean fryer bay', category: 'Cleaning', frequency: 'weekly', targetDay: 'Tuesday' },
      { title: 'Check first aid and burn kit', category: 'General', frequency: 'monthly', targetDate: '1' }
    ];
    const defaultPm = [
      { title: 'Clean hood filters', equipment: 'Hood System', frequencyDays: 7 },
      { title: 'Delime dish machine', equipment: 'Dish Machine', frequencyDays: 30 },
      { title: 'Inspect cooler gaskets', equipment: 'Coolers', frequencyDays: 30 },
      { title: 'Grease trap service check', equipment: 'Grease Trap', frequencyDays: 30 },
      { title: 'Fire suppression visual check', equipment: 'Fire Suppression', frequencyDays: 90 }
    ];
    try {
      const existingTaskTitles = new Set(tasks.map(t => (t.title || '').toLowerCase()));
      const existingPmTitles = new Set(pmSchedules.map(p => (p.title || '').toLowerCase()));
      const taskAdds = defaultTasks
        .filter(t => !existingTaskTitles.has(t.title.toLowerCase()))
        .map(t => addDoc(collection(db, 'tasks'), { ...t, completions: {}, restaurantId: appUser.restaurantId }));
      const pmAdds = defaultPm
        .filter(p => !existingPmTitles.has(p.title.toLowerCase()))
        .map(p => addDoc(collection(db, 'pmSchedules'), { ...p, lastCompleted: getToday(), lastUpdatedBy: appUser.name, restaurantId: appUser.restaurantId }));
      await Promise.all([...taskAdds, ...pmAdds]);
      addToast('Kitchen Ops Seeded', `Added ${taskAdds.length + pmAdds.length} operating standards.`);
    } catch (err) {
      addToast('Error', err.message);
    }
  };

  const kpiCards = [
    { label: 'Health Score', value: `${healthScore}/100`, detail: healthScore >= 85 ? 'Strong shift posture' : healthScore >= 70 ? 'Watch the weak spots' : 'Needs manager attention' },
    { label: 'Open Tasks', value: `${openTasks.length}`, detail: `${doneTasks.length}/${dueTasks.length || 0} completed today` },
    { label: 'Low Stock', value: `${lowStockItems.length}`, detail: `${pendingOrderItems.length} already pending` },
    { label: 'Maintenance', value: `${openMaintenance.length}`, detail: `${criticalMaintenance.length} high priority` },
    { label: 'Labor Now', value: laborPct === null ? `$${todayLaborCost.toFixed(0)}` : `${laborPct}%`, detail: activePunches.length ? `${activePunches.length} on clock` : 'Nobody clocked in' },
    { label: 'Waste Today', value: `${todayWaste.length}`, detail: wasteCost ? `$${wasteCost.toFixed(2)} logged` : 'No cost logged' }
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-4 pb-24 animate-[slideIn_0.2s_ease-out]">
      <div className={`${T.card} p-5 bg-gradient-to-br from-[#1A2126] to-[#12161A] overflow-hidden relative`}>
        <div className="absolute -top-8 -right-6 text-[120px] font-black text-[#D4A381]/5 leading-none">86</div>
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="text-[10px] font-black uppercase tracking-[0.35em] text-[#D4A381] mb-2">Morning Brief</div>
            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">Kitchen Command Center</h1>
            <p className="text-sm text-slate-400 font-medium mt-2 max-w-2xl">A live cockpit for prep, people, inventory, maintenance, labor, waste, and the little gremlins that usually wait until dinner rush.</p>
          </div>
          <div className="grid grid-cols-2 sm:flex sm:flex-wrap gap-2">
            <button onClick={handlePostBrief} className={`${T.btn} flex items-center justify-center gap-2`}><Send size={16}/> Post Brief</button>
            <button onClick={handleCreateSmartPrepTasks} className={`${T.btnAlt} flex items-center justify-center gap-2`}><ClipboardList size={16}/> Prep Plan</button>
            <button onClick={handleBuildSmartOrder} className={`${T.btnAlt} flex items-center justify-center gap-2`}><Package size={16}/> Smart Order</button>
            <button onClick={handlePost86Alert} className={`${T.btnAlt} flex items-center justify-center gap-2`}><Bell size={16}/> 86 Alert</button>
            <button onClick={handleMarkOpsReviewed} className={`${T.btnAlt} flex items-center justify-center gap-2`}><Check size={16}/> Reviewed</button>
            {(appUser?.isAdmin || appUser?.permissions?.prep || appUser?.permissions?.team) && <button onClick={handleSeedKitchenOps} className={`${T.btnAlt} flex items-center justify-center gap-2`}><Plus size={16}/> Seed Standards</button>}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-6 gap-2">
        {kpiCards.map(card => (
          <div key={card.label} className={`${T.card} p-3 text-center`}>
            <div className={`text-[9px] font-black uppercase tracking-widest ${T.muted}`}>{card.label}</div>
            <div className="text-xl font-black text-[#D4A381] mt-1">{card.value}</div>
            <div className="text-[10px] text-slate-500 font-bold mt-1 truncate">{card.detail}</div>
          </div>
        ))}
      </div>

      <div className={`${T.card} p-4 grid grid-cols-1 lg:grid-cols-3 gap-3`}>
        <div className="lg:col-span-2">
          <h2 className="font-black text-white flex items-center gap-2"><Scale size={18} className={T.copper}/> Smart Action Dock</h2>
          <p className="text-xs text-slate-400 font-bold mt-1">These buttons turn the dashboard into actual work: pending orders, prep tasks, 86 alerts, and audit trail checkpoints.</p>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="bg-[#12161A] border border-[#2A353D] rounded-xl p-2"><div className="text-[9px] font-black uppercase tracking-widest text-slate-500">Suggested Prep</div><div className="text-xl font-black text-white">{suggestedPrepTasks.length}</div></div>
          <div className="bg-[#12161A] border border-[#2A353D] rounded-xl p-2"><div className="text-[9px] font-black uppercase tracking-widest text-slate-500">86 Watch</div><div className={`text-xl font-black ${urgent86Items.length ? 'text-red-400' : 'text-emerald-400'}`}>{urgent86Items.length}</div></div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className={`${T.card} p-4 lg:col-span-2`}>
          <div className="flex items-center justify-between border-b border-[#2A353D] pb-3 mb-3">
            <h2 className="font-black text-white flex items-center gap-2"><ChefHat size={18} className={T.copper}/> Manager Readout</h2>
            <span className="text-[9px] font-black uppercase tracking-widest text-slate-500">{formatDisplayFullDate(today)}</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {recommendations.map((rec, idx) => (
              <div key={idx} className="bg-[#12161A] border border-[#2A353D] rounded-xl p-3">
                <div className="text-[9px] font-black uppercase tracking-widest text-[#D4A381] mb-1">Priority {idx + 1}</div>
                <div className="text-sm font-bold text-slate-200 leading-snug">{rec}</div>
              </div>
            ))}
          </div>
        </div>

        <div className={`${T.card} p-4`}>
          <h2 className="font-black text-white flex items-center gap-2 border-b border-[#2A353D] pb-3 mb-3"><TrendingUp size={18} className={T.copper}/> Smart Prep Forecast</h2>
          <div className="space-y-2">
            {prepForecast.map(row => (
              <div key={row.label} className="flex justify-between gap-3 bg-[#12161A] border border-[#2A353D] rounded-xl p-3">
                <div>
                  <div className="text-[9px] font-black uppercase tracking-widest text-slate-500">{row.label}</div>
                  <div className="text-xs text-slate-400 font-bold mt-1">{row.note}</div>
                </div>
                <div className="text-sm font-black text-[#D4A381] text-right whitespace-nowrap">{row.value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className={`${T.card} overflow-hidden`}>
          <div className={`${T.th} flex items-center gap-2`}><Package size={14}/> Inventory Radar</div>
          <div className={`divide-y ${T.border} max-h-[360px] overflow-y-auto custom-scrollbar`}>
            {lowStockItems.length === 0 && <div className="p-6 text-center text-slate-500 font-bold text-sm">No par problems detected.</div>}
            {lowStockItems.slice(0, 12).map(item => {
              const par = Number(item.parLevel || 0);
              const stock = Number(item.currentStock || 0);
              const needed = Math.max(0, par - stock);
              return (
                <div key={item.id} className={`${T.row} flex justify-between items-center gap-3`}>
                  <div className="min-w-0">
                    <div className="text-sm font-bold text-white truncate">{item.name}</div>
                    <div className="text-[9px] uppercase tracking-widest text-slate-500 font-black">Stock {stock} / Par {par}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-black text-orange-400">Order {needed}</div>
                    <div className="text-[9px] text-slate-500 font-bold">${Number(item.price || 0).toFixed(2)}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className={`${T.card} overflow-hidden`}>
          <div className={`${T.th} flex items-center gap-2`}><Wrench size={14}/> Equipment Radar</div>
          <div className={`divide-y ${T.border} max-h-[360px] overflow-y-auto custom-scrollbar`}>
            {openMaintenance.length === 0 && overduePm.length === 0 && <div className="p-6 text-center text-slate-500 font-bold text-sm">No equipment warnings right now.</div>}
            {criticalMaintenance.concat(openMaintenance.filter(l => !criticalMaintenance.includes(l))).slice(0, 8).map(log => (
              <div key={log.id} className={`${T.row}`}>
                <div className="flex justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm font-bold text-white truncate">{log.equipment}</div>
                    <div className="text-xs text-slate-400 font-medium mt-1 line-clamp-2">{log.issue}</div>
                  </div>
                  <span className={`text-[9px] font-black uppercase tracking-widest ${log.urgency === 'Critical' ? 'text-red-500' : log.urgency === 'High' ? 'text-orange-400' : 'text-slate-500'}`}>{log.urgency || 'Standard'}</span>
                </div>
              </div>
            ))}
            {overduePm.slice(0, 4).map(pm => (
              <div key={pm.id} className={`${T.row} bg-red-950/10`}>
                <div className="text-sm font-bold text-red-300">PM Overdue: {pm.title}</div>
                <div className="text-[9px] text-slate-500 font-black uppercase tracking-widest mt-1">{pm.equipment} • every {pm.frequencyDays} days</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className={`${T.card} overflow-hidden`}>
          <div className={`${T.th} flex items-center gap-2`}><Users size={14}/> Labor & Schedule Warnings</div>
          <div className={`divide-y ${T.border}`}>
            {scheduleWarnings.length === 0 && <div className="p-6 text-center text-slate-500 font-bold text-sm">No obvious schedule warnings in the next week.</div>}
            {scheduleWarnings.map((w, idx) => <div key={idx} className={`${T.row} text-sm font-bold text-slate-200`}>{w}</div>)}
            {todayShifts.slice(0, 8).map(s => (
              <div key={s.id} className={`${T.row} flex justify-between items-center text-xs`}>
                <span className="font-bold text-white">{users.find(u => u.id === s.employeeId)?.name || 'Staff'} <span className="text-slate-500">{s.role}</span></span>
                <span className="font-mono text-[#D4A381]">{formatShortTime(s.startTime)} - {formatShortTime(s.endTime)}</span>
              </div>
            ))}
          </div>
        </div>

        <div className={`${T.card} overflow-hidden`}>
          <div className={`${T.th} flex items-center gap-2`}><Clock size={14}/> Kitchen Timeline</div>
          <div className={`divide-y ${T.border} max-h-[420px] overflow-y-auto custom-scrollbar`}>
            {timeline.length === 0 && <div className="p-6 text-center text-slate-500 font-bold text-sm">No timeline activity for this day yet.</div>}
            {timeline.map((item, idx) => (
              <div key={`${item.type}-${idx}`} className={`${T.row} flex gap-3`}>
                <div className="text-[10px] font-mono text-[#D4A381] w-16 flex-shrink-0">{new Date(item.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                <div className="min-w-0">
                  <div className="text-[9px] font-black uppercase tracking-widest text-slate-500">{item.type}</div>
                  <div className="text-sm font-bold text-white truncate">{item.title}</div>
                  {item.detail && <div className="text-xs text-slate-400 truncate">{item.detail}</div>}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className={`${T.card} p-4`}>
        <div className="flex items-center justify-between border-b border-[#2A353D] pb-3 mb-3">
          <h2 className="font-black text-white flex items-center gap-2"><BookOpen size={18} className={T.copper}/> Recipe & Menu Brain</h2>
          <span className="text-[9px] font-black uppercase tracking-widest text-slate-500">{recipes.length} recipes tracked</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="bg-[#12161A] border border-[#2A353D] rounded-xl p-3">
            <div className="text-[9px] font-black uppercase tracking-widest text-[#D4A381] mb-1">Use Before It Hurts</div>
            <div className="text-sm font-bold text-white">{lowStockItems.length ? 'Avoid specials using low-stock items.' : 'Inventory is flexible enough for specials.'}</div>
          </div>
          <div className="bg-[#12161A] border border-[#2A353D] rounded-xl p-3">
            <div className="text-[9px] font-black uppercase tracking-widest text-[#D4A381] mb-1">Specials Signal</div>
            <div className="text-sm font-bold text-white">{forecastSales > avgMonthSales * 1.15 && avgMonthSales > 0 ? 'Run fast, high-margin items today.' : 'Normal day: good test window for a new special.'}</div>
          </div>
          <div className="bg-[#12161A] border border-[#2A353D] rounded-xl p-3">
            <div className="text-[9px] font-black uppercase tracking-widest text-[#D4A381] mb-1">86 Watch</div>
            <div className="text-sm font-bold text-white">{importantEvents.length ? importantEvents[0].title : 'No critical 86 notes posted today.'}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

const TabSales = ({ sales, timePunches = [], users = [], addToast, appUser }) => {
  const getMonday = (dStr) => {
    const d = new Date(dStr + 'T12:00:00');
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    return new Date(d.setDate(diff));
  };

  const [weekStart, setWeekStart] = useState(getMonday(getToday()));
  const [editData, setEditData] = useState({});

  const weekDays = Array.from({length: 7}).map((_, i) => {
    const d = new Date(weekStart);
    d.setDate(d.getDate() + i);
    return d.toISOString().split('T')[0];
  });

  // --- AUTO-LABOR CALCULATION ENGINE ---
  const calculatePunchHours = (inTime, outTime, breakMins = 0) => {
      if (!inTime) return 0;
      const end = outTime ? new Date(outTime) : new Date(); // If currently on clock, calc up to this exact minute
      const rawMins = (end - new Date(inTime)) / 60000;
      return Math.max(0, (rawMins - breakMins) / 60);
  };

  const getDailyLabor = (date) => {
      const dayPunches = timePunches.filter(p => p.date === date);
      return dayPunches.reduce((acc, p) => {
          const emp = users.find(u => u.id === p.employeeId);
          const hours = calculatePunchHours(p.clockInTime, p.clockOutTime, p.breakMinutes || 0);
          return acc + (hours * (emp?.wage || 0));
      }, 0);
  };

  useEffect(() => {
    const newEditData = {};
    weekDays.forEach(date => {
      const daySale = sales.find(s => s.date === date);
      newEditData[date] = {
        grossSales: daySale?.grossSales || '',
        laborCost: daySale?.laborCost !== undefined ? daySale.laborCost : '',
        foodCost: daySale?.foodCost || '',
        notes: daySale?.notes || ''
      };
    });
    setEditData(newEditData);
  }, [weekStart, sales]);

  const changeWeek = (offset) => {
    const newDate = new Date(weekStart);
    newDate.setDate(newDate.getDate() + (offset * 7));
    setWeekStart(newDate);
  };

  const handleSave = async (date) => {
    const data = editData[date];
    const existing = sales.find(s => s.date === date);
    const autoLabor = getDailyLabor(date);
    
    // If they didn't type anything, grab the auto-calculated labor
    const finalLabor = data.laborCost !== '' ? parseFloat(data.laborCost) : autoLabor;

    const payload = {
      date,
      grossSales: parseFloat(data.grossSales) || 0,
      laborCost: finalLabor || 0,
      foodCost: parseFloat(data.foodCost) || 0,
      notes: data.notes || '',
      restaurantId: appUser.restaurantId,
      loggedBy: appUser.name,
      timestamp: new Date().toISOString()
    };

    try {
      if (existing) {
        await updateDoc(doc(db, "sales", existing.id), payload);
      } else {
        await addDoc(collection(db, "sales"), payload);
      }
      addToast('Saved', `Data for ${new Date(date+'T12:00').toLocaleDateString()} locked in.`);
    } catch (err) {
      addToast('Error', err.message);
    }
  };

  const handleInputChange = (date, field, value) => {
    setEditData(prev => ({ ...prev, [date]: { ...prev[date], [field]: value } }));
  };

  let wtdGross = 0; let wtdLabor = 0; let wtdFood = 0;
  weekDays.forEach(d => {
    const s = sales.find(x => x.date === d);
    const autoLabor = getDailyLabor(d);
    if (s) { 
      wtdGross += (s.grossSales||0); 
      wtdLabor += (s.laborCost > 0 ? s.laborCost : autoLabor); 
      wtdFood += (s.foodCost||0); 
    } else {
      wtdLabor += autoLabor; // Add auto-labor even if not saved yet to show running trends
    }
  });
  
  const wtdLaborPct = wtdGross > 0 ? ((wtdLabor / wtdGross) * 100).toFixed(1) : 0;
  const wtdFoodPct = wtdGross > 0 ? ((wtdFood / wtdGross) * 100).toFixed(1) : 0;
  const wtdProfit = wtdGross - (wtdLabor + wtdFood);

  return (
    <div className="max-w-4xl mx-auto space-y-4 pb-24 animate-[slideIn_0.2s_ease-out]">
      
      {/* Tight Weekly Controls */}
      <div className="flex justify-between items-center bg-[#1A2126] border border-[#2A353D] rounded-xl p-2 shadow-sm">
         <button onClick={() => changeWeek(-1)} className="p-2 bg-[#12161A] text-slate-400 rounded-lg hover:text-[#D4A381] border border-[#2A353D] transition-colors"><ChevronLeft size={18} /></button>
         <div className="text-center">
           <h2 className="text-sm font-black text-white uppercase tracking-widest">Week of {weekStart.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</h2>
         </div>
         <button onClick={() => changeWeek(1)} className="p-2 bg-[#12161A] text-slate-400 rounded-lg hover:text-[#D4A381] border border-[#2A353D] transition-colors"><ChevronRight size={18} /></button>
      </div>

      {/* Expanded WTD KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <div className={`${T.card} p-2 sm:p-3 text-center`}><div className={`text-[8px] sm:text-[10px] font-black uppercase tracking-widest ${T.muted}`}>WTD Gross</div><div className="text-sm sm:text-lg font-black text-[#D4A381]">${wtdGross.toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 0})}</div></div>
        <div className={`${T.card} p-2 sm:p-3 text-center`}><div className={`text-[8px] sm:text-[10px] font-black uppercase tracking-widest ${T.muted}`}>WTD Labor</div><div className={`text-sm sm:text-lg font-black ${wtdLaborPct > 30 ? 'text-red-400' : 'text-emerald-400'}`}>{wtdLaborPct}%</div></div>
        <div className={`${T.card} p-2 sm:p-3 text-center`}><div className={`text-[8px] sm:text-[10px] font-black uppercase tracking-widest ${T.muted}`}>WTD Food</div><div className={`text-sm sm:text-lg font-black ${wtdFoodPct > 33 ? 'text-red-400' : 'text-emerald-400'}`}>{wtdFoodPct}%</div></div>
        <div className={`${T.card} p-2
 sm:p-3 text-center`}><div className={`text-[8px] sm:text-[10px] font-black uppercase tracking-widest ${T.muted}`}>WTD Profit</div><div className={`text-sm sm:text-lg font-black ${wtdProfit < 0 ? 'text-red-400' : 'text-emerald-400'}`}>${wtdProfit.toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 0})}</div></div>
      </div>

      {/* Ultra-Compact 7-Day Ledger with Notes */}
      <div className={`${T.card} overflow-hidden`}>
         <div className="divide-y divide-[#2A353D]">
           {weekDays.map(date => {
              const data = editData[date] || { grossSales: '', laborCost: '', foodCost: '', notes: '' };
              const isToday = date === getToday();
              const hasData = sales.find(s => s.date === date);
              const autoLabor = getDailyLabor(date);
              
              const displayLabor = data.laborCost !== '' ? data.laborCost : (autoLabor > 0 ? autoLabor.toFixed(2) : '');

              return (
                <div key={date} className={`p-2 sm:p-3 flex flex-col gap-2 ${isToday ? 'bg-[#12161A] border-l-2 border-[#D4A381]' : 'hover:bg-[#12161A]/50 transition-colors'}`}>
                   <div className="flex justify-between items-center">
                      <span className={`text-[10px] font-black uppercase tracking-widest ${isToday ? 'text-[#D4A381]' : 'text-slate-300'}`}>{new Date(date+'T12:00').toLocaleDateString('en-US', {weekday:'short', month:'numeric', day:'numeric'})}</span>
                      <div className="flex items-center gap-2">
                         {data.laborCost === '' && autoLabor > 0 && <span className="text-[8px] text-emerald-500 font-black uppercase tracking-widest bg-emerald-900/20 px-1.5 py-0.5 rounded border border-emerald-900/50">Auto-Labor</span>}
                         {hasData && <span className="text-[8px] text-[#D4A381] font-black uppercase tracking-widest bg-[#8F6040]/20 px-1.5 py-0.5 rounded border border-[#D4A381]/30">Saved</span>}
                         {hasData && appUser?.isAdmin && <button onClick={() => { if(window.confirm("Delete record?")) deleteDoc(doc(db,"sales",hasData.id)); }} className="text-slate-500 hover:text-red-500"><Trash2 size={12}/></button>}
                      </div>
                   </div>
                   <div className="flex flex-col gap-1.5">
                      <div className="flex gap-1.5">
                        <div className="relative flex-1"><span className="absolute left-1.5 top-1/2 -translate-y-1/2 text-[9px] text-slate-500 font-bold">$</span><input type="number" value={data.grossSales} onChange={e=>handleInputChange(date, 'grossSales', e.target.value)} placeholder="Gross" className="w-full bg-[#0B0E11] border border-[#2A353D] text-white text-[10px] sm:text-xs font-bold pl-4 pr-1 py-1.5 rounded outline-none focus:border-[#D4A381]" /></div>
                        <div className="relative flex-1"><span className={`absolute left-1.5 top-1/2 -translate-y-1/2 text-[9px] font-bold ${data.laborCost === '' && autoLabor > 0 ? 'text-emerald-500' : 'text-slate-500'}`}>$</span><input type="number" value={displayLabor} onChange={e=>handleInputChange(date, 'laborCost', e.target.value)} placeholder="Labor" className={`w-full bg-[#0B0E11] border border-[#2A353D] text-[10px] sm:text-xs font-bold pl-4 pr-1 py-1.5 rounded outline-none focus:border-[#D4A381] ${data.laborCost === '' && autoLabor > 0 ? 'text-emerald-400 bg-emerald-900/10 border-emerald-900/50' : 'text-white'}`} /></div>
                        <div className="relative flex-1"><span className="absolute left-1.5 top-1/2 -translate-y-1/2 text-[9px] text-slate-500 font-bold">$</span><input type="number" value={data.foodCost} onChange={e=>handleInputChange(date, 'foodCost', e.target.value)} placeholder="Food" className="w-full bg-[#0B0E11] border border-[#2A353D] text-white text-[10px] sm:text-xs font-bold pl-4 pr-1 py-1.5 rounded outline-none focus:border-[#D4A381]" /></div>
                      </div>
                      <div className="flex gap-1.5">
                        <input type="text" value={data.notes} onChange={e=>handleInputChange(date, 'notes', e.target.value)} placeholder="Context notes (e.g., Event, Weather, Promos)..." className="flex-1 w-full bg-[#0B0E11] border border-[#2A353D] text-slate-300 text-[10px] sm:text-xs font-medium px-2 py-1.5 rounded outline-none focus:border-[#D4A381]" />
                        <button onClick={()=>handleSave(date)} className="w-16 bg-gradient-to-r from-[#C59373] to-[#8F6040] text-slate-900 text-[10px] font-black uppercase tracking-wider rounded flex items-center justify-center flex-shrink-0 hover:opacity-80 transition-opacity">Save</button>
                      </div>
                   </div>
                </div>
              )
           })}
         </div>
      </div>
    </div>
  );
};

// ============================================================================
// ADMINISTRATOR COMMAND CENTER (Formerly God Mode)
// ============================================================================
const TabGodMode = ({ appUser, addToast, setGhostTenant, setActiveTab }) => {  const [subTab, setSubTab] = useState('overview');
  
  // Master Data States
  const [restaurants, setRestaurants] = useState([]);
  const [superAdmins, setSuperAdmins] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [crashLogs, setCrashLogs] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [userCounts, setUserCounts] = useState({});
  const [totalInstalls, setTotalInstalls] = useState(0); 

// Form States
  const [rName, setRName] = useState(''); const [rAddress, setRAddress] = useState(''); const [oName, setOName] = useState(''); const [oEmail, setOEmail] = useState(''); const [oPhone, setOPhone] = useState('');  const [adminEmail, setAdminEmail] = useState('');
  const [broadcastMsg, setBroadcastMsg] = useState('');
const [editingRest, setEditingRest] = useState(null);
  const [forgeEventTitle, setForgeEventTitle] = useState(''); const [forgeEventDate, setForgeEventDate] = useState(getToday());
  const [userSearch, setUserSearch] = useState('');
  const [bulkDeleteEmails, setBulkDeleteEmails] = useState('');
  const [isBulkDeletingUsers, setIsBulkDeletingUsers] = useState(false);

// Pricing & MRR States
  const [tierPrices, setTierPrices] = useState({ Starter: 39, Pro: 99, Elite: 149, Enterprise: 199 });
  const [isEditingPrices, setIsEditingPrices] = useState(false);
  
  // Live Banner States
  const [bannerTarget, setBannerTarget] = useState('ALL');
  const [bannerText, setBannerText] = useState('');

  const handlePushBanner = async (e) => {
    e.preventDefault();
    if (!bannerText.trim()) return addToast('Error', 'Banner text required.');
    if (!window.confirm("Pin this banner to the top of the app?")) return;
    
    addToast('Deploying', 'Pushing banner to selected workspace(s)...');
    try {
      if (bannerTarget === 'ALL') {
        const promises = restaurants.map(r => updateDoc(doc(db, "restaurants", r.id), { systemBanner: bannerText.trim() }));
        await Promise.all(promises);
      } else {
        await updateDoc(doc(db, "restaurants", bannerTarget), { systemBanner: bannerText.trim() });
      }
      addToast('Success', 'Banner deployed successfully.');
      setBannerText('');
    } catch(err) { addToast('Error', err.message); }
  };

  const handleClearBanner = async () => {
    if (!window.confirm("Clear active banners for the selected target?")) return;
    addToast('Clearing', 'Removing banners...');
    try {
      if (bannerTarget === 'ALL') {
        const promises = restaurants.map(r => updateDoc(doc(db, "restaurants", r.id), { systemBanner: null }));
        await Promise.all(promises);
      } else {
        await updateDoc(doc(db, "restaurants", bannerTarget), { systemBanner: null });
      }
      addToast('Success', 'Banner(s) cleared.');
    } catch(err) { addToast('Error', err.message); }
  };
  
  // Nuke Security States
  const [nukeTarget, setNukeTarget] = useState(null);
  const [nukePassword, setNukePassword] = useState('');
  const [isNuking, setIsNuking] = useState(false);
  // --- RAW JSON INSPECTOR STATE ---
  const [isRawInspectorOpen, setIsRawInspectorOpen] = useState(false);
  const [rawInspectorId, setRawInspectorId] = useState('');
  const [rawInspectorCollection, setRawInspectorCollection] = useState('users');
  const [rawInspectorData, setRawInspectorData] = useState(null);

  const handleFetchRawDoc = async (e) => {
    e.preventDefault();
    if (!rawInspectorId.trim()) return;
    try {
      const docSnap = await getDoc(doc(db, rawInspectorCollection, rawInspectorId.trim()));
      if (docSnap.exists()) setRawInspectorData({ id: docSnap.id, ...docSnap.data() });
      else addToast('Not Found', 'No document found with that ID in that collection.');
    } catch(err) { addToast('Error', err.message); }
  };

  // Fetch Global Intelligence
  useEffect(() => {
    const unsubRests = onSnapshot(collection(db, 'restaurants'), snap => setRestaurants(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
    const unsubAdmins = onSnapshot(query(collection(db, 'users'), where('isSuperAdmin', '==', true)), snap => setSuperAdmins(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
    const unsubUsers = onSnapshot(collection(db, 'users'), snap => {
      const uList = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setAllUsers(uList);
      const counts = {}; uList.forEach(u => { if (u.restaurantId) counts[u.restaurantId] = (counts[u.restaurantId] || 0) + 1; });
      setUserCounts(counts);
    });
    const unsubCrashes = onSnapshot(collection(db, 'crashReports'), snap => setCrashLogs(snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a,b) => new Date(b.time||0) - new Date(a.time||0)).slice(0, 50)));
const unsubAudit = onSnapshot(collection(db, 'auditLogs'), snap => {
       const rawLogs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
       setAuditLogs(rawLogs.sort((a,b) => new Date(b.timestamp) - new Date(a.timestamp)).slice(0, 100));
       setTotalInstalls(rawLogs.filter(log => log.action === 'APP_INSTALLED').length);
    });
    const unsubPricing = onSnapshot(doc(db, 'system', 'pricing'), doc => {
       if (doc.exists()) setTierPrices(doc.data());
    });
    return () => { unsubRests(); unsubAdmins(); unsubUsers(); unsubCrashes(); unsubAudit(); unsubPricing(); };
  }, []);

// --- 1. TENANT MANAGEMENT & DEPLOYMENT ---

   const handleDeleteTenant = async (tenantId, tenantName) => {
    if (prompt(`CRITICAL: Type "DELETE" to permanently remove the workspace registry for ${tenantName}. \n\nNOTE: You should use the 'Danger Zone' Nuke tool in the Manage menu first to wipe their underlying data.`) !== 'DELETE') {
      return addToast('Aborted', 'Workspace deletion canceled.');
    }

    addToast('Deleting', `Removing workspace ${tenantName}...`);
    try {
      await deleteDoc(doc(db, "restaurants", tenantId));
      addToast('Deleted', `${tenantName} has been permanently removed from the roster.`);
    } catch (err) {
      addToast('Error', err.message);
    }
  };                 
  const handleDeployTenant = async (e) => {
    e.preventDefault(); 
    if (!rName.trim() || !oEmail.trim() || !oName.trim() || !rAddress.trim()) return;
    
    addToast('Deploying', `Creating workspace for ${rName}...`);
    
    try {
      const tPass = generateTempPass(); 
      
      // Ping the Vercel Backend to bypass Firebase Security Rules safely
      const response = await secureFetch('/api/deploy-tenant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
           rName: rName.trim(),
           oName: oName.trim(),
           oEmail: oEmail.trim(),
           oPhone: oPhone.trim(),
           rAddress: rAddress.trim(),
           tPass: tPass
        })
      });

      // SAFETY NET: Prevent the "Unexpected token" HTML crash if Vercel throws a 404 or 500
      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
         throw new Error("API Route Missing! Did you push api/deploy-tenant.js to GitHub/Vercel?");
      }

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to deploy tenant.');

      const welcomeMsg = `Welcome to 86chaos!\n\nYour restaurant OS is live. Access it here: https://app.86chaos.com\n\nUsername: ${oEmail.toLowerCase().trim()}\nTemporary Password: ${tPass}\n\nPlease log in to set a permanent password.`;
      window.location.href = `mailto:${oEmail.toLowerCase().trim()}?subject=${encodeURIComponent(`Your 86 Chaos OS: ${rName.trim()}`)}&body=${encodeURIComponent(welcomeMsg)}`;
      
      addToast('Tenant Deployed', `${rName} is now live.`); 
      setRName(''); setOName(''); setOEmail(''); setOPhone(''); setRAddress('');    
    } catch (error) { 
      addToast('Deployment Failed', error.message); 
    }
  };


// --- MISSING CLIENT MANAGEMENT FUNCTIONS ---
  const handleUpdateTenant = async (e) => {
    e.preventDefault();
    try {
      await updateDoc(doc(db, "restaurants", editingRest.id), {
        name: editingRest.name,
        ownerName: editingRest.ownerName,
        ownerEmail: editingRest.ownerEmail,
        ownerPhone: editingRest.ownerPhone,
        systemSettings: editingRest.systemSettings || {},
        planType: editingRest.planType || 'Pro',
        billingStatus: editingRest.billingStatus || 'Paid',
        customPrice: editingRest.customPrice || '',
        trialDays: editingRest.trialDays !== undefined ? editingRest.trialDays : 14,
        isActive: editingRest.isActive ?? true,
        isReadOnly: editingRest.isReadOnly ?? false,
        features: editingRest.features || {},
        labs: editingRest.labs || {}
      });
      addToast('Saved', 'Client workspace configuration updated.');
      setEditingRest(null);
    } catch (err) {
      addToast('Error', err.message);
    }
  };

  const handleExportData = async (rest) => {
    try {
      const usersSnap = await getDocs(query(collection(db, 'users'), where("restaurantId", "==", rest.id)));
      const usersList = usersSnap.docs.map(d => d.data());
      if (usersList.length === 0) return addToast('Empty', 'No users found for this workspace.');

      let csv = "Name,Email,Role,Phone,Admin\n" + usersList.map(u => `"${u.name}","${u.email}","${u.role}","${u.phone || ''}","${u.isAdmin || false}"`).join("\n");
      const blob = new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", `Users_Export_${rest.name.replace(/\s+/g, '_')}.csv`);
      document.body.appendChild(link); link.click(); document.body.removeChild(link);
      addToast('Exported', 'User list downloaded.');
    } catch (err) { 
      addToast('Error', 'Export failed.'); 
    }
  };

  // --- DATABASE SNAPSHOT ENGINE (BACKUP & RESTORE) ---
  const handleCreateBackup = async (rest) => {
    addToast('Backing Up', `Compiling database snapshot for ${rest.name}...`);
    const collectionsToBackup = ['users', 'shifts', 'recipes', 'inventoryItems', 'vendors', 'invoices', 'timePunches', 'sales', 'events', 'tasks', 'wasteLogs', 'timeOffRequests', 'prepCategories', 'roles', 'shiftSwaps', 'maintenanceLogs'];
    const snapshot = { metadata: { restaurantId: rest.id, restaurantName: rest.name, timestamp: new Date().toISOString() }, data: {} };

    try {
      for (const colName of collectionsToBackup) {
        const q = query(collection(db, colName), where("restaurantId", "==", rest.id));
        const snap = await getDocs(q);
        snapshot.data[colName] = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      }
      
      const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", `86chaos_Backup_${rest.name.replace(/\s+/g, '_')}_${getToday()}.json`);
      document.body.appendChild(link); link.click(); document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      addToast('Backup Complete', 'JSON snapshot downloaded successfully.');
    } catch (err) { addToast('Backup Failed', err.message); }
  };

  const handleRestoreBackup = async (e, rest) => {
    const file = e.target.files[0];
    if (!file) return;
    if (prompt(`CRITICAL: Type "RESTORE" to inject this backup file into ${rest.name}'s database.`) !== 'RESTORE') {
      e.target.value = '';
      return addToast('Aborted', 'Restore canceled.');
    }

    addToast('Restoring', 'Injecting data. Do not close your browser...');
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const backup = JSON.parse(event.target.result);
        if (backup.metadata.restaurantId !== rest.id) return addToast('Error', 'Tenant ID mismatch. You cannot restore a backup from a different workspace.');

        let restoredCount = 0;
        for (const [colName, docs] of Object.entries(backup.data)) {
          const promises = docs.map(d => {
             const { id, ...data } = d;
             return setDoc(doc(db, colName, id), data);
          });
          await Promise.all(promises);
          restoredCount += docs.length;
        }
        addToast('Restore Complete', `Successfully injected ${restoredCount} documents.`);
      } catch (err) { addToast('Error', 'Invalid backup file or upload failed.'); }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // --- EMPLOYEE SPECIFIC BACKUP & RESTORE ENGINE ---
  const handleBackupEmployee = async (u) => {
    addToast('Backing Up', `Compiling data for ${u.name}...`);
    const snapshot = { metadata: { userId: u.id, userName: u.name, timestamp: new Date().toISOString() }, data: { users: [u], shifts: [], timePunches: [], timeOffRequests: [] } };
    try {
      const shiftsSnap = await getDocs(query(collection(db, 'shifts'), where('employeeId', '==', u.id)));
      snapshot.data.shifts = shiftsSnap.docs.map(d => ({ id: d.id, ...d.data() }));

      const punchesSnap = await getDocs(query(collection(db, 'timePunches'), where('employeeId', '==', u.id)));
      snapshot.data.timePunches = punchesSnap.docs.map(d => ({ id: d.id, ...d.data() }));

      const timeOffSnap = await getDocs(query(collection(db, 'timeOffRequests'), where('userId', '==', u.id)));
      snapshot.data.timeOffRequests = timeOffSnap.docs.map(d => ({ id: d.id, ...d.data() }));

      const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", `86chaos_Employee_${u.name.replace(/\s+/g, '_')}_${getToday()}.json`);
      document.body.appendChild(link); link.click(); document.body.removeChild(link);
      URL.revokeObjectURL(url);
      addToast('Backup Complete', 'Employee JSON downloaded.');
    } catch (err) { addToast('Error', err.message); }
  };

  const handleRestoreEmployee = async (e, u) => {
    const file = e.target.files[0];
    if (!file) return;
    if (prompt(`CRITICAL: Type "RESTORE" to inject this backup into ${u.name}'s profile.`) !== 'RESTORE') {
      e.target.value = ''; return addToast('Aborted', 'Restore canceled.');
    }
    addToast('Restoring', 'Injecting employee data...');
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const backup = JSON.parse(event.target.result);
        if (backup.metadata.userId !== u.id && !window.confirm("ID mismatch. Inject anyway?")) return;
        let count = 0;
        for (const [colName, docs] of Object.entries(backup.data)) {
          const promises = docs.map(d => {
            const { id, ...data } = d;
            return setDoc(doc(db, colName, id), data);
          });
          await Promise.all(promises);
          count += docs.length;
        }
        addToast('Restore Complete', `Injected ${count} records.`);
      } catch (err) { addToast('Error', 'Invalid backup file.'); }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

const handleDeleteGlobalUser = async (u) => {
    if (prompt(`CRITICAL: Type "DELETE" to permanently erase ${u.name} and all their access.`) !== 'DELETE') {
      return addToast('Aborted', 'User deletion canceled.');
    }
    
    addToast('Terminating', 'Nuking user from all systems...');
    try {
      // 1. Nuke the Authentication Login via Vercel
      await secureFetch('/api/delete-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetUid: u.id })
      });
      
      // 2. Nuke the Database Profile
      await deleteDoc(doc(db, "users", u.id));
      addToast('Terminated', `User ${u.name} has been erased.`);
    } catch (err) {
      addToast('Error', 'Could not delete user. ' + err.message);
    }
  };


  const parseBulkEmailList = (raw) => [...new Set((raw || '')
    .split(/[\s,;]+/)
    .map(v => v.toLowerCase().trim())
    .filter(v => v && v.includes('@'))
  )];

  const handleBulkDeleteUsersByEmail = async (e) => {
    e.preventDefault();
    const emails = parseBulkEmailList(bulkDeleteEmails);
    if (emails.length === 0) return addToast('Nothing to Delete', 'Paste one or more email addresses first.');

    const protectedEmails = new Set([MASTER_ADMIN_EMAIL.toLowerCase(), (appUser?.email || '').toLowerCase()].filter(Boolean));
    const targets = allUsers.filter(u => emails.includes((u.email || '').toLowerCase().trim()) && !protectedEmails.has((u.email || '').toLowerCase().trim()));
    const skippedProtected = emails.filter(email => protectedEmails.has(email));

    if (targets.length === 0) {
      return addToast('No Matches', skippedProtected.length ? 'Only protected admin emails were entered.' : 'No user profiles matched those emails.');
    }

    const duplicateSummary = Object.entries(targets.reduce((acc, u) => {
      const key = (u.email || '').toLowerCase().trim();
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    }, {})).map(([email, count]) => `${email} (${count})`).join(', ');

    const confirmText = prompt(`This will delete ${targets.length} user profile(s) matching:
${duplicateSummary}

Type DELETE USERS to continue.`);
    if (confirmText !== 'DELETE USERS') return addToast('Aborted', 'Bulk deletion canceled.');

    setIsBulkDeletingUsers(true);
    let authDeleted = 0;
    let profileDeleted = 0;
    const errors = [];

    try {
      // Preferred path: one secure backend call deletes Firebase Auth users and Firestore profiles.
      try {
        const response = await secureFetch('/api/delete-users-bulk', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ emails })
        });
        const result = await response.json().catch(() => ({}));
        if (response.ok) {
          authDeleted = result.authDeleted ?? result.deletedAuthCount ?? targets.length;
          profileDeleted = result.profileDeleted ?? result.deletedProfileCount ?? targets.length;
          addToast('Bulk Delete Complete', `${profileDeleted} profile(s) removed. ${authDeleted} auth login(s) removed.`);
          setBulkDeleteEmails('');
          await addDoc(collection(db, 'auditLogs'), {
            userId: appUser?.id || 'system', userName: appUser?.name || 'System Admin', action: 'BULK_DELETE_USERS', target: 'users',
            details: `Bulk deleted users by email: ${emails.join(', ')}`, timestamp: new Date().toISOString(), restaurantId: appUser?.restaurantId || 'system', isGhost: appUser?.isGhost || false
          }).catch(()=>{});
          return;
        }
        throw new Error(result.error || 'Bulk delete API unavailable.');
      } catch (bulkApiErr) {
        console.warn('Bulk delete API unavailable, falling back to individual user deletion:', bulkApiErr);
      }

      // Fallback path: try the existing single delete-user endpoint for each UID, then delete the profile doc.
      for (const u of targets) {
        try {
          try {
            const response = await secureFetch('/api/delete-user', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ targetUid: u.id })
            });
            if (response.ok) authDeleted++;
          } catch (authErr) {
            errors.push(`Auth delete failed for ${u.email}: ${authErr.message}`);
          }
          await deleteDoc(doc(db, 'users', u.id));
          profileDeleted++;
        } catch (profileErr) {
          errors.push(`Profile delete failed for ${u.email}: ${profileErr.message}`);
        }
      }

      await addDoc(collection(db, 'auditLogs'), {
        userId: appUser?.id || 'system', userName: appUser?.name || 'System Admin', action: 'BULK_DELETE_USERS', target: 'users',
        details: `Bulk deleted ${profileDeleted} profile(s) by email. Auth deleted: ${authDeleted}. Errors: ${errors.slice(0, 5).join(' | ') || 'none'}`,
        timestamp: new Date().toISOString(), restaurantId: appUser?.restaurantId || 'system', isGhost: appUser?.isGhost || false
      }).catch(()=>{});

      addToast(errors.length ? 'Partial Delete' : 'Bulk Delete Complete', `${profileDeleted} profile(s) removed. ${authDeleted} auth login(s) removed.`);
      if (!errors.length) setBulkDeleteEmails('');
    } finally {
      setIsBulkDeletingUsers(false);
    }
  };

  const loadDuplicateEmailsIntoBulkDelete = () => {
    if (duplicateEmailGroups.length === 0) return addToast('Clean', 'No duplicate email groups found.');
    setSubTab('users');
    setBulkDeleteEmails(duplicateEmailGroups.map(([email]) => email).join('
'));
    addToast('Loaded', 'Duplicate email groups loaded into the bulk delete box. Review before deleting.');
  };

  // --- OBLITERATION ENGINE ---
  const handleNukeData = async (e) => {
    e.preventDefault();
    if (!nukePassword) return addToast('Error', 'Password required.');
    setIsNuking(true);
    
    try {
      await signInWithEmailAndPassword(auth, appUser.email, nukePassword);
      
      let cols = [];
      if (nukeTarget.type === 'inventory') cols = ['inventoryItems', 'vendors', 'invoices'];
      else if (nukeTarget.type === 'schedule') cols = ['shifts', 'timeOffRequests', 'shiftSwaps'];
      else if (nukeTarget.type === 'recipes') cols = ['recipes'];
      else if (nukeTarget.type === 'events') cols = ['events'];
      else if (nukeTarget.type === 'users') cols = ['users'];
      else if (nukeTarget.type === 'everything') cols = ['inventoryItems', 'vendors', 'invoices', 'users', 'recipes', 'shifts', 'timeOffRequests', 'shiftSwaps', 'events', 'wasteLogs', 'sales', 'maintenanceLogs'];

      let totalDeleted = 0;
      for (const c of cols) {
        const snap = await getDocs(query(collection(db, c), where("restaurantId", "==", nukeTarget.rest.id)));
        const deletePromises = [];
        
        snap.forEach(d => {
           if (c === 'users' && d.id === appUser.id) return;
           deletePromises.push(deleteDoc(doc(db, c, d.id)));
        });
        
        await Promise.all(deletePromises);
        totalDeleted += deletePromises.length;
      }

      addToast('Obliterated', `Deleted ${totalDeleted} documents for ${nukeTarget.rest.name}.`);
      setNukeTarget(null);
      setNukePassword('');
      setEditingRest(null); 
    } catch (err) {
      addToast('Error', 'Authentication failed or deletion error. Check your password.');
}
    setIsNuking(false);
  };

// --- SHOWCASE GENERATOR (DEMO WORKSPACE) ---
  const handleInjectDemoWorkspace = async () => {
    if (!window.confirm("Deploy a fully populated Demo Workspace? This will inject massive amounts of data and take a few seconds.")) return;
    addToast('Building...', 'Injecting massive showcase data. Please wait...');

    try {
      const today = new Date();
      const todayStr = today.toISOString().split('T')[0];
      
      const getOffsetDate = (days) => {
        const d = new Date(today);
        d.setDate(d.getDate() + days);
        return d.toISOString().split('T')[0];
      };

      const next7Days = Array.from({length: 7}).map((_, i) => getOffsetDate(i));
      const past7Days = Array.from({length: 7}).map((_, i) => getOffsetDate(-i));

      // 1. Create Restaurant
      const restRef = await addDoc(collection(db, "restaurants"), {
         name: "Showcase Bistro (Demo)",
         ownerName: "Sales Demo",
         ownerEmail: "demo@86chaos.com",
         isActive: true,
         isReadOnly: false,
         features: { schedule: true, events: true, ops: true, messages: true, prep: true, recipes: true, inventory: true, sales: true, team: true, maintenance: true, timesheets: true },
         labs: { laborProjection: true },
         planType: 'Enterprise',
         billingStatus: 'Paid',
         createdAt: new Date().toISOString(),
         lastActive: new Date().toISOString(),
         systemSettings: { address: '123 Demo St', geofenceRadius: 300, overtime: 40, enableTargets: true, targetSales: 55000, targetLaborPct: 22.5 }
      });
      const rId = restRef.id;

      // 2. Create 20 Users
      const dummyUsers = [
         { name: 'Alice Admin', role: 'General Manager', isAdmin: true, wage: 30 },
         { name: 'Sarah Supervisor', role: 'Manager', isAdmin: false, wage: 22 },
         { name: 'Charlie Chef', role: 'Chef', isAdmin: false, wage: 25 },
         { name: 'Sam Sous', role: 'Sous Chef', isAdmin: false, wage: 20 },
         { name: 'Bob Bartender', role: 'Bartender', isAdmin: false, wage: 10 },
         { name: 'Betty Bartender', role: 'Bartender', isAdmin: false, wage: 10 },
         { name: 'Eve Server', role: 'Server', isAdmin: false, wage: 8 },
         { name: 'Sammy Server', role: 'Server', isAdmin: false, wage: 8 },
         { name: 'Sally Server', role: 'Server', isAdmin: false, wage: 8 },
         { name: 'Steven Server', role: 'Server', isAdmin: false, wage: 8 },
         { name: 'Larry Line', role: 'Line Cook', isAdmin: false, wage: 17 },
         { name: 'Lenny Line', role: 'Line Cook', isAdmin: false, wage: 17 },
         { name: 'Frank Fry', role: 'Line Cook', isAdmin: false, wage: 16 },
         { name: 'Gina Grill', role: 'Line Cook', isAdmin: false, wage: 18 },
         { name: 'Paul Prep', role: 'Prep Cook', isAdmin: false, wage: 15 },
         { name: 'Penny Prep', role: 'Prep Cook', isAdmin: false, wage: 15 },
         { name: 'Holly Host', role: 'Host', isAdmin: false, wage: 13 },
         { name: 'Hunter Host', role: 'Host', isAdmin: false, wage: 13 },
         { name: 'Dave Dish', role: 'Dishwasher', isAdmin: false, wage: 14 },
         { name: 'Dan Dish', role: 'Dishwasher', isAdmin: false, wage: 14 }
      ];
      
      const userIds = [];
      const userPromises = dummyUsers.map(async (u) => {
         const uRef = await addDoc(collection(db, "users"), {
           ...u, email: u.name.split(' ')[0].toLowerCase() + '@demo.com', restaurantId: rId, isActive: true, passwordStored: false
         });
         userIds.push({ ...u, id: uRef.id });
      });
      await Promise.all(userPromises);

      // 3. Create Full Schedule (7 Days of Shifts)
      const shiftPromises = [];
      next7Days.forEach(date => {
        // Morning Crew
        shiftPromises.push(addDoc(collection(db, "shifts"), { restaurantId: rId, employeeId: userIds[1].id, role: 'Manager', date, startTime: '08:00', endTime: '16:00', isPublished: true }));
        shiftPromises.push(addDoc(collection(db, "shifts"), { restaurantId: rId, employeeId: userIds[14].id, role: 'Prep Cook', date, startTime: '07:00', endTime: '14:00', isPublished: true }));
        shiftPromises.push(addDoc(collection(db, "shifts"), { restaurantId: rId, employeeId: userIds[10].id, role: 'Line Cook', date, startTime: '09:00', endTime: '16:00', isPublished: true }));
        shiftPromises.push(addDoc(collection(db, "shifts"), { restaurantId: rId, employeeId: userIds[6].id, role: 'Server', date, startTime: '10:30', endTime: '16:00', isPublished: true }));
        shiftPromises.push(addDoc(collection(db, "shifts"), { restaurantId: rId, employeeId: userIds[4].id, role: 'Bartender', date, startTime: '10:30', endTime: '17:00', isPublished: true }));
        shiftPromises.push(addDoc(collection(db, "shifts"), { restaurantId: rId, employeeId: userIds[18].id, role: 'Dishwasher', date, startTime: '11:00', endTime: '16:00', isPublished: true }));
        
        // Night Crew
        shiftPromises.push(addDoc(collection(db, "shifts"), { restaurantId: rId, employeeId: userIds[3].id, role: 'Sous Chef', date, startTime: '14:00', endTime: '22:00', isPublished: true }));
        shiftPromises.push(addDoc(collection(db, "shifts"), { restaurantId: rId, employeeId: userIds[11].id, role: 'Line Cook', date, startTime: '15:00', endTime: '22:30', isPublished: true }));
        shiftPromises.push(addDoc(collection(db, "shifts"), { restaurantId: rId, employeeId: userIds[12].id, role: 'Line Cook', date, startTime: '16:00', endTime: '23:00', isPublished: true }));
        shiftPromises.push(addDoc(collection(db, "shifts"), { restaurantId: rId, employeeId: userIds[7].id, role: 'Server', date, startTime: '16:00', endTime: '23:00', isPublished: true }));
        shiftPromises.push(addDoc(collection(db, "shifts"), { restaurantId: rId, employeeId: userIds[8].id, role: 'Server', date, startTime: '17:00', endTime: '23:00', isPublished: true }));
        shiftPromises.push(addDoc(collection(db, "shifts"), { restaurantId: rId, employeeId: userIds[5].id, role: 'Bartender', date, startTime: '16:30', endTime: '23:30', isPublished: true }));
        shiftPromises.push(addDoc(collection(db, "shifts"), { restaurantId: rId, employeeId: userIds[16].id, role: 'Host', date, startTime: '16:30', endTime: '21:00', isPublished: true }));
        shiftPromises.push(addDoc(collection(db, "shifts"), { restaurantId: rId, employeeId: userIds[19].id, role: 'Dishwasher', date, startTime: '16:00', endTime: '23:30', isPublished: true }));
      });
      await Promise.all(shiftPromises);

      // Add a Shift Trade
      const targetShift = await addDoc(collection(db, "shifts"), { restaurantId: rId, employeeId: userIds[9].id, role: 'Server', date: getOffsetDate(2), startTime: '16:00', endTime: '23:00', isPublished: true });
      await addDoc(collection(db, "shiftSwaps"), { restaurantId: rId, shiftId: targetShift.id, originalEmployeeId: userIds[9].id, role: 'Server', date: getOffsetDate(2), startTime: '16:00', endTime: '23:00', status: 'available', listedAt: new Date().toISOString() });

      // 4. Time Off & Punches
      await addDoc(collection(db, "timeOffRequests"), { restaurantId: rId, userId: userIds[6].id, userName: 'Eve Server', date: getOffsetDate(3), status: 'pending', submittedAt: new Date().toISOString(), isPartial: false });
      await addDoc(collection(db, "timeOffRequests"), { restaurantId: rId, userId: userIds[10].id, userName: 'Larry Line', date: getOffsetDate(5), status: 'approved', submittedAt: new Date().toISOString(), isPartial: false });
      await addDoc(collection(db, "timePunches"), { restaurantId: rId, employeeId: userIds[1].id, employeeName: 'Sarah Supervisor', date: todayStr, clockInTime: new Date(today.setHours(7, 55, 0)).toISOString(), status: 'clocked_in' });
      await addDoc(collection(db, "timePunches"), { restaurantId: rId, employeeId: userIds[14].id, employeeName: 'Paul Prep', date: todayStr, clockInTime: new Date(today.setHours(6, 50, 0)).toISOString(), status: 'clocked_in' });
      await addDoc(collection(db, "timePunches"), { restaurantId: rId, employeeId: userIds[10].id, employeeName: 'Larry Line', date: todayStr, clockInTime: new Date(today.setHours(8, 58, 0)).toISOString(), status: 'clocked_in' });

      // 5. Messages / Events
      await addDoc(collection(db, "events"), { restaurantId: rId, type: 'note', title: 'Welcome to the Demo Workspace! Feel free to click around and explore the features.', author: 'Alice Admin', date: new Date().toISOString(), isImportant: true, replies: [] });
      await addDoc(collection(db, "events"), { restaurantId: rId, type: 'note', title: '86 the Salmon for tonight. Distributor shorted us.', author: 'Charlie Chef', date: new Date().toISOString(), isImportant: false, replies: [{ id: '1', author: 'Eve Server', text: 'Heard, thank you chef!', timestamp: new Date().toISOString() }] });
      await addDoc(collection(db, "events"), { restaurantId: rId, type: 'special_event', title: 'Live Music Night', date: todayStr, time: '19:00', notes: 'Local band playing. Expect heavy volume from 7-10.', addedBy: 'System' });
      await addDoc(collection(db, "events"), { restaurantId: rId, type: 'special_event', title: 'Private Party Catering', date: getOffsetDate(4), time: '18:00', notes: '50-top in the back room. Set menu.', addedBy: 'System' });

      // 6. Prep & Tasks
      const prepItems = [
        { text: 'Dice Onions (4 Qt)', station: 'Prep Table', isMaster: true },
        { text: 'Portion Burger Patties (50x)', station: 'Grill', isMaster: true },
        { text: 'Cut Lemons & Limes', station: 'Expo', isMaster: true },
        { text: 'Blend House Ranch', station: 'Salad/Cold', isMaster: true },
        { text: 'Blanch French Fries', station: 'Fry', isMaster: true },
        { text: 'Thaw Chicken Breasts', station: 'Prep Table', isMaster: true }
      ];
      await Promise.all(prepItems.map(p => addDoc(collection(db, "prepItems"), { restaurantId: rId, date: 'MASTER', text: p.text, station: p.station, isCompleted: false, qty: 1, isMaster: true, completedDates: {} })));
      
      await addDoc(collection(db, "prepItems"), { restaurantId: rId, date: todayStr, text: 'Emergency 86 Prep: Thaw Shrimp', station: 'Grill', isCompleted: false, qty: 1 });
      await addDoc(collection(db, "tasks"), { restaurantId: rId, title: 'Clean Deep Fryer', category: 'Cleaning', frequency: 'daily', completions: {} });
      await addDoc(collection(db, "tasks"), { restaurantId: rId, title: 'Wipe Down Walk-in Shelves', category: 'Cleaning', frequency: 'weekly', targetDay: 'Monday', completions: {} });
      await addDoc(collection(db, "tasks"), { restaurantId: rId, title: 'Check First Aid Kit', category: 'General', frequency: 'monthly', targetDate: '1', completions: {} });

      // 7. Inventory & Vendors & Line Checks
      const v1 = await addDoc(collection(db, "vendors"), { restaurantId: rId, name: 'Sysco (Demo)', rep: 'John', phone: '555-0192', cutOffDays: ['Monday', 'Thursday'], cutOffTime: '16:00' });
      const v2 = await addDoc(collection(db, "vendors"), { restaurantId: rId, name: 'US Foods (Demo)', rep: 'Sarah', phone: '555-3841', cutOffDays: ['Tuesday', 'Friday'], cutOffTime: '15:00' });
      const v3 = await addDoc(collection(db, "vendors"), { restaurantId: rId, name: 'Local Produce Farm', rep: 'Mike', phone: '555-9988' });

      const invItems = [
        { name: 'French Fries (3/8)', cat: 'Frozen', v: v1.id, pack: '6/5#', y: 1, p: 35.50, par: 10, stock: 4, code: '78321' },
        { name: 'Ketchup', cat: 'Dry Goods', v: v1.id, pack: '6/#10', y: 1, p: 28.00, par: 3, stock: 1, code: '11223' },
        { name: 'Chicken Breast (6oz)', cat: 'Meat', v: v2.id, pack: '2/10#', y: 1, p: 65.00, par: 8, stock: 9, code: '44556' },
        { name: 'Ground Beef (80/20)', cat: 'Meat', v: v2.id, pack: '4/10#', y: 1, p: 120.00, par: 6, stock: 2, code: '44557' },
        { name: 'Romaine Lettuce', cat: 'Produce', v: v3.id, pack: '24ct', y: 1, p: 22.00, par: 5, stock: 2, code: '99881' },
        { name: 'Roma Tomatoes', cat: 'Produce', v: v3.id, pack: '25#', y: 1, p: 18.00, par: 4, stock: 1, code: '99882' },
        { name: 'Heavy Cream', cat: 'Dairy', v: v1.id, pack: '12/1qt', y: 1, p: 45.00, par: 3, stock: 4, code: '33441' },
        { name: 'Cheddar Block', cat: 'Dairy', v: v1.id, pack: '4/5#', y: 1, p: 55.00, par: 4, stock: 1, code: '33442' },
        { name: 'Fry Oil', cat: 'Supplies', v: v2.id, pack: '35# jug', y: 1, p: 38.00, par: 8, stock: 8, code: '77881' },
        { name: 'To-Go Boxes', cat: 'Supplies', v: v1.id, pack: '200ct', y: 1, p: 42.00, par: 5, stock: 2, code: '11990' }
      ];
      await Promise.all(invItems.map(i => addDoc(collection(db, "inventoryItems"), { restaurantId: rId, name: i.name, category: i.cat, supplierId: i.v, packSize: i.pack, yieldQty: i.y, price: i.p, parLevel: i.par, currentStock: i.stock, pendingQty: 0, pfgCode: i.code, isStarred: false })));

      await addDoc(collection(db, "lineCheckItems"), { restaurantId: rId, name: 'Salad Station Cooler', category: 'Cold Holding (≤ 41°F)' });
      await addDoc(collection(db, "lineCheckItems"), { restaurantId: rId, name: 'Grill Drawers', category: 'Cold Holding (≤ 41°F)' });
      await addDoc(collection(db, "lineCheckItems"), { restaurantId: rId, name: 'Soup Warmer', category: 'Hot Holding (≥ 135°F)' });

      // 8. Recipes
      await addDoc(collection(db, "recipes"), { restaurantId: rId, title: 'House Ranch', category: 'Sauce/Dressing', prepTime: '10 mins', yieldAmt: '1 Gallon', ingredients: '1 Gal Mayo\n1/2 Gal Buttermilk\n1 Cup Ranch Seasoning', instructions: '1. Combine all in 12qt Cambro.\n2. Whisk until smooth.\n3. Date and label.', authorName: 'Alice Admin', lastUpdated: new Date().toISOString() });
      await addDoc(collection(db, "recipes"), { restaurantId: rId, title: 'Beer Cheese', category: 'Sauce/Dressing', prepTime: '30 mins', yieldAmt: '1.5 Gallons', ingredients: '1 lb Butter\n1 lb Flour\n1 Tablespoon Salt\n1 Pint Light Beer\n1 gallon milk\n8 cups shredded cheddar', instructions: '1. Melt butter and whisk in flour to create roux.\n2. Add beer and stir.\n3. Whisk in hot milk.\n4. Fold in cheese until melted.', authorName: 'Charlie Chef', lastUpdated: new Date().toISOString() });
      await addDoc(collection(db, "recipes"), { restaurantId: rId, title: 'Signature Burger Prep', category: 'Meat Prep', prepTime: '20 mins', yieldAmt: '24 Patties', ingredients: '10 lbs Ground Beef (80/20)\n1/2 Cup Kosher Salt\n1/4 Cup Black Pepper\n2 Tbsp Garlic Powder', instructions: '1. Gently mix seasonings into ground beef.\n2. Portion into 6.5oz balls.\n3. Press into patties.\n4. Layer with parchment paper.', authorName: 'Charlie Chef', lastUpdated: new Date().toISOString() });

      // 9. Sales (7 Days Historical)
      const salesPromises = past7Days.map((d, index) => {
         const base = 5000 + (Math.random() * 2000);
         const isWeekend = index === 1 || index === 2; // Rough assumption for random peaks
         const gross = isWeekend ? base * 1.5 : base;
         return addDoc(collection(db, "sales"), { restaurantId: rId, date: d, grossSales: gross, laborCost: gross * 0.22, foodCost: gross * 0.28, notes: isWeekend ? 'Busy weekend shift.' : 'Standard service.' });
      });
      await Promise.all(salesPromises);

      // 10. Maintenance & PM
      await addDoc(collection(db, "maintenanceLogs"), { restaurantId: rId, equipment: 'Ice Machine', issue: 'Leaking water on the floor near drain', urgency: 'High', status: 'Reported', reportedAt: new Date().toISOString(), reportedBy: 'Bob Bartender' });
      await addDoc(collection(db, "maintenanceLogs"), { restaurantId: rId, equipment: 'Fryer #2', issue: 'Pilot light keeps going out', urgency: 'Critical', status: 'Pending Parts', notes: 'Called Hobart. Waiting on thermocouple.', reportedAt: new Date().toISOString(), reportedBy: 'Alice Admin' });
      await addDoc(collection(db, "pmSchedules"), { restaurantId: rId, title: 'Degrease Hood Filters', equipment: 'Line Vents', frequencyDays: 30, lastCompleted: getOffsetDate(-29) }); // Overdue tomorrow
      await addDoc(collection(db, "pmSchedules"), { restaurantId: rId, title: 'Descale Dish Machine', equipment: 'Dishwasher', frequencyDays: 14, lastCompleted: getOffsetDate(-5) });

      addToast('Demo Live', 'Massive Showcase Workspace successfully deployed. Check your Clients list.');
    } catch(e) {
      addToast('Error', e.message);
    }
  };

  // --- 2. SYSTEM OPERATIONS & FORGE ---

  // --- 2. SYSTEM OPERATIONS & FORGE ---
  const handleMegaphone = async (e) => {
    e.preventDefault(); 
    if(!broadcastMsg.trim()) return; 
    if(!window.confirm("Blast this to EVERY restaurant?")) return;
    
    addToast('Broadcasting', 'Pushing message to all shards...');
    let success = 0; let failed = 0;
    
    for (const r of restaurants) {
      try {
        await addDoc(collection(db, "events"), { 
          date: new Date().toISOString(), title: broadcastMsg.trim(), type: 'note', author: 'System Alert', isImportant: true, restaurantId: r.id, replies: [] 
        });
        success++;
      } catch (err) { failed++; }
    }
    
    if (failed > 0) addToast('Partial Alert', `Sent to ${success}, but Firebase blocked ${failed}. Check console.`);
    else addToast('Megaphone', `Message blasted successfully to ${success} locations.`);
    setBroadcastMsg('');
  };

 const handleForgePush = async (e, type) => {
    e.preventDefault(); 
    if(!window.confirm(`Push this ${type} to ALL clients globally?`)) return;
    
    addToast('Deploying', `Pushing ${type} to all shards...`);
    let success = 0; let failed = 0;

    for (const r of restaurants) {
      try {
        if (type === 'Event') await addDoc(collection(db, "events"), { type: 'special_event', date: forgeEventDate, title: forgeEventTitle.trim(), addedBy: '86 Chaos System', restaurantId: r.id });
        success++;
      } catch (err) { failed++; }
    }
    
    if (failed > 0) addToast('Partial Deploy', `Pushed to ${success}, but failed on ${failed}.`);
    else addToast('Forge Deployed', `${type} injected globally into ${success} databases.`);
    setForgeEventTitle('');
  };

               const handleTestPush = async () => {
    if (!window.confirm("Fire a test notification to all opted-in devices in your workspace?")) return;
    addToast('Pinging Server', 'Firing test shot to Vercel...');
    try {
      const pushRes = await secureFetch('/api/send-schedule-alert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          restaurantId: appUser.restaurantId,
          restaurantName: 'TEST MODE'
        })
      });
      const pushData = await pushRes.json();
      if (pushData.message) addToast('Server Reply', pushData.message); 
      else if (pushData.success) addToast('Success', `Test pushed to ${pushData.sentCount} devices.`);
      else addToast('API Error', pushData.error || 'Unknown error');
    } catch (err) {
      addToast('Network Error', 'Failed to reach Vercel.');
    }
  };   

  const handleOrphanSweep = async () => {
    if(!window.confirm("Scan platform for dead shifts (shifts attached to deleted users)?")) return;
    addToast('Scanning', 'Running orphan sweep...');
    const sSnap = await getDocs(collection(db, 'shifts')); let deadCount = 0;
    sSnap.forEach(d => { const s = d.data(); if (!allUsers.find(u => u.id === s.employeeId)) { deleteDoc(doc(db, "shifts", d.id)); deadCount++; } });
    addToast('Sweep Complete', `Purged ${deadCount} orphaned database documents.`);
  };

  const handleForceRefresh = async () => {
    if (!window.confirm("🚨 CRITICAL: This will send a hard-refresh command to EVERY active browser connected to 86 Chaos globally. Proceed?")) return;
    addToast('Executing', 'Sending refresh signal...');
    const stamp = new Date().toISOString(); let count = 0;
    for (const r of restaurants) {
       try { await updateDoc(doc(db, "restaurants", r.id), { forceRefresh: stamp }); count++; } catch(e){}
    }
    addToast('Refresh Broadcast', `Hard reload signal sent to ${count} databases.`);
  };

  const handleGlobalLockdown = async (lock) => {
    if (lock) {
        if (prompt('CRITICAL: This will instantly lock out EVERY client workspace (except yours) by triggering the billing lock screen. Type "LOCKDOWN" to proceed.') !== 'LOCKDOWN') return;
        addToast('Executing', 'Initiating global lockdown...');
    } else {
        if (!window.confirm('Restore access to all suspended workspaces?')) return;
        addToast('Executing', 'Lifting lockdown...');
    }
    
    let count = 0;
    for (const r of restaurants) {
      if (r.id !== appUser.restaurantId) {
        try { await updateDoc(doc(db, "restaurants", r.id), { billingStatus: lock ? 'Past Due' : 'Paid' }); count++; } catch(e){}
      }
    }
    addToast(lock ? 'Lockdown Complete' : 'Unlocked', `${count} workspaces have been ${lock ? 'suspended' : 'restored'}.`);
  };

const handleGrantAccess = async (e) => {
  e.preventDefault();
  const targetEmail = adminEmail.toLowerCase().trim();
  if (!targetEmail) return;
  try {
    const response = await secureFetch('/api/admin-access', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'grant', email: targetEmail })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error || 'Grant access failed.');
    setAdminEmail('');
    addToast('Granted', 'Custom-claim access granted. The user must log out and back in.');
  } catch (err) {
    addToast('Access Error', err.message || 'Could not grant access. Check /api/admin-access and Vercel env vars.');
  }
};

const handleRevokeAccess = async (user) => {
  if (!window.confirm(`Revoke Admin from ${user.name}?`)) return;
  try {
    const response = await secureFetch('/api/admin-access', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'revoke', email: user.email })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error || 'Revoke access failed.');
    addToast('Revoked', 'Custom-claim access removed. The user must log out and back in.');
  } catch (err) {
    addToast('Access Error', err.message || 'Could not revoke access.');
  }
};

// --- CALCULATIONS ---
  const mrr = restaurants.reduce((acc, r) => {
    if (r.customPrice !== undefined && r.customPrice !== '') return acc + parseFloat(r.customPrice);
    return acc + (r.planType === 'Enterprise' ? 199 : r.planType === 'Elite' ? 149 : r.planType === 'Pro' ? 99 : r.planType === 'Starter' ? 49 : 0);
  }, 0);
  const timeAgo = (dateStr) => { if (!dateStr) return 'Never'; const days = Math.floor((Date.now() - new Date(dateStr).getTime()) / (1000 * 60 * 60 * 24)); if (days === 0) return 'Active Today'; if (days === 1) return 'Active Yesterday'; return `Inactive ${days} days`; };
  const staleTenants = restaurants.filter(r => r.isActive && Math.floor((Date.now() - new Date(r.lastActive||0).getTime()) / 86400000) > 21);

  // --- NEW SAAS HEALTH METRICS ---
const activeTrials = restaurants.filter(r => r.billingStatus === 'Trial').length;
  const paidWorkspaces = restaurants.filter(r => r.billingStatus === 'Paid').length;
  const dau = allUsers.filter(u => u.lastActive && Math.floor((Date.now() - new Date(u.lastActive).getTime()) / 86400000) === 0).length;
  const stickyRate = allUsers.length > 0 ? ((dau / allUsers.length) * 100).toFixed(0) : 0;

  // --- NEW INFRASTRUCTURE & FINANCIAL METRICS ---
  const arpa = paidWorkspaces > 0 ? (mrr / paidWorkspaces).toFixed(2) : 0;
  const trialPipelineValue = activeTrials * (tierPrices.Pro || 99); 
  const crashes24h = crashLogs.filter(log => (Date.now() - new Date(log.time||0).getTime()) < 86400000).length;
  const pushOptInRate = allUsers.length > 0 ? ((allUsers.filter(u => u.fcmToken).length / allUsers.length) * 100).toFixed(0) : 0;
  const apiConnectedCount = restaurants.filter(r => r.integrations?.posProvider || r.integrations?.payrollProvider).length;
  const ONLINE_WINDOW_MS = 3 * 60 * 1000;
  const nowMs = Date.now();
  const getLastActiveMs = (u) => {
    const parsed = new Date(u.lastActive || u.lastSeen || 0).getTime();
    return Number.isFinite(parsed) ? parsed : 0;
  };
  const isOnlineNow = (u) => {
    const last = getLastActiveMs(u);
    return !!last && (nowMs - last) < ONLINE_WINDOW_MS && u.onlineState !== 'offline';
  };
  const onlineUsers = allUsers.filter(isOnlineNow).sort((a,b) => getLastActiveMs(b) - getLastActiveMs(a));
  const onlineRestaurantIds = [...new Set(onlineUsers.map(u => u.restaurantId).filter(Boolean))];
  const onlineRestaurants = restaurants.filter(r => onlineRestaurantIds.includes(r.id));
  const onlineByRestaurant = onlineRestaurantIds.map(id => ({
    id,
    rest: restaurants.find(r => r.id === id),
    users: onlineUsers.filter(u => u.restaurantId === id)
  })).sort((a,b) => b.users.length - a.users.length);
  const recentlyActiveUsers = allUsers.filter(u => {
    const last = getLastActiveMs(u);
    return !!last && (nowMs - last) < 15 * 60 * 1000 && !isOnlineNow(u);
  }).sort((a,b) => getLastActiveMs(b) - getLastActiveMs(a));

  const pastDueWorkspaces = restaurants.filter(r => r.billingStatus === 'Past Due');
  const readOnlyWorkspaces = restaurants.filter(r => r.isReadOnly);
  const trialWorkspaces = restaurants.filter(r => r.billingStatus === 'Trial');
  const adminUsers = allUsers.filter(u => u.isAdmin || u.isSuperAdmin);
  const inactiveUsers = allUsers.filter(u => {
    const last = getLastActiveMs(u);
    return !last || (nowMs - last) > 30 * 86400000;
  });
  const moduleList = ['schedule','events','ops','messages','prep','recipes','inventory','sales','team','maintenance','timesheets'];
  const featureAdoption = moduleList.map(feat => ({ feat, count: restaurants.filter(r => r.features?.[feat] !== false).length })).sort((a,b) => b.count - a.count);
  const usersWithoutRestaurant = allUsers.filter(u => !u.restaurantId);
  const missingOwnerAccounts = restaurants.filter(r => r.ownerEmail && !allUsers.some(u => (u.email || '').toLowerCase() === (r.ownerEmail || '').toLowerCase()));
  const duplicateEmailGroups = Object.entries(allUsers.reduce((acc, u) => {
    const emailKey = (u.email || '').toLowerCase().trim();
    if (emailKey) acc[emailKey] = [...(acc[emailKey] || []), u];
    return acc;
  }, {})).filter(([, group]) => group.length > 1);
  const usersMissingPush = allUsers.filter(u => !u.fcmToken);
  const permissionDeniedLogs = crashLogs.filter(log => `${log.message || ''} ${log.stack || ''}`.toLowerCase().includes('permission-denied'));
  const endpointList = ['admin-access', 'whoami', 'security-diagnostics', 'deploy-tenant', 'delete-user', 'scan-invoice', 'send-push', 'send-schedule-alert'];
  const envReport = typeof window !== 'undefined' ? {
    host: window.location.host,
    path: window.location.pathname,
    online: navigator.onLine,
    serviceWorker: 'serviceWorker' in navigator,
    indexedDb: 'indexedDB' in window,
    notifications: typeof Notification !== 'undefined' ? Notification.permission : 'unsupported',
    storageUser: !!(localStorage.getItem('86chaosUser') || sessionStorage.getItem('86chaosUser')),
    userAgent: navigator.userAgent
  } : { host: 'server', online: false, serviceWorker: false, indexedDb: false, notifications: 'unknown', storageUser: false, userAgent: 'unknown' };
  const platformSnapshot = [
    `86 Chaos Platform Snapshot`,
    `Version: ${CURRENT_VERSION}`,
    `Online users: ${onlineUsers.length}`,
    `Active workspaces: ${restaurants.filter(r=>r.isActive).length}`,
    `Paid workspaces: ${paidWorkspaces}`,
    `Trials: ${trialWorkspaces.length}`,
    `Past due: ${pastDueWorkspaces.length}`,
    `Network users: ${allUsers.length}`,
    `Admins: ${adminUsers.length}`,
    `Crashes 24h: ${crashes24h}`,
    `Permission denied logs: ${permissionDeniedLogs.length}`,
    `Push opt-in: ${pushOptInRate}%`,
    `Users without restaurantId: ${usersWithoutRestaurant.length}`,
    `Missing owner accounts: ${missingOwnerAccounts.length}`,
    `Duplicate email groups: ${duplicateEmailGroups.length}`,
    `Host: ${envReport.host}`,
    `Browser online: ${envReport.online}`,
    `Generated: ${new Date().toLocaleString()}`
  ].join('\n');

  const adminRiskQueue = [
    crashes24h > 0 ? { tone: crashes24h > 10 ? 'red' : 'amber', title: 'Fresh crash reports', detail: `${crashes24h} crash/bug log(s) in the last 24 hours.`, jump: 'support' } : null,
    permissionDeniedLogs.length > 0 ? { tone: 'red', title: 'Permission denied errors', detail: `${permissionDeniedLogs.length} log(s) look like Firestore rule blocks.`, jump: 'support' } : null,
    pastDueWorkspaces.length > 0 ? { tone: 'amber', title: 'Past due workspaces', detail: `${pastDueWorkspaces.length} workspace(s) are locked or billing-risk.`, jump: 'tenants' } : null,
    missingOwnerAccounts.length > 0 ? { tone: 'amber', title: 'Missing owner accounts', detail: `${missingOwnerAccounts.length} restaurant owner email(s) do not match a user profile.`, jump: 'support' } : null,
    usersWithoutRestaurant.length > 0 ? { tone: 'amber', title: 'Users missing restaurantId', detail: `${usersWithoutRestaurant.length} user profile(s) cannot route correctly.`, jump: 'support' } : null,
    duplicateEmailGroups.length > 0 ? { tone: 'red', title: 'Duplicate user emails', detail: `${duplicateEmailGroups.length} duplicate email group(s) found.`, jump: 'support' } : null,
    pushOptInRate < 30 && allUsers.length > 0 ? { tone: 'amber', title: 'Low push adoption', detail: `${pushOptInRate}% of users have notification tokens.`, jump: 'users' } : null
  ].filter(Boolean);
  const platformStatus = adminRiskQueue.some(r => r.tone === 'red') ? 'Needs Attention' : adminRiskQueue.length ? 'Monitoring' : 'Clean';

  const handleCopyPlatformSnapshot = async () => {
    try {
      await navigator.clipboard.writeText(platformSnapshot);
      addToast('Copied', 'Platform snapshot copied to clipboard.');
    } catch (err) {
      addToast('Snapshot', platformSnapshot);
    }
  };

  const handleCopyDiagnostics = async () => {
    const diagnostics = [
      platformSnapshot,
      '',
      'Client Runtime',
      `Host: ${envReport.host}`,
      `Path: ${envReport.path}`,
      `Navigator online: ${envReport.online}`,
      `Notifications: ${envReport.notifications}`,
      `Service worker available: ${envReport.serviceWorker}`,
      `IndexedDB available: ${envReport.indexedDb}`,
      `Stored user cache: ${envReport.storageUser}`,
      '',
      'Data Integrity',
      `Users without restaurantId: ${usersWithoutRestaurant.map(u => u.email || u.name || u.id).join(', ') || 'none'}`,
      `Missing owner accounts: ${missingOwnerAccounts.map(r => (r.name || 'Unnamed') + ' <' + (r.ownerEmail || 'no email') + '>').join(', ') || 'none'}`,
      `Duplicate email groups: ${duplicateEmailGroups.map(([email, group]) => email + ' (' + group.length + ')').join(', ') || 'none'}`,
      `Permission denied logs: ${permissionDeniedLogs.length}`,
      '',
      `User agent: ${envReport.userAgent}`
    ].join('\n');
    try {
      await navigator.clipboard.writeText(diagnostics);
      addToast('Copied', 'Support diagnostics copied to clipboard.');
    } catch (err) {
      addToast('Diagnostics', diagnostics.substring(0, 220));
    }
  };

  const handleClearAllBanners = async () => {
    if (!window.confirm('Clear system banners from every workspace?')) return;
    try {
      await Promise.all(restaurants.map(r => updateDoc(doc(db, 'restaurants', r.id), { systemBanner: null })));
      addToast('Banners Cleared', 'All workspace banners were removed.');
    } catch (err) { addToast('Error', err.message); }
  };

  const SignalPip = ({ tone = 'emerald', label = 'LIVE', hot = false }) => {
    const colors = tone === 'red' ? 'text-red-400 bg-red-500' : tone === 'amber' ? 'text-amber-400 bg-amber-400' : tone === 'blue' ? 'text-blue-400 bg-blue-400' : tone === 'purple' ? 'text-fuchsia-400 bg-fuchsia-400' : 'text-emerald-400 bg-emerald-400';
    return <span className={`inline-flex items-center gap-1.5 text-[9px] font-black uppercase tracking-widest ${colors.split(' ')[0]}`}><span className={`cockpit-light ${hot ? 'hot' : 'quiet'} ${colors.split(' ')[1]}`}></span>{label}</span>;
  };

  const CockpitMetric = ({ label, value, detail, tone = 'emerald', hot = false }) => (
    <div className="cockpit-panel cockpit-grid rounded-xl p-3 min-h-[92px] flex flex-col justify-between">
      <div className="flex items-center justify-between gap-2">
        <span className="text-[9px] font-black uppercase tracking-widest text-slate-500 truncate">{label}</span>
        <SignalPip tone={tone} label={hot ? 'HOT' : 'SYNC'} hot={hot} />
      </div>
      <div className="text-2xl font-black text-white leading-none mt-2">{value}</div>
      <div className="text-[10px] text-slate-400 font-bold mt-2 truncate">{detail}</div>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto space-y-5 pb-24 animate-[slideIn_0.2s_ease-out]">
      {/* 747 COCKPIT COMMAND STRIP */}
      <div className="cockpit-panel rounded-2xl p-4 overflow-hidden relative">
        <div className="absolute inset-0 cockpit-grid opacity-60 pointer-events-none"></div>
        <div className="relative flex flex-col lg:flex-row lg:items-end justify-between gap-4 mb-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <SignalPip tone="emerald" label="PLATFORM LIVE" hot />
              <SignalPip tone={crashes24h > 0 ? 'amber' : 'emerald'} label={crashes24h > 0 ? 'WATCH' : 'CLEAN'} />
              <SignalPip tone="blue" label="FIREBASE" />
              <SignalPip tone="purple" label="GHOST READY" />
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">System Administrator Command Deck</h1>
            <p className="text-xs text-slate-400 font-bold mt-1">Live platform telemetry, client control, user presence, safety locks, and support tools.</p>
          </div>
          <div className="flex flex-wrap gap-1.5 text-[9px] font-black uppercase tracking-widest">
            {[
              ['AUTH', 'emerald'],
              ['DB', 'emerald'],
              ['RULES', permissionDeniedLogs.length ? 'amber' : 'emerald'],
              ['API', apiConnectedCount ? 'blue' : 'emerald'],
              ['GHOST', 'purple'],
              ['CRASH', crashes24h ? 'amber' : 'emerald']
            ].map(([lamp, tone]) => (
              <span key={lamp} className="bg-[#0B0E11] border border-[#2A353D] rounded-md px-2 py-1 text-slate-300 flex items-center gap-1.5">
                <span className={`cockpit-light quiet ${tone === 'amber' ? 'bg-amber-400 text-amber-400' : tone === 'blue' ? 'bg-blue-400 text-blue-400' : tone === 'purple' ? 'bg-fuchsia-400 text-fuchsia-400' : 'bg-emerald-400 text-emerald-400'}`}></span>{lamp}
              </span>
            ))}
          </div>
        </div>
        <div className="relative grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-2">
          <CockpitMetric label="Platform" value={platformStatus} detail={`${adminRiskQueue.length} item(s) in action queue`} tone={platformStatus === 'Needs Attention' ? 'red' : platformStatus === 'Monitoring' ? 'amber' : 'emerald'} hot={platformStatus === 'Needs Attention'} />
          <CockpitMetric label="Online Now" value={onlineUsers.length} detail={`${onlineRestaurants.length} active workspaces`} tone="emerald" />
          <CockpitMetric label="MRR" value={`$${mrr}`} detail={`ARPA $${arpa}`} tone="emerald" />
          <CockpitMetric label="Crashes 24h" value={crashes24h} detail={crashes24h ? 'Needs eyes' : 'No fresh crashes'} tone={crashes24h ? 'amber' : 'emerald'} hot={crashes24h > 10} />
          <CockpitMetric label="Push Opt-In" value={`${pushOptInRate}%`} detail={`${allUsers.filter(u => u.fcmToken).length} devices`} tone={pushOptInRate < 30 ? 'amber' : 'emerald'} />
          <CockpitMetric label="Stale Clients" value={staleTenants.length} detail="Inactive 21+ days" tone={staleTenants.length ? 'amber' : 'emerald'} />
        </div>
      </div>

      {/* MASTER NAVIGATION */}
      <div className="grid grid-cols-2 md:grid-cols-5 lg:grid-cols-9 gap-2 border-b border-[#2A353D] mb-6 pb-4">
        {[{id:'overview', label:'Dashboard'}, {id:'live', label:'Live Users'}, {id:'tenants', label:'Clients'}, {id:'users', label:'Users'}, {id:'admins', label:'Grant Access'}, {id:'support', label:'Support'}, {id:'forensics', label:'Forensics'}, {id:'ops', label:'Operations'}, {id:'forge', label:'Forge'}].map((t) => (
          <button key={t.id} onClick={() => setSubTab(t.id)} className={`px-2 py-2.5 text-[10px] sm:text-[11px] font-black rounded-xl uppercase tracking-widest transition-all ${subTab === t.id ? 'bg-red-600 text-white shadow-lg scale-[1.02]' : 'bg-[#1A2126] text-slate-400 border border-[#2A353D] hover:text-white hover:border-slate-500'}`}>{t.label}</button>
        ))}
      </div>

      {/* ADMIN QUICK CONTROL SWITCHBOARD */}
      <div className="cockpit-panel rounded-xl p-3 overflow-hidden relative">
        <div className="absolute inset-0 cockpit-grid opacity-35 pointer-events-none"></div>
        <div className="relative flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2 mb-1.5">
              <SignalPip tone="emerald" label="CONTROL TOWER" hot />
              <SignalPip tone={pastDueWorkspaces.length ? 'amber' : 'emerald'} label={`${pastDueWorkspaces.length} PAST DUE`} hot={pastDueWorkspaces.length > 0} />
              <SignalPip tone={readOnlyWorkspaces.length ? 'blue' : 'emerald'} label={`${readOnlyWorkspaces.length} READ ONLY`} />
              <SignalPip tone="purple" label={`${adminUsers.length} ADMINS`} />
            </div>
            <div className="text-sm font-black text-white">Quick Control Switchboard</div>
            <div className="text-[10px] text-slate-500 font-bold uppercase tracking-widest truncate">Snapshot, banners, live radar, client controls, and support jump points.</div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 w-full lg:w-auto">
            <button type="button" onClick={handleCopyPlatformSnapshot} className="bg-[#0B0E11] border border-[#2A353D] text-slate-300 hover:text-[#D4A381] hover:border-[#D4A381]/50 rounded-lg px-3 py-2 text-[10px] font-black uppercase tracking-widest">Copy Snapshot</button>
            <button type="button" onClick={handleClearAllBanners} className="bg-[#0B0E11] border border-[#2A353D] text-slate-300 hover:text-red-300 hover:border-red-500/50 rounded-lg px-3 py-2 text-[10px] font-black uppercase tracking-widest">Clear Banners</button>
            <button type="button" onClick={() => setSubTab('live')} className="bg-emerald-900/15 border border-emerald-900/50 text-emerald-300 hover:bg-emerald-900/30 rounded-lg px-3 py-2 text-[10px] font-black uppercase tracking-widest">Live Radar</button>
            <button type="button" onClick={() => setSubTab('tenants')} className="bg-purple-900/15 border border-purple-900/50 text-purple-300 hover:bg-purple-900/30 rounded-lg px-3 py-2 text-[10px] font-black uppercase tracking-widest">Clients</button>
          </div>
        </div>
        <div className="relative mt-3 grid grid-cols-2 md:grid-cols-4 gap-2">
          <div className="bg-[#0B0E11] border border-[#2A353D] rounded-lg p-2"><div className="text-[9px] font-black uppercase tracking-widest text-slate-500">Trials</div><div className="text-xl font-black text-white">{trialWorkspaces.length}</div></div>
          <div className="bg-[#0B0E11] border border-[#2A353D] rounded-lg p-2"><div className="text-[9px] font-black uppercase tracking-widest text-slate-500">Inactive Users</div><div className="text-xl font-black text-white">{inactiveUsers.length}</div></div>
          <div className="bg-[#0B0E11] border border-[#2A353D] rounded-lg p-2"><div className="text-[9px] font-black uppercase tracking-widest text-slate-500">Modules Live</div><div className="text-xl font-black text-white">{featureAdoption.filter(f => f.count > 0).length}/{moduleList.length}</div></div>
          <div className="bg-[#0B0E11] border border-[#2A353D] rounded-lg p-2"><div className="text-[9px] font-black uppercase tracking-widest text-slate-500">Version</div><div className="text-xl font-black text-white">{CURRENT_VERSION}</div></div>
        </div>
      </div>

<Modal isOpen={!!editingRest} onClose={() => setEditingRest(null)} title={`Manage Client: ${editingRest?.name}`}>
        {editingRest && (() => {
          
// --- THE TIER PRESET ENGINE ---
          const applyTierPreset = (tier) => {
            // 1. Start with a baseline where EVERY feature is explicitly set to FALSE
            const baseFeatures = { schedule: false, events: false, ops: false, messages: false, prep: false, recipes: false, inventory: false, sales: false, team: false, maintenance: false, timesheets: false };
            let newLabs = { laborProjection: false };
            let updatedFeatures = { ...baseFeatures };
            
            // 2. Merge only the allowed features as TRUE over the baseline
            if (tier === 'Starter') {
                updatedFeatures = { ...baseFeatures, schedule: true, events: true, ops: true, messages: true, prep: true, team: true };
            } else if (tier === 'Pro') {
                updatedFeatures = { ...baseFeatures, schedule: true, events: true, ops: true, messages: true, prep: true, team: true, recipes: true, inventory: true, maintenance: true };
            } else if (tier === 'Elite') {
                updatedFeatures = { ...baseFeatures, schedule: true, events: true, ops: true, messages: true, prep: true, team: true, recipes: true, inventory: true, maintenance: true, sales: true, timesheets: true };
            } else if (tier === 'Enterprise') {
                // Enterprise: Everything (Up to 5 Locations)
                updatedFeatures = { ...baseFeatures, schedule: true, events: true, ops: true, messages: true, prep: true, team: true, recipes: true, inventory: true, maintenance: true, sales: true, timesheets: true };
                newLabs = { laborProjection: true };
            }

            // 3. Save the complete object (with explicit true/false flags) to state
            setEditingRest({
                ...editingRest,
                planType: tier,
                features: updatedFeatures,
                labs: newLabs
            });
          };
       
    
          return (
            <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2 custom-scrollbar">
<form onSubmit={handleUpdateTenant} className="space-y-4">
                {/* ACTIVE SEATS DASHBOARD */}
                <div className="flex justify-between items-center bg-[#12161A] p-4 rounded-xl border border-[#2A353D] mb-2 shadow-inner">
                  <div>
                    <div className="text-[10px] font-black uppercase tracking-widest text-slate-500">Active User Seats</div>
                    <div className="text-2xl font-black text-[#D4A381]">{userCounts[editingRest.id] || 0} <span className="text-xs text-slate-400 font-bold">Staff Members</span></div>
                  </div>
                  <div className="text-right">
                     <div className="text-[10px] font-black uppercase tracking-widest text-slate-500">Workspace ID</div>
                     <div className="text-xs font-mono font-bold text-slate-300">{editingRest.id}</div>
                  </div>
                </div>

                <div><label className={T.label}>Business Name</label><input type="text" value={editingRest.name} onChange={e => setEditingRest({...editingRest, name: e.target.value})} className={T.input} required /></div>
                <div><label className={T.label}>Owner Name</label><input type="text" value={editingRest.ownerName || ''} onChange={e => setEditingRest({...editingRest, ownerName: e.target.value})} className={T.input} required /></div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div><label className={T.label}>Owner Email</label><input type="email" value={editingRest.ownerEmail || ''} onChange={e => setEditingRest({...editingRest, ownerEmail: e.target.value})} className={T.input} required /></div>
                  <div><label className={T.label}>Owner Phone</label><input type="tel" value={editingRest.ownerPhone || ''} onChange={e => setEditingRest({...editingRest, ownerPhone: e.target.value})} className={T.input} required /></div>
                </div>
                <div><label className={T.label}>Street Address</label><input type="text" value={editingRest.systemSettings?.address || ''} onChange={e => setEditingRest({...editingRest, systemSettings: { ...editingRest.systemSettings, address: e.target.value }})} className={T.input} /></div>
                
   <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 mt-2">
                  <div><label className={T.label}>Plan Tier</label><select value={editingRest.planType || 'Pro'} onChange={e => setEditingRest({...editingRest, planType: e.target.value})} className={T.input}><option value="Trial">Trial</option><option value="Starter">Starter</option><option value="Pro">Pro</option><option value="Elite">Elite</option><option value="Enterprise">Enterprise</option></select></div>
                  <div><label className={T.label}>Billing Status</label><select value={editingRest.billingStatus || 'Paid'} onChange={e => setEditingRest({...editingRest, billingStatus: e.target.value})} className={`${T.input} ${editingRest.billingStatus === 'Past Due' ? 'text-red-500 font-black' : editingRest.billingStatus === 'Trial' ? 'text-blue-400 font-black' : 'text-emerald-500 font-black'}`}><option value="Trial">Trial (Free)</option><option value="Paid">Paid (Active)</option><option value="Past Due">Past Due (Lock App)</option></select></div>
                  <div><label className={T.label}>Custom Price ($)</label><input type="number" placeholder="Default" value={editingRest.customPrice || ''} onChange={e => setEditingRest({...editingRest, customPrice: e.target.value})} className={`${T.input} placeholder-slate-600`} /></div>
                  <div><label className={T.label}>Trial Length (Days)</label><input type="number" min="0" placeholder="14" value={editingRest.trialDays !== undefined ? editingRest.trialDays : 14} onChange={e => setEditingRest({...editingRest, trialDays: parseInt(e.target.value) || 0})} className={T.input} /></div>
                </div>
                
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <label className="flex items-center gap-2 p-3 bg-[#12161A] rounded-xl border border-[#2A353D] cursor-pointer hover:bg-[#1A2126] transition-colors"><input type="checkbox" checked={editingRest.isActive} onChange={e => setEditingRest({...editingRest, isActive: e.target.checked})} className="w-4 h-4 accent-emerald-500" /><span className={`text-xs font-black ${editingRest.isActive ? 'text-emerald-500' : 'text-slate-500'}`}>System Active</span></label>
                  <label className="flex items-center gap-2 p-3 bg-blue-900/10 rounded-xl border border-blue-900/50 cursor-pointer hover:bg-blue-900/20 transition-colors"><input type="checkbox" checked={editingRest.isReadOnly} onChange={e => setEditingRest({...editingRest, isReadOnly: e.target.checked})} className="w-4 h-4 accent-blue-500" /><span className={`text-xs font-black ${editingRest.isReadOnly ? 'text-blue-500' : 'text-slate-500'}`}>Read-Only Mode</span></label>
                </div>

                {/* Super-admin access is intentionally NOT managed here.
                    Use System Administrator > Grant Access so elevated permissions stay in one audited place. */}

                {/* QUICK APPLY TIER PRESETS */}
                <div className="pt-4 border-t border-[#2A353D]">
                  <label className={T.label}>Quick-Apply Tier Packages</label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2">
                    <button type="button" onClick={() => applyTierPreset('Starter')} className={`py-2.5 text-[10px] font-black uppercase tracking-widest rounded-lg border transition-colors ${editingRest.planType === 'Starter' ? 'bg-slate-100 text-slate-900 border-white shadow-[0_0_10px_rgba(255,255,255,0.2)]' : 'bg-[#12161A] text-slate-400 border-[#2A353D] hover:border-slate-500'}`}>Starter</button>
                    <button type="button" onClick={() => applyTierPreset('Pro')} className={`py-2.5 text-[10px] font-black uppercase tracking-widest rounded-lg border transition-colors ${editingRest.planType === 'Pro' ? 'bg-[#D4A381] text-slate-900 border-[#C59373] shadow-[0_0_10px_rgba(212,163,129,0.2)]' : 'bg-[#12161A] text-slate-400 border-[#2A353D] hover:border-[#D4A381]'}`}>Pro</button>
                    <button type="button" onClick={() => applyTierPreset('Elite')} className={`py-2.5 text-[10px] font-black uppercase tracking-widest rounded-lg border transition-colors ${editingRest.planType === 'Elite' ? 'bg-blue-500 text-white border-blue-400 shadow-[0_0_10px_rgba(59,130,246,0.2)]' : 'bg-[#12161A] text-slate-400 border-[#2A353D] hover:border-blue-500'}`}>Elite</button>
<button type="button" onClick={() => applyTierPreset('Enterprise')} className={`py-2.5 text-[10px] font-black uppercase tracking-widest rounded-lg border transition-colors ${editingRest.planType === 'Enterprise' ? 'bg-purple-500 text-white border-purple-400 shadow-[0_0_10px_rgba(168,85,247,0.2)]' : 'bg-[#12161A] text-slate-400 border-[#2A353D] hover:border-purple-500'}`} title="Up to 5 Locations">Enterprise</button>                  </div>
           <button type="button" onClick={() => {
                    applyTierPreset('Pro');
                    setEditingRest(prev => ({...prev, planType: 'Trial', billingStatus: 'Trial'}));
                  }} className={`w-full mt-2 py-3 text-[10px] font-black uppercase tracking-widest rounded-lg border transition-colors ${editingRest.billingStatus === 'Trial' ? 'bg-blue-500 text-white border-blue-400 shadow-[0_0_10px_rgba(59,130,246,0.2)]' : 'bg-blue-900/20 text-blue-400 border-blue-900/50 hover:bg-blue-900/40'}`}>
                    🎁 Start {editingRest.trialDays !== undefined ? editingRest.trialDays : 14}-Day Free Trial (Unlocks Pro Features)
                  </button>
                </div>

                {/* MANUAL MODULE OVERRIDES */}
                <div className="pt-4 border-t border-[#2A353D]">
                   <label className={T.label}>Manual Module Overrides</label>
                   <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-2">
                      {['schedule', 'events', 'ops', 'messages', 'prep', 'recipes', 'inventory', 'sales', 'team', 'maintenance', 'timesheets'].map(feat => (
                        <label key={feat} className={`flex items-center gap-2 p-2.5 rounded-lg border transition-colors cursor-pointer ${editingRest.features && editingRest.features[feat] ? 'bg-[#8F6040]/20 border-[#C59373]' : 'bg-[#12161A] border-[#2A353D] hover:bg-[#1A2126]'}`}>
                          <input type="checkbox" checked={editingRest.features ? editingRest.features[feat] : false} onChange={e => setEditingRest({...editingRest, features: { ...(editingRest.features || {}), [feat]: e.target.checked }})} className="w-4 h-4 accent-[#8F6040]" />
                          <span className={`text-[11px] font-bold capitalize ${editingRest.features && editingRest.features[feat] ? 'text-[#D4A381]' : 'text-slate-400'}`}>{feat}</span>
                        </label>
                      ))}
                   </div>
                </div>
                
                {/* LABS / CANARY ROLLOUT */}
                <div className="pt-2 border-t border-[#2A353D]">
                  <label className={T.label}>Labs / Beta Features (Canary Rollout)</label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <label className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer transition-colors ${editingRest.labs?.laborProjection ? 'bg-purple-900/20 border-purple-500/50' : 'bg-[#12161A] border-[#2A353D] hover:bg-[#1A2126]'}`}>
                      <input type="checkbox" checked={editingRest.labs?.laborProjection || false} onChange={e => setEditingRest({...editingRest, labs: { ...(editingRest.labs || {}), laborProjection: e.target.checked }})} className="w-4 h-4 accent-purple-500" />
                      <span className={`text-[11px] font-bold capitalize ${editingRest.labs?.laborProjection ? 'text-purple-400' : 'text-slate-400'}`}>Labor Projections</span>
                    </label>
                  </div>
                </div>

                <button type="submit" className={`w-full ${T.btn} bg-gradient-to-r from-red-600 to-red-800 text-white mt-4`}>Save Configuration</button>
              </form>

              {/* BACKUP & RESTORE */}
              <div className="pt-4 border-t border-[#2A353D] mt-4 space-y-3">
                <h4 className="text-[10px] uppercase tracking-widest text-emerald-500 font-black mb-2">Database Backup & Recovery</h4>
                <div className="grid grid-cols-2 gap-2">
                  <button type="button" onClick={() => handleCreateBackup(editingRest)} className="w-full bg-emerald-900/20 text-emerald-400 font-bold py-2.5 rounded-lg border border-emerald-900/50 hover:bg-emerald-900/40 transition-all text-[10px] uppercase tracking-widest flex items-center justify-center gap-2">
                    💾 Download JSON
                  </button>
                  <label className="w-full bg-blue-900/20 text-blue-400 font-bold py-2.5 rounded-lg border border-blue-900/50 hover:bg-blue-900/40 transition-all text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer">
                    <span>🔄 Upload Restore</span>
                    <input type="file" accept=".json" onChange={(e) => handleRestoreBackup(e, editingRest)} className="hidden" />
                  </label>
                </div>
                <button type="button" onClick={() => handleExportData(editingRest)} className="w-full bg-[#12161A] text-slate-300 font-bold py-2 rounded-xl border border-[#2A353D] hover:text-white transition-all text-xs flex items-center justify-center gap-2 mt-2">
                  <ClipboardList size={14}/> Download CSV User Export
                </button>
              </div>

              {/* DANGER ZONE */}
              <div className="pt-4 border-t border-red-900/50 mt-4 space-y-3">
                <div>
                  <h4 className="text-[10px] uppercase tracking-widest text-red-500 font-black mb-2 text-center">Danger Zone (Data Wipes)</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <button type="button" onClick={() => setNukeTarget({ rest: editingRest, type: 'inventory', label: 'Inventory & Vendors' })} className="w-full bg-red-900/10 text-red-500 font-bold py-2 rounded-lg border border-red-900/30 hover:bg-red-900/40 transition-all text-[10px] uppercase tracking-widest flex items-center justify-center gap-1"><Trash2 size={12}/> Inventory</button>
                    <button type="button" onClick={() => setNukeTarget({ rest: editingRest, type: 'schedule', label: 'Schedule & Time Off' })} className="w-full bg-red-900/10 text-red-500 font-bold py-2 rounded-lg border border-red-900/30 hover:bg-red-900/40 transition-all text-[10px] uppercase tracking-widest flex items-center justify-center gap-1"><Trash2 size={12}/> Schedule</button>
                    <button type="button" onClick={() => setNukeTarget({ rest: editingRest, type: 'recipes', label: 'All Recipes' })} className="w-full bg-red-900/10 text-red-500 font-bold py-2 rounded-lg border border-red-900/30 hover:bg-red-900/40 transition-all text-[10px] uppercase tracking-widest flex items-center justify-center gap-1"><Trash2 size={12}/> Recipes</button>
                    <button type="button" onClick={() => setNukeTarget({ rest: editingRest, type: 'events', label: 'Events & Messages' })} className="w-full bg-red-900/10 text-red-500 font-bold py-2 rounded-lg border border-red-900/30 hover:bg-red-900/40 transition-all text-[10px] uppercase tracking-widest flex items-center justify-center gap-1"><Trash2 size={12}/> Events/Msgs</button>
                    <button type="button" onClick={() => setNukeTarget({ rest: editingRest, type: 'users', label: 'All Users/Staff' })} className="w-full bg-red-900/10 text-red-500 font-bold py-2 rounded-lg border border-red-900/30 hover:bg-red-900/40 transition-all text-[10px] uppercase tracking-widest flex items-center justify-center gap-1"><Trash2 size={12}/> Users</button>
                    <button type="button" onClick={() => setNukeTarget({ rest: editingRest, type: 'everything', label: 'ABSOLUTELY EVERYTHING' })} className="w-full bg-red-600/20 text-red-500 font-black py-2 rounded-lg border border-red-500/50 hover:bg-red-600 hover:text-white transition-all text-[10px] uppercase tracking-widest flex items-center justify-center gap-1"><Trash2 size={12}/> NUKE ALL</button>
                  </div>
                </div>
              </div>

            </div>
          );
        })()}
      </Modal>

      <Modal isOpen={!!nukeTarget} onClose={() => { setNukeTarget(null); setNukePassword(''); }} title={`⚠️ CRITICAL: Nuke ${nukeTarget?.label}`}>
        <form onSubmit={handleNukeData} className="space-y-4">
          <div className="bg-red-900/20 border border-red-500/50 p-3 rounded-xl text-red-200 text-xs font-bold leading-relaxed">
            You are about to permanently delete <strong>{nukeTarget?.label}</strong> for <strong>{nukeTarget?.rest?.name}</strong>. This action cannot be undone.
          </div>
          <div>
            <label className={T.label}>Enter Your Master Admin Password</label>
            <input type="password" value={nukePassword} onChange={e => setNukePassword(e.target.value)} className={T.input} required placeholder="Authenticate to confirm..." disabled={isNuking} />
          </div>
          <button type="submit" disabled={isNuking} className={`w-full ${T.btn} bg-red-600 hover:bg-red-700 text-white flex justify-center items-center gap-2`}>
            {isNuking ? <Loader2 className="animate-spin" size={18} /> : <><Trash2 size={18} /> Permanently Delete Data</>}
          </button>
        </form>
      </Modal>

{/* --- TAB: OVERVIEW --- */}
      {subTab === 'overview' && (
        <div className="space-y-6 animate-[slideIn_0.2s_ease-out]">
          
          {/* PRIMARY REVENUE ROW */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className={`${T.card} p-5 bg-gradient-to-br from-[#1A2126] to-[#12161A] border-emerald-900/30`}><div className="text-[10px] font-black text-emerald-500 uppercase tracking-widest mb-1">Est. Platform MRR</div><div className="text-3xl lg:text-4xl font-black text-white">${mrr.toLocaleString()}<span className="text-sm lg:text-lg text-slate-500">/mo</span></div></div>
            <div className={`${T.card} p-5 bg-gradient-to-br from-[#1A2126] to-[#12161A]`}><div className="text-[10px] font-black text-[#D4A381] uppercase tracking-widest mb-1">Active Tenants</div><div className="text-3xl lg:text-4xl font-black text-white">{restaurants.filter(r=>r.isActive).length}</div></div>
            <div className={`${T.card} p-5 bg-gradient-to-br from-[#1A2126] to-[#12161A]`}><div className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-1">Network Users</div><div className="text-3xl lg:text-4xl font-black text-white">{allUsers.length}</div></div>
            {appUser?.email?.toLowerCase() === 'geoffm1985@gmail.com' && (
              <div className={`${T.card} p-5 bg-gradient-to-br from-[#1A2126] to-[#12161A] border-fuchsia-900/30`}><div className="text-[10px] font-black text-fuchsia-400 uppercase tracking-widest mb-1">Total App Installs</div><div className="text-3xl lg:text-4xl font-black text-white">{totalInstalls}</div></div>
            )}          
          </div>

{/* SECONDARY ENGAGEMENT & PIPELINE ROW */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className={`${T.card} p-4 bg-gradient-to-br from-[#1A2126] to-[#12161A]`}><div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Paid Workspaces</div><div className="text-2xl lg:text-3xl font-black text-white">{paidWorkspaces} <span className="text-[10px] text-slate-300 tracking-widest uppercase align-middle bg-[#12161A] border border-[#2A353D] px-1.5 py-0.5 rounded">ARPA: ${arpa}</span></div></div>
            <div className={`${T.card} p-4 bg-gradient-to-br from-[#1A2126] to-[#12161A] border-blue-900/30`}><div className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-1">Active Trials</div><div className="text-2xl lg:text-3xl font-black text-white">{activeTrials} <span className="text-[10px] text-blue-400 tracking-widest uppercase align-middle bg-blue-900/20 border border-blue-900/50 px-1.5 py-0.5 rounded">Pipe: ${trialPipelineValue}</span></div></div>
            <div className={`${T.card} p-4 bg-gradient-to-br from-[#1A2126] to-[#12161A]`}><div className="text-[10px] font-black text-orange-400 uppercase tracking-widest mb-1">Daily Active (DAU)</div><div className="text-2xl lg:text-3xl font-black text-white">{dau} <span className="text-[10px] text-orange-500 tracking-widest uppercase align-middle bg-orange-900/20 border border-orange-900/50 px-1.5 py-0.5 rounded">Today</span></div></div>
            <div className={`${T.card} p-4 bg-gradient-to-br from-[#1A2126] to-[#12161A]`}><div className="text-[10px] font-black text-purple-400 uppercase tracking-widest mb-1">App Sticky Rate</div><div className={`text-2xl lg:text-3xl font-black ${stickyRate < 30 ? 'text-red-400' : 'text-emerald-400'}`}>{stickyRate}% <span className="text-[10px] text-slate-500 tracking-widest uppercase align-middle bg-[#12161A] border border-[#2A353D] px-1.5 py-0.5 rounded text-white">Adoption</span></div></div>
          </div>

          {/* PRICING & MRR CONFIG */}
          {/* ... (Your pricing and stale account code remains exactly the same here) ... */}

          <div className={`${T.card} p-4`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
              <div>
                <h3 className="font-black text-white text-sm flex items-center gap-2"><Shield size={18} className={T.copper}/> Administrator Action Queue</h3>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Only the important warnings. Less disco ball, more control tower.</p>
              </div>
              <span className={`text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-lg border ${platformStatus === 'Clean' ? 'bg-emerald-900/20 text-emerald-400 border-emerald-900/50' : platformStatus === 'Monitoring' ? 'bg-amber-900/20 text-amber-400 border-amber-900/50' : 'bg-red-900/20 text-red-400 border-red-900/50'}`}>{platformStatus}</span>
            </div>
            {adminRiskQueue.length === 0 ? (
              <div className="bg-[#12161A] border border-[#2A353D] rounded-xl p-4 text-sm font-bold text-emerald-400">No urgent admin issues detected.</div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-2">
                {adminRiskQueue.slice(0, 6).map((item, idx) => (
                  <button key={idx} type="button" onClick={() => setSubTab(item.jump)} className={`text-left bg-[#12161A] border rounded-xl p-3 hover:bg-[#0B0E11] transition-colors ${item.tone === 'red' ? 'border-red-900/50' : item.tone === 'amber' ? 'border-amber-900/50' : 'border-[#2A353D]'}`}>
                    <div className={`text-[10px] font-black uppercase tracking-widest mb-1 ${item.tone === 'red' ? 'text-red-400' : item.tone === 'amber' ? 'text-amber-400' : 'text-emerald-400'}`}>{item.title}</div>
                    <div className="text-xs text-slate-300 font-bold leading-snug">{item.detail}</div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* --- GLOBAL INFRASTRUCTURE & HEALTH MATRIX --- */}
          <div className={`${T.card} overflow-hidden border-slate-700/50`}>
            <div className={`bg-[#12161A] p-4 border-b ${T.border} flex justify-between items-center`}>
              <h3 className="font-black text-lg text-white flex items-center gap-2"><Globe className="text-blue-500" size={18}/> Infrastructure Health Matrix</h3>
              <span className="bg-[#1A2126] text-slate-400 px-2 py-1 rounded text-[10px] font-black uppercase tracking-widest border border-[#2A353D]">Version {CURRENT_VERSION}</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-[#2A353D]">
              
              {/* Shard Status */}
              <div className="p-5 flex items-center justify-between hover:bg-[#12161A]/50 transition-colors">
                <div>
                  <div className="font-black text-white text-sm">Core Database Shards</div>
                  <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">Firebase Firestore DB</div>
                </div>
                <div className="flex items-center gap-2 bg-emerald-900/20 border border-emerald-900/50 px-3 py-1.5 rounded-lg">
                  <span className="cockpit-light quiet bg-emerald-400 text-emerald-400"></span>
                  <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400">Operational</span>
                </div>
              </div>

              {/* Stability Status */}
              <div className="p-5 flex items-center justify-between hover:bg-[#12161A]/50 transition-colors">
                <div>
                  <div className="font-black text-white text-sm">Application Stability</div>
                  <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">{crashes24h} Crashes (Last 24h)</div>
                </div>
                <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border ${crashes24h > 10 ? 'bg-red-900/20 border-red-900/50 text-red-400 animate-pulse' : crashes24h > 0 ? 'bg-orange-900/20 border-orange-900/50 text-orange-400' : 'bg-emerald-900/20 border-emerald-900/50 text-emerald-400'}`}>
                  {crashes24h > 10 ? <Bug size={14}/> : <Check size={14}/>}
                  <span className="text-[10px] font-black uppercase tracking-widest">{crashes24h > 10 ? 'Degraded' : crashes24h > 0 ? 'Monitoring' : 'Stable'}</span>
                </div>
              </div>

              {/* Push Relay Status */}
              <div className="p-5 flex items-center justify-between border-t border-[#2A353D] hover:bg-[#12161A]/50 transition-colors">
                <div>
                  <div className="font-black text-white text-sm">Push Notification Relay</div>
                  <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">{pushOptInRate}% Global Opt-In Rate</div>
                </div>
                <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border ${pushOptInRate < 30 ? 'bg-orange-900/20 border-orange-900/50 text-orange-400' : 'bg-emerald-900/20 border-emerald-900/50 text-emerald-400'}`}>
                  <Bell size={14}/>
                  <span className="text-[10px] font-black uppercase tracking-widest">{pushOptInRate < 30 ? 'Low Adoption' : 'Active'}</span>
                </div>
              </div>

              {/* API Webhooks Status */}
              <div className="p-5 flex items-center justify-between border-t border-[#2A353D] hover:bg-[#12161A]/50 transition-colors">
                <div>
                  <div className="font-black text-white text-sm">External API Webhooks</div>
                  <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">POS & Payroll Sync</div>
                </div>
                <div className="flex items-center gap-2 bg-[#12161A] border border-[#2A353D] px-3 py-1.5 rounded-lg">
                  <Repeat size={14} className="text-blue-400"/>
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-300">{apiConnectedCount} Endpoints Live</span>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* --- TAB: LIVE OPS / PRESENCE RADAR --- */}
      {subTab === 'live' && (
        <div className="space-y-4 animate-[slideIn_0.2s_ease-out]">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2 cockpit-panel rounded-2xl overflow-hidden">
              <div className={`bg-[#12161A] p-3 border-b ${T.border} flex items-center justify-between gap-3`}>
                <h3 className="font-black text-sm text-white flex items-center gap-2"><span className="cockpit-light bg-emerald-400 text-emerald-400 hot"></span> Live Users Now</h3>
                <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400">{onlineUsers.length} active</span>
              </div>
              <div className={`divide-y ${T.border} max-h-[55vh] overflow-y-auto custom-scrollbar`}>
                {onlineUsers.length === 0 && <div className="p-8 text-center text-slate-500 font-bold">No one is currently heartbeating. Newly loaded clients will appear here within about a minute.</div>}
                {onlineUsers.map(u => {
                  const restName = restaurants.find(r => r.id === u.restaurantId)?.name || 'Unknown Workspace';
                  return (
                    <div key={u.id} className="p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-[#12161A]/55 transition-colors">
                      <div className="min-w-0 flex items-center gap-3">
                        <img src={getAvatar(u.name, u.photoURL)} className={`w-8 h-8 rounded-full border ${T.border} object-cover`} alt="avatar"/>
                        <div className="min-w-0">
                          <div className="text-sm font-black text-white truncate flex items-center gap-2">{u.name || 'Unnamed User'} <SignalPip tone="emerald" label="ONLINE" hot /></div>
                          <div className="text-[10px] text-slate-400 font-bold truncate">{restName} • {u.role || 'No role'} • {u.activeTab ? `Tab: ${u.activeTab}` : 'Tab: unknown'}</div>
                          <div className="text-[9px] text-slate-500 font-mono truncate">{u.email || 'No email'} • {u.activeDevice || 'Unknown device'}</div>
                        </div>
                      </div>
                      <button onClick={() => { setGhostTenant({ id: u.restaurantId, name: restName, mode: 'user', impersonate: u }); setActiveTab('published'); }} className="px-3 py-1.5 bg-fuchsia-900/20 border border-fuchsia-500/50 text-fuchsia-400 font-bold text-[10px] uppercase tracking-widest rounded-lg hover:bg-fuchsia-900/40 transition-colors shadow-sm flex items-center justify-center gap-1"><Moon size={14} /> Possess</button>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="cockpit-panel rounded-2xl overflow-hidden">
              <div className={`bg-[#12161A] p-3 border-b ${T.border}`}>
                <h3 className="font-black text-sm text-white">Active Workspaces</h3>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Grouped by live heartbeat</p>
              </div>
              <div className={`divide-y ${T.border} max-h-[55vh] overflow-y-auto custom-scrollbar`}>
                {onlineByRestaurant.length === 0 && <div className="p-6 text-center text-slate-500 font-bold text-sm">No active workspaces.</div>}
                {onlineByRestaurant.map(group => (
                  <div key={group.id} className="p-3 hover:bg-[#12161A]/55 transition-colors">
                    <div className="flex items-center justify-between gap-2">
                      <div className="font-black text-white text-sm truncate">{group.rest?.name || group.id}</div>
                      <div className="flex items-center gap-1.5 text-emerald-400 text-[10px] font-black"><span className="cockpit-light bg-emerald-400 text-emerald-400"></span>{group.users.length}</div>
                    </div>
                    <div className="text-[10px] text-slate-400 font-bold mt-1 truncate">{group.users.map(u => (u.name || u.email || 'User').split(' ')[0]).join(', ')}</div>
                    <button onClick={() => { setGhostTenant({ id: group.id, name: group.rest?.name || group.id, mode: 'workspace' }); setActiveTab('published'); }} className="mt-2 w-full px-2 py-1.5 bg-purple-900/20 border border-purple-500/40 text-purple-300 font-black text-[9px] uppercase tracking-widest rounded-lg hover:bg-purple-900/40">Possess Workspace</button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="cockpit-panel rounded-2xl p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-black text-white text-sm">Recent Activity Buffer</h3>
                <SignalPip tone="amber" label={`${recentlyActiveUsers.length} warm`} />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {recentlyActiveUsers.slice(0, 12).map(u => {
                  const restName = restaurants.find(r => r.id === u.restaurantId)?.name || 'Unknown';
                  return <div key={u.id} className="bg-[#0B0E11] border border-[#2A353D] rounded-lg p-2"><div className="text-xs font-black text-white truncate">{u.name || u.email}</div><div className="text-[9px] font-bold text-slate-500 uppercase tracking-wider truncate">{restName} • {timeAgo(u.lastActive)}</div></div>
                })}
                {recentlyActiveUsers.length === 0 && <div className="text-sm text-slate-500 font-bold">No recently active users outside the live window.</div>}
              </div>
            </div>

            <div className="cockpit-panel rounded-2xl p-4">
              <h3 className="font-black text-white text-sm mb-3">Control Tower Signals</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  ['Auth Gate', 'emerald', 'Firebase Auth ready'],
                  ['Tenant Rules', 'emerald', 'Super admin override'],
                  ['Ghost Layer', 'purple', 'Possess enabled'],
                  ['Push Relay', pushOptInRate < 30 ? 'amber' : 'emerald', `${pushOptInRate}% opt-in`],
                  ['Crash Intake', crashes24h ? 'amber' : 'emerald', `${crashes24h} today`],
                  ['Backup Engine', 'blue', 'JSON export ready'],
                  ['Billing Locks', staleTenants.length ? 'amber' : 'emerald', `${staleTenants.length} stale`],
                  ['API Routes', 'blue', `${apiConnectedCount} integrations`],
                  ['Online Radar', onlineUsers.length ? 'emerald' : 'amber', `${onlineUsers.length} live`]
                ].map(([name, tone, detail]) => (
                  <div key={name} className="bg-[#0B0E11] border border-[#2A353D] rounded-lg p-2.5 min-h-[70px]">
                    <SignalPip tone={tone} label={name} hot={tone === 'amber'} />
                    <div className="text-[10px] text-slate-400 font-bold mt-2 leading-tight">{detail}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- TAB: TENANTS --- */}
      {subTab === 'tenants' && (
        <div className="space-y-6 animate-[slideIn_0.2s_ease-out]">
 <form onSubmit={handleDeployTenant} className={`${T.card} p-5 border-red-900/50 shadow-[0_0_20px_rgba(220,38,38,0.1)]`}>
            <div className="mb-4 pb-2 border-b border-[#2A353D]"><h2 className="text-lg font-black text-white flex items-center gap-2">Deploy New Workspace</h2></div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input type="text" placeholder="Restaurant Name" value={rName} onChange={e=>setRName(e.target.value)} className={T.input} required />
              <input type="text" placeholder="Full Street Address" value={rAddress} onChange={e=>setRAddress(e.target.value)} className={T.input} required />
              <input type="text" placeholder="Owner Name" value={oName} onChange={e=>setOName(e.target.value)} className={T.input} required />
              <input type="email" placeholder="Owner Email" value={oEmail} onChange={e=>setOEmail(e.target.value)} className={T.input} required />
              <input type="tel" placeholder="Owner Phone" value={oPhone} onChange={e=>setOPhone(e.target.value)} className={`${T.input} sm:col-span-2`} required />
            </div>
            <button type="submit" className="w-full bg-red-600 hover:bg-red-700 text-white font-black uppercase tracking-widest py-3 rounded-xl shadow-lg mt-4 transition-colors">Deploy Database & Email Credentials</button>
          </form>

          <div className={`${T.card} overflow-hidden`}>
            <div className={`bg-[#12161A] p-4 border-b ${T.border} flex justify-between items-center`}><h3 className="font-black text-sm text-white">Client Roster</h3><span className="bg-[#1A2126] text-slate-400 px-2 py-1 rounded text-[10px] font-black uppercase tracking-widest border border-[#2A353D]">{restaurants.length} Total</span></div>
<div className={`divide-y ${T.border}`}>
{restaurants.map(r => {
                // Subscription Math Engine
                const createdDate = new Date(r.createdAt || Date.now());
                const trialDurationDays = r.trialDays !== undefined ? parseInt(r.trialDays) : 14;
                const trialEndDate = new Date(createdDate.getTime() + trialDurationDays * 24 * 60 * 60 * 1000);
                const isTrialActive = r.billingStatus === 'Trial';
                const daysInTrial = Math.ceil((trialEndDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
                
                const nextBill = new Date();
                nextBill.setDate(createdDate.getDate());
                if (nextBill <= new Date()) nextBill.setMonth(nextBill.getMonth() + 1);

                return (
                <div key={r.id} className={`${T.row} flex flex-col xl:flex-row justify-between xl:items-center gap-4`}>
                  <div className="flex-1 min-w-0">
                    <div className="font-black text-white text-lg flex items-center gap-2 flex-wrap">
                      <span className="truncate">{r.name}</span>
                      {!r.isActive && <span className="bg-red-500 text-white text-[8px] px-1.5 py-0.5 rounded uppercase">Suspended</span>}
                      {r.isReadOnly && <span className="bg-blue-900 text-blue-300 border border-blue-500/50 text-[8px] px-1.5 py-0.5 rounded uppercase">Read-Only</span>}
                      {r.billingStatus === 'Past Due' ? <span className="bg-red-900 text-red-400 border border-red-500/50 text-[8px] px-1.5 py-0.5 rounded uppercase animate-pulse">Past Due</span> : <span className="bg-emerald-900 text-emerald-400 border border-emerald-500/50 text-[8px] px-1.5 py-0.5 rounded uppercase">{r.planType || 'Pro'}</span>}
                    </div>
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Owner: {r.ownerName} <span className="mx-1">•</span> {r.ownerEmail} {r.ownerPhone && <><span className="mx-1">•</span> {r.ownerPhone}</>}</div>
                    
                    {/* BILLING & SUBSCRIPTION HUD */}
                    <div className="flex flex-wrap items-center gap-3 mt-2 mb-1 bg-[#0B0E11] border border-[#2A353D] p-2.5 rounded-lg w-full xl:w-max">
                      <div className="flex flex-col">
                        <span className="text-[8px] font-black uppercase tracking-widest text-slate-500">Service Started</span>
                        <span className="text-[10px] font-bold text-slate-300">{createdDate.toLocaleDateString()}</span>
                      </div>
                      <div className="h-6 w-px bg-[#2A353D]"></div>
        {isTrialActive ? (
                        <div className="flex flex-col">
                          <span className="text-[8px] font-black uppercase tracking-widest text-blue-400">{trialDurationDays}-Day Free Trial</span>
                          <span className="text-[10px] font-bold text-blue-300">Ends {trialEndDate.toLocaleDateString()} ({daysInTrial > 0 ? `${daysInTrial} days left` : 'Expired'})</span>
                        </div>
                      ) : (
                        <div className="flex flex-col">
                          <span className="text-[8px] font-black uppercase tracking-widest text-emerald-500">Next Billing Cycle</span>
                          <span className="text-[10px] font-bold text-emerald-400">{r.billingStatus === 'Past Due' ? 'PAYMENT FAILED' : nextBill.toLocaleDateString()}</span>
                        </div>
                      )}
                    </div>

                    <div className="text-[9px] text-slate-500 font-medium mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1">ID: {r.id}<span>•</span><span className="text-white font-bold">{userCounts[r.id] || 0} Seats</span><span>•</span><span className="text-emerald-400 font-black flex items-center gap-1"><span className="cockpit-light bg-emerald-400 text-emerald-400"></span>{onlineUsers.filter(u => u.restaurantId === r.id).length} Online</span><span>•</span><span className={timeAgo(r.lastActive).includes('Inactive') ? 'text-red-400' : 'text-emerald-500'}>Ping: {timeAgo(r.lastActive)}</span></div>
                  </div>
                  <div className="flex flex-wrap gap-2 flex-shrink-0">
<button onClick={() => setEditingRest(r)} className="px-3 py-1.5 bg-[#12161A] border border-[#2A353D] text-slate-300 font-bold text-[10px] uppercase tracking-widest rounded-lg hover:text-[#D4A381] hover:border-[#D4A381]/50 transition-colors shadow-sm flex items-center gap-1"><Settings size={14} /> Manage</button>
                    <button onClick={() => { setGhostTenant({ id: r.id, name: r.name, mode: 'workspace' }); setActiveTab('published'); }} className="px-3 py-1.5 bg-purple-900/20 border border-purple-500/50 text-purple-400 font-bold text-[10px] uppercase tracking-widest rounded-lg hover:bg-purple-900/50 transition-colors shadow-sm flex items-center gap-1"><Moon size={14} /> Possess</button>
                    <button onClick={() => handleDeleteTenant(r.id, r.name)} className="px-3 py-1.5 bg-red-900/10 border border-red-900/30 text-red-500 font-bold text-[10px] uppercase tracking-widest rounded-lg hover:bg-red-900/40 transition-colors shadow-sm"><Trash2 size={12}/></button>
                  </div>
                </div>
              )})}
            </div>
          </div>
        </div>
      )}

      {/* --- TAB: GLOBAL USERS --- */}
      {subTab === 'users' && (
        <div className="space-y-6 animate-[slideIn_0.2s_ease-out]">
          <div className={`${T.card} p-4 flex gap-3 items-center`}>
            <Search className={T.copper} size={20}/>
            <input type="text" placeholder="Search any user by name, email, role, or ID..." value={userSearch} onChange={e=>setUserSearch(e.target.value)} className={T.input}/>
          </div>

          <form onSubmit={handleBulkDeleteUsersByEmail} className={`${T.card} p-4 border-red-900/40 bg-red-950/10`}>
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 mb-3">
              <div>
                <h3 className="font-black text-sm text-red-300 flex items-center gap-2"><Trash2 size={16}/> Bulk Delete Users by Email</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Paste one or many emails. This is for duplicate/bad accounts. Geoff/current admin emails are protected.</p>
              </div>
              {duplicateEmailGroups.length > 0 && <button type="button" onClick={loadDuplicateEmailsIntoBulkDelete} className="text-[9px] font-black uppercase tracking-widest text-red-300 border border-red-900/50 px-2 py-1.5 rounded-lg hover:bg-red-900/20">Load Duplicate Emails</button>}
            </div>
            <textarea value={bulkDeleteEmails} onChange={e=>setBulkDeleteEmails(e.target.value)} rows="3" className={`${T.input} font-mono text-xs`} placeholder="bad@email.com
duplicate@email.com
another@email.com"></textarea>
            <div className="flex flex-col sm:flex-row gap-2 mt-3">
              <button type="submit" disabled={isBulkDeletingUsers} className="flex-1 bg-red-900/30 text-red-200 border border-red-700/60 hover:bg-red-900/50 font-black uppercase tracking-widest py-2.5 rounded-lg text-xs disabled:opacity-50 flex items-center justify-center gap-2">
                {isBulkDeletingUsers ? <Loader2 className="animate-spin" size={14}/> : <Trash2 size={14}/>} Delete Matching Users
              </button>
              <button type="button" onClick={() => setBulkDeleteEmails('')} className={`${T.btnAlt} sm:w-32`}>Clear</button>
            </div>
          </form>

          <div className={`divide-y ${T.border} ${T.card} max-h-[70vh] overflow-y-auto custom-scrollbar`}>
            {allUsers.filter(u => {
              const restName = restaurants.find(r => r.id === u.restaurantId)?.name || '';
              return (u.name + u.email + u.role + u.id + restName).toLowerCase().includes(userSearch.toLowerCase());
            }).slice(0, 50).map(u => {              
              const restName = restaurants.find(r => r.id === u.restaurantId)?.name || 'Unknown Location';
              return (
                <div key={u.id} className={`${T.row} flex flex-col md:flex-row justify-between md:items-center gap-3`}>
                  <div>
                    <div className="font-bold text-white text-sm">{u.name} {u.isAdmin && <span className="bg-red-500 text-white text-[8px] px-1.5 py-0.5 rounded uppercase ml-1">Admin</span>}</div>
                    <div className="text-[10px] text-slate-400 font-medium">{u.email} <span className="mx-1"> </span> <span className={T.copper}>{u.role}</span></div>
                    <div className="text-[9px] text-slate-500 mt-0.5 tracking-widest uppercase flex flex-wrap items-center gap-x-2 gap-y-1">{restName}<span>|</span>{isOnlineNow(u) ? <span className="text-emerald-400 font-black flex items-center gap-1"><span className="cockpit-light bg-emerald-400 text-emerald-400 hot"></span>Online Now</span> : <span className={timeAgo(u.lastActive).includes('Inactive') ? 'text-red-400' : 'text-emerald-500'}>Ping: {timeAgo(u.lastActive)}</span>}</div>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
<button onClick={() => { setGhostTenant({ id: u.restaurantId, name: restName, mode: 'user', impersonate: u }); setActiveTab('published'); }} className="px-3 py-1.5 bg-fuchsia-900/20 border border-fuchsia-500/50 text-fuchsia-400 font-bold text-[10px] uppercase tracking-widest rounded-lg hover:bg-fuchsia-900/40 transition-colors shadow-sm flex items-center gap-1"><Moon size={14} /> Possess</button>
                    <button onClick={() => handleBackupEmployee(u)} className="p-1.5 bg-[#12161A] border border-[#2A353D] text-slate-400 hover:text-emerald-400 rounded-lg transition-colors shadow-sm" title="Download User Data JSON">
                      💾
                    </button>
                    <label className="p-1.5 bg-[#12161A] border border-[#2A353D] text-slate-400 hover:text-blue-400 rounded-lg transition-colors shadow-sm cursor-pointer" title="Inject Data to User">
                      <input type="file" accept=".json" onChange={(e) => handleRestoreEmployee(e, u)} className="hidden" />
                      🔄
                    </label>
              <button onClick={async () => {
                      if(!window.confirm(`Force ${u.name} to log out and clear their device cache?`)) return;
                      await updateDoc(doc(db, "users", u.id), { forceLogout: true });
                      addToast('Executed', 'Kill signal sent to user device.');
                    }} className="p-1.5 bg-orange-900/20 border border-orange-900/50 text-orange-500 hover:bg-orange-900/40 rounded-lg transition-colors shadow-sm" title="Force Logout & Cache Clear">
                      🔌
                    </button>
                    <button onClick={async () => {
                      if(!window.confirm(`Force ${u.name} into the Password Reset flow on their next login?`)) return;
                      await updateDoc(doc(db, "users", u.id), { forcePasswordChange: true });
                      addToast('Executed', 'User must reset password on next login.');
                    }} className="p-1.5 bg-yellow-900/20 border border-yellow-900/50 text-yellow-500 hover:bg-yellow-900/40 rounded-lg transition-colors shadow-sm" title="Force Password Reset Screen">
                      🔑
                    </button>
                    <button onClick={() => handleDeleteGlobalUser(u)} className="p-1.5 bg-red-900/10 border border-red-900/30 text-red-500 hover:bg-red-900/40 rounded-lg transition-colors shadow-sm" title="Delete Account">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

{/* --- TAB: THE FORGE --- */}
      {subTab === 'forge' && (
        <div className="space-y-6 animate-[slideIn_0.2s_ease-out]">
          <form onSubmit={(e) => handleForgePush(e, 'Event')} className={`${T.card} p-5`}>
            <div className="mb-4 pb-2 border-b border-[#2A353D]"><h2 className="text-lg font-black text-white flex items-center gap-2"><Calendar className={T.copper} size={18}/> Global Event Injection</h2><p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mt-1">Force an event onto every client's calendar simultaneously.</p></div>
            <div className="flex flex-col sm:flex-row gap-3"><input type="date" value={forgeEventDate} onChange={e=>setForgeEventDate(e.target.value)} className={`${T.input} sm:w-48`} required /><input type="text" placeholder="Event Title (e.g. Mother's Day)" value={forgeEventTitle} onChange={e=>setForgeEventTitle(e.target.value)} className={T.input} required /><button type="submit" className={`${T.btn} px-8 whitespace-nowrap`}>Push Event</button></div>
          </form>
        </div>
      )}

      {/* --- TAB: SUPPORT & CRASHES --- */}
      {subTab === 'support' && (
        <div className="space-y-4 animate-[slideIn_0.2s_ease-out]">
          <div className="cockpit-panel rounded-2xl p-4 overflow-hidden relative">
            <div className="absolute inset-0 cockpit-grid opacity-30 pointer-events-none"></div>
            <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="font-black text-sm text-white flex items-center gap-2"><Bug className="text-orange-500" size={18}/> Support Diagnostics Bay</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Runtime, auth, database integrity, API checks, crash ledger, and ghost-access clues.</p>
              </div>
              <div className="flex gap-2">
                <button onClick={handleCopyDiagnostics} className="text-[9px] font-black uppercase tracking-widest text-[#D4A381] hover:text-white border border-[#2A353D] px-2 py-1 rounded transition-colors">Copy Diagnostics</button>
                <button onClick={() => { if(window.confirm("Clear all crash logs?")) { crashLogs.forEach(log => deleteDoc(doc(db, "crashReports", log.id))); } }} className="text-[9px] font-black uppercase tracking-widest text-slate-500 hover:text-red-500 border border-[#2A353D] px-2 py-1 rounded transition-colors">Clear Logs</button>
              </div>
            </div>

            <div className="relative z-10 grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
              <CockpitMetric label="Permission Denied" value={permissionDeniedLogs.length} detail="Firestore rule hits" tone={permissionDeniedLogs.length ? 'red' : 'emerald'} hot={permissionDeniedLogs.length > 0} />
              <CockpitMetric label="Missing Owners" value={missingOwnerAccounts.length} detail="Owner email no user doc" tone={missingOwnerAccounts.length ? 'amber' : 'emerald'} hot={missingOwnerAccounts.length > 0} />
              <CockpitMetric label="No Restaurant ID" value={usersWithoutRestaurant.length} detail="Users orphaned from tenant" tone={usersWithoutRestaurant.length ? 'amber' : 'emerald'} hot={usersWithoutRestaurant.length > 0} />
              <CockpitMetric label="Duplicate Emails" value={duplicateEmailGroups.length} detail="Auth/profile mismatch risk" tone={duplicateEmailGroups.length ? 'red' : 'emerald'} hot={duplicateEmailGroups.length > 0} />
            </div>

            <div className="relative z-10 grid grid-cols-1 lg:grid-cols-3 gap-3">
              <div className="bg-[#0B0E11] border border-[#2A353D] rounded-xl p-3">
                <div className="flex items-center justify-between mb-2"><div className="text-[10px] font-black uppercase tracking-widest text-slate-500">Runtime</div><SignalPip tone={envReport.online ? 'emerald' : 'red'} label={envReport.online ? 'ONLINE' : 'OFFLINE'} hot={!envReport.online}/></div>
                <div className="space-y-1 text-[10px] font-mono text-slate-400 break-all">
                  <div><span className="text-slate-600">Host:</span> {envReport.host}</div>
                  <div><span className="text-slate-600">Version:</span> {CURRENT_VERSION}</div>
                  <div><span className="text-slate-600">Notifications:</span> {envReport.notifications}</div>
                  <div><span className="text-slate-600">IndexedDB:</span> {envReport.indexedDb ? 'available' : 'missing'}</div>
                  <div><span className="text-slate-600">Service Worker:</span> {envReport.serviceWorker ? 'available' : 'missing'}</div>
                  <div><span className="text-slate-600">Cached User:</span> {envReport.storageUser ? 'yes' : 'no'}</div>
                </div>
              </div>

              <div className="bg-[#0B0E11] border border-[#2A353D] rounded-xl p-3">
                <div className="flex items-center justify-between mb-2"><div className="text-[10px] font-black uppercase tracking-widest text-slate-500">API Route Checklist</div><SignalPip tone="blue" label="VERCEL"/></div>
                <div className="grid grid-cols-1 gap-1.5">
                  {endpointList.map(ep => (
                    <div key={ep} className="flex items-center justify-between text-[10px] font-bold bg-[#12161A] border border-[#2A353D] rounded-lg px-2 py-1.5">
                      <span className="text-slate-300">/api/{ep}</span>
                      <span className="text-slate-500 uppercase tracking-widest">present in repo</span>
                    </div>
                  ))}
                </div>
                <p className="text-[9px] text-slate-600 font-bold mt-2 leading-snug">If a route returns HTML or 404, Vercel did not deploy that file or the filename does not match the fetch path.</p>
              </div>

              <div className="bg-[#0B0E11] border border-[#2A353D] rounded-xl p-3">
                <div className="flex items-center justify-between mb-2"><div className="text-[10px] font-black uppercase tracking-widest text-slate-500">Access Model</div><SignalPip tone="purple" label="RULES"/></div>
                <div className="space-y-1.5 text-[10px] font-bold text-slate-400">
                  <div className="flex justify-between gap-2"><span>Super admins</span><span className="text-white">{superAdmins.length}</span></div>
                  <div className="flex justify-between gap-2"><span>Master email</span><span className="text-[#D4A381]">{MASTER_ADMIN_EMAIL}</span></div>
                  <div className="flex justify-between gap-2"><span>Ghost needs rules</span><span className="text-emerald-400">isSuperAdmin()</span></div>
                  <div className="flex justify-between gap-2"><span>Read-only clients</span><span className="text-blue-400">{readOnlyWorkspaces.length}</span></div>
                  <div className="flex justify-between gap-2"><span>Past due lockouts</span><span className="text-red-400">{pastDueWorkspaces.length}</span></div>
                </div>
              </div>
            </div>

            {(missingOwnerAccounts.length > 0 || usersWithoutRestaurant.length > 0 || duplicateEmailGroups.length > 0) && (
              <div className="relative z-10 mt-3 grid grid-cols-1 lg:grid-cols-3 gap-3">
                {missingOwnerAccounts.length > 0 && <div className="bg-amber-900/10 border border-amber-900/50 rounded-xl p-3"><div className="text-[10px] font-black uppercase tracking-widest text-amber-400 mb-2">Missing Owner Accounts</div>{missingOwnerAccounts.slice(0,8).map(r => <div key={r.id} className="text-[10px] text-slate-400 font-bold break-all mb-1">{r.name}: {r.ownerEmail}</div>)}</div>}
                {usersWithoutRestaurant.length > 0 && <div className="bg-amber-900/10 border border-amber-900/50 rounded-xl p-3"><div className="text-[10px] font-black uppercase tracking-widest text-amber-400 mb-2">Users Without Restaurant</div>{usersWithoutRestaurant.slice(0,8).map(u => <div key={u.id} className="text-[10px] text-slate-400 font-bold break-all mb-1">{u.name || 'Unnamed'}: {u.email || u.id}</div>)}</div>}
                {duplicateEmailGroups.length > 0 && <div className="bg-red-900/10 border border-red-900/50 rounded-xl p-3"><div className="flex items-center justify-between gap-2 mb-2"><div className="text-[10px] font-black uppercase tracking-widest text-red-400">Duplicate Email Groups</div><button onClick={loadDuplicateEmailsIntoBulkDelete} className="text-[8px] font-black uppercase tracking-widest text-red-300 border border-red-900/50 px-2 py-1 rounded hover:bg-red-900/30">Open Cleanup</button></div>{duplicateEmailGroups.slice(0,8).map(([email, group]) => <div key={email} className="text-[10px] text-slate-400 font-bold break-all mb-1">{email}: {group.length} profiles</div>)}</div>}
              </div>
            )}
          </div>

          <div className={`${T.card} overflow-hidden`}>
            <div className={`bg-[#12161A] p-4 border-b ${T.border} flex justify-between items-center`}>
              <h3 className="font-black text-sm text-white flex items-center gap-2"><Bug className="text-orange-500" size={18}/> Bug Ledger</h3>
              <div className="flex items-center gap-2 text-[9px] font-black uppercase tracking-widest text-slate-500"><span className="cockpit-light bg-emerald-400 text-emerald-400 slow"></span>{crashLogs.length} recent logs</div>
            </div>
            <div className={`divide-y ${T.border} max-h-[70vh] overflow-y-auto custom-scrollbar`}>
              {crashLogs.length === 0 && <div className="p-8 text-center text-slate-500 font-bold">No bugs or crashes logged yet. System stable.</div>}
              {crashLogs.map(log => (
                <div key={log.id} className={`${T.row} flex flex-col gap-2 ${(`${log.message || ''} ${log.stack || ''}`.toLowerCase().includes('permission-denied')) ? 'bg-red-950/20' : ''}`}>
                  <div className="flex justify-between items-start">
                    <span className="text-xs font-black text-orange-400 bg-orange-900/20 px-2 py-0.5 rounded border border-orange-900/50 break-all leading-tight">{log.message}</span>
                    <span className={`text-[9px] font-bold ${T.muted} whitespace-nowrap ml-2`}>{new Date(log.time).toLocaleString()}</span>
                  </div>
                  {(log.restaurantId || log.user) && (
                    <div className="text-[9px] mt-1 flex flex-wrap gap-1.5">
                      {log.restaurantId && <span className="bg-[#0B0E11] border border-[#2A353D] px-2 py-0.5 rounded text-slate-400 font-bold">restaurantId: {log.restaurantId}</span>}
                      {log.user && <span className="bg-[#0B0E11] border border-[#2A353D] px-2 py-0.5 rounded text-slate-400 font-bold">user: {log.user}</span>}
                    </div>
                  )}
                  {(log.screenSize || log.userAgent) && (
                    <div className="text-[9px] mt-1.5 flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3 bg-[#0B0E11] p-1.5 rounded-lg border border-[#2A353D]">
                      {log.screenSize && <span className="font-black text-blue-400 whitespace-nowrap">🖥️ {log.screenSize}</span>}
                      {log.userAgent && <span className="font-medium text-slate-500 truncate" title={log.userAgent}>📱 {log.userAgent}</span>}
                    </div>
                  )}
                  {log.breadcrumbs && log.breadcrumbs.length > 0 && (
                    <div className="bg-[#0B0E11] rounded-lg border border-[#2A353D] p-2 mt-1">
                       <div className="text-[8px] font-black uppercase tracking-widest text-slate-500 mb-1">User Action Telemetry (Last 15 Clicks)</div>
                       <div className="text-[10px] font-mono text-slate-400 space-y-0.5">
                         {log.breadcrumbs.map((crumb, idx) => (
                           <div key={idx} className="flex gap-2 hover:bg-[#12161A] px-1 rounded transition-colors">
                             <span className="text-emerald-500/70">[{crumb.time}]</span>
                             <span className="text-slate-500">{crumb.action}:</span>
                             <span className="text-blue-300">"{crumb.target}"</span>
                           </div>
                         ))}
                       </div>
                    </div>
                  )}
                  {log.stack && <div className="text-[9px] text-slate-500 font-mono mt-1 overflow-x-auto whitespace-pre-wrap bg-[#0B0E11] p-2 rounded border border-[#2A353D] opacity-70 hover:opacity-100 transition-opacity">{log.stack}</div>}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* --- TAB: FORENSICS (GLOBAL AUDIT TRAIL) --- */}
<Modal isOpen={isRawInspectorOpen} onClose={() => { setIsRawInspectorOpen(false); setRawInspectorData(null); }} title="Raw Database Inspector">
        <div className="space-y-4">
          <form onSubmit={handleFetchRawDoc} className="flex gap-2">
            <select value={rawInspectorCollection} onChange={e=>setRawInspectorCollection(e.target.value)} className={`${T.input} w-1/3`}>
              <option value="users">Users</option>
              <option value="restaurants">Restaurants</option>
              <option value="shifts">Shifts</option>
              <option value="recipes">Recipes</option>
              <option value="inventoryItems">Inventory</option>
              <option value="timePunches">Time Punches</option>
            </select>
            <input type="text" value={rawInspectorId} onChange={e=>setRawInspectorId(e.target.value)} placeholder="Paste Document ID..." className={`${T.input} flex-1`} required />
            <button type="submit" className={`${T.btn} px-4`}><Search size={18}/></button>
          </form>
    {rawInspectorData && (
            <div className="bg-[#0B0E11] p-4 rounded-xl border border-[#2A353D] overflow-x-auto max-h-[50vh] custom-scrollbar">
              <pre className="text-[10px] text-emerald-400 font-mono leading-relaxed whitespace-pre-wrap break-all">
                {JSON.stringify(rawInspectorData, null, 2)}
              </pre>
            </div>
          )}
        </div>
      </Modal>
      {subTab === 'forensics' && (
        <div className={`${T.card} overflow-hidden animate-[slideIn_0.2s_ease-out]`}>
<div className={`bg-[#12161A] p-4 border-b ${T.border} flex justify-between items-center`}>
            <h3 className="font-black text-sm text-white flex items-center gap-2"><Search className="text-blue-500" size={18}/> Global Forensics & Ghost Audit</h3>
            <button onClick={() => setIsRawInspectorOpen(true)} className="bg-blue-900/20 text-blue-400 border border-blue-900/50 hover:bg-blue-900/40 text-[10px] font-black uppercase tracking-widest px-3 py-1.5 rounded-lg transition-colors shadow-sm flex items-center gap-2">
              <Wrench size={12} /> Inspect Raw JSON
            </button>
          </div>          <div className={`divide-y ${T.border} max-h-[70vh] overflow-y-auto custom-scrollbar`}>
            {auditLogs.length === 0 && <div className="p-8 text-center text-slate-500 font-bold">No forensic data logged yet.</div>}
            {auditLogs.map(log => (
              <div key={log.id} className={`${T.row} flex flex-col gap-1`}>
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-sm">{log.userName}</span>
                    {log.isGhost && <span className="bg-purple-900/20 text-purple-400 border border-purple-500/50 text-[8px] px-1.5 py-0.5 rounded uppercase font-black tracking-widest flex items-center gap-1">👻 Ghost Action</span>}
                    <span className={`text-[9px] uppercase font-black tracking-widest bg-[#12161A] border ${T.border} text-blue-400 px-2 py-0.5 rounded`}>{log.action}</span>
                  </div>
                  <span className={`text-[9px] font-bold ${T.muted} whitespace-nowrap ml-2`}>{new Date(log.timestamp).toLocaleString()}</span>
                </div>
       <div className="text-xs text-slate-300 font-medium mt-1 break-words whitespace-pre-wrap">
                  {log.details} <span className="text-slate-500 ml-1">Target: [{log.target}]</span> <span className="text-[#D4A381] ml-1">Tenant ID: {log.restaurantId}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* --- TAB: OPERATIONS --- */}
      {subTab === 'ops' && (
        <div className="space-y-6 animate-[slideIn_0.2s_ease-out]">
          <form onSubmit={handleMegaphone} className={`${T.card} p-5`}>
            <div className="mb-4 pb-2 border-b border-[#2A353D]"><h2 className="text-lg font-black text-white">System Megaphone</h2><p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mt-1">Push a priority system alert to the message board of every single restaurant.</p></div>
            <textarea value={broadcastMsg} onChange={e=>setBroadcastMsg(e.target.value)} rows="3" className={`${T.input} mb-3 border-[#D4A381]/50 focus:border-[#D4A381]`} placeholder="SYSTEM ALERT: Maintenance scheduled for 3AM..."></textarea>
            <button type="submit" className="w-full bg-[#12161A] text-[#D4A381] border border-[#2A353D] hover:bg-[#1A2126] font-black uppercase tracking-widest py-3 rounded-xl transition-colors">Blast Message</button>
          </form>

    <div className={`${T.card} p-5 border-blue-900/50 shadow-[0_0_15px_rgba(59,130,246,0.05)]`}>
            <form onSubmit={handlePushBanner}>
              <div className="mb-4 pb-2 border-b border-[#2A353D]">
                <h2 className="text-lg font-black text-blue-400 flex items-center gap-2"><Bell size={18}/> Top-of-App Banner Broadcast</h2>
                <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mt-1">Pin a persistent, high-visibility alert directly below the main header.</p>
              </div>
              <div className="space-y-3">
                <select value={bannerTarget} onChange={e => setBannerTarget(e.target.value)} className={T.input}>
                  <option value="ALL">🚨 ALL WORKSPACES (GLOBAL)</option>
                  {restaurants.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                </select>
                <input type="text" value={bannerText} onChange={e => setBannerText(e.target.value)} placeholder="e.g. SYSTEM DEGRADED - POS SYNC IS CURRENTLY DOWN" className={T.input} />
                <div className="flex gap-2">
                  <button type="submit" className="flex-1 bg-blue-900/20 text-blue-400 border border-blue-900/50 hover:bg-blue-900/40 font-black uppercase tracking-widest py-3 rounded-xl transition-colors shadow-sm">Pin Banner</button>
                  <button type="button" onClick={handleClearBanner} className="px-6 bg-[#12161A] text-slate-400 border border-[#2A353D] hover:text-red-400 font-black uppercase tracking-widest py-3 rounded-xl transition-colors shadow-sm">Clear Selected</button>
                </div>
              </div>
            </form>

            {/* THE ACTIVE BANNER LEDGER */}
            {restaurants.filter(r => r.systemBanner).length > 0 && (
              <div className="mt-5 pt-4 border-t border-[#2A353D] animate-[slideIn_0.2s_ease-out]">
                <h3 className="text-[10px] font-black uppercase text-[#D4A381] tracking-widest mb-3">Currently Active Banners</h3>
                <div className="space-y-2 max-h-48 overflow-y-auto custom-scrollbar pr-2">
                  {restaurants.filter(r => r.systemBanner).map(r => (
                    <div key={r.id} className="flex justify-between items-center bg-[#12161A] p-3 rounded-xl border border-[#2A353D]">
                      <div className="min-w-0 pr-3">
                        <div className="text-xs font-bold text-white truncate">{r.name}</div>
                        <div className="text-[10px] text-blue-400 font-bold mt-0.5 leading-snug break-words">"{r.systemBanner}"</div>
                      </div>
                      <button type="button" onClick={async () => {
                        if(!window.confirm(`Clear banner for ${r.name}?`)) return;
                        await updateDoc(doc(db, "restaurants", r.id), { systemBanner: null });
                        addToast('Cleared', `Banner removed from ${r.name}.`);
                      }} className="text-slate-400 hover:text-red-500 p-2 flex-shrink-0 transition-colors bg-[#1A2126] rounded-lg border border-[#2A353D]"><Trash2 size={14}/></button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          
<div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className={`${T.card} p-5 border-amber-900/30`}>
              <h3 className="font-black text-white mb-1">Deploy Demo Workspace</h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-4 leading-snug">Automatically inject a fake restaurant populated with staff, shifts, prep lists, and data across every tab for showcasing.</p>
              <button onClick={handleInjectDemoWorkspace} type="button" className="w-full bg-amber-900/20 text-amber-400 border border-amber-900/50 font-black text-xs uppercase tracking-widest py-3 rounded-xl hover:bg-amber-900/40 transition-colors flex items-center justify-center gap-2"><Star size={16}/> Build Showcase</button>
            </div>
            <div className={`${T.card} p-5 border-fuchsia-900/30`}>
              <h3 className="font-black text-white mb-1">Test Push Notifications</h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-4 leading-snug">Fires a live test ping through Vercel to verify tokens and Firebase Admin credentials are working.</p>
              <button onClick={handleTestPush} type="button" className="w-full bg-fuchsia-900/20 text-fuchsia-400 border border-fuchsia-900/50 font-black text-xs uppercase tracking-widest py-3 rounded-xl hover:bg-fuchsia-900/40 transition-colors flex items-center justify-center gap-2"><Bell size={16}/> Fire Test Alert</button>
            </div>
            <div className={`${T.card} p-5 border-emerald-900/30`}>
              <h3 className="font-black text-white mb-1">Global Force Refresh</h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-4 leading-snug">Pushes a silent command to all active devices to instantly hard-reload the browser. Use after deploying new code.</p>
              <button onClick={handleForceRefresh} className="w-full bg-emerald-900/20 text-emerald-400 border border-emerald-900/50 font-black text-xs uppercase tracking-widest py-3 rounded-xl hover:bg-emerald-900/40 transition-colors">Execute Global Refresh</button>
            </div>
            <div className={`${T.card} p-5 border-blue-900/30`}>
              <h3 className="font-black text-white mb-1">Orphan Data Sweeper</h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-4 leading-snug">Scans all global databases for shifts assigned to employees that have been fully deleted. Reclaims server space.</p>
              <button onClick={handleOrphanSweep} className="w-full bg-blue-900/20 text-blue-400 border border-blue-900/50 font-black text-xs uppercase tracking-widest py-3 rounded-xl hover:bg-blue-900/40 transition-colors">Run DB Sweep</button>
            </div>
            
            <div className={`${T.card} p-5 border-red-900/30 sm:col-span-2`}>
              <h3 className="font-black text-white mb-1">Global Lockdown</h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-4 leading-snug">Instantly suspends every tenant by triggering the Past Due billing lock. Bypasses your own workspace to prevent self-lockout.</p>
              <div className="grid grid-cols-2 gap-3">
                <button onClick={() => handleGlobalLockdown(true)} className="w-full bg-red-900/20 text-red-500 border border-red-900/50 font-black text-xs uppercase tracking-widest py-3 rounded-xl hover:bg-red-900/40 transition-colors flex items-center justify-center gap-2"><Shield size={16}/> Lock All</button>
                <button onClick={() => handleGlobalLockdown(false)} className="w-full bg-[#12161A] text-slate-300 border border-[#2A353D] font-black text-xs uppercase tracking-widest py-3 rounded-xl hover:text-white transition-colors flex items-center justify-center gap-2">Unlock All</button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* --- TAB: ACCESS CONTROL --- */}
      {subTab === 'admins' && (
        <div className="space-y-6 animate-[slideIn_0.2s_ease-out]">
          <form onSubmit={handleGrantAccess} className={`${T.card} p-5`}>
            <div className="mb-4 pb-2 border-b border-[#2A353D]"><h2 className="text-lg font-black text-white">Grant Administrator Access</h2><p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mt-1">Add a user's exact email address to grant full system control.</p></div>
            <div className="flex flex-col sm:flex-row gap-3"><input type="email" placeholder="User's exact email..." value={adminEmail} onChange={e=>setAdminEmail(e.target.value)} className={T.input} required /><button type="submit" className={`${T.btn} px-8`}>Grant Access</button></div>
          </form>
          <div className={`${T.card} overflow-hidden`}><div className={`bg-[#12161A] p-4 border-b ${T.border}`}><h3 className="font-black text-sm text-white">Platform Administrators</h3></div><div className={`divide-y ${T.border}`}>{superAdmins.map(admin => (<div key={admin.id} className={`${T.row} flex justify-between items-center`}><div><div className="font-black text-white">{admin.name}</div><div className="text-[10px] font-bold text-slate-400">{admin.email}</div></div><button onClick={() => handleRevokeAccess(admin)} className="px-3 py-1.5 bg-[#12161A] border border-[#2A353D] text-red-500 font-bold text-[10px] uppercase tracking-widest rounded-lg hover:bg-[#1A2126] transition-colors">Revoke</button></div>))}</div></div>
        </div>
      )}
    </div>
  );
};



export default function App() {
  const [appUser, setAppUser] = useState(() => { 
    try {
      const savedLocal = localStorage.getItem('86chaosUser'); 
      const savedSession = sessionStorage.getItem('86chaosUser');
      return savedLocal ? JSON.parse(savedLocal) : (savedSession ? JSON.parse(savedSession) : null);
    } catch (err) {
      console.warn('Stored session was corrupted. Clearing local session cache.', err);
      localStorage.removeItem('86chaosUser');
      sessionStorage.removeItem('86chaosUser');
      return null;
    }
  });
  // --- GHOST MODE & ROUTING STATE ---
  const [ghostTenant, setGhostTenant] = useState(null);
      
  const rId = ghostTenant ? ghostTenant.id : appUser?.restaurantId;
  
  // --- VERSION CHECKER STATE & LOGIC ---
  const [showUpdateBanner, setShowUpdateBanner] = useState(false);

  useEffect(() => {
    const checkAppVersion = async () => {
      try {
        const response = await fetch(`/version.json?t=${Date.now()}`);
        if (response.ok) {
          const data = await response.json();
          if (data.version !== CURRENT_VERSION) {
            setShowUpdateBanner(true);
          }
        }
      } catch (error) {
        console.warn("Background version check failed:", error);
      }
    };

    checkAppVersion();
    const versionInterval = setInterval(checkAppVersion, 3 * 60 * 1000);
    return () => clearInterval(versionInterval);
  }, []);



  
                    
  // --- APP INSTALL TRACKER (NEW) ---
  useEffect(() => {
    const handleAppInstall = () => {
      const currentUser = JSON.parse(localStorage.getItem('86chaosUser'));
      logAudit(currentUser, 'APP_INSTALLED', 'Device OS', 'User installed 86chaos as a native app to their device.');
    };
    window.addEventListener('appinstalled', handleAppInstall);
    return () => window.removeEventListener('appinstalled', handleAppInstall);
  }, []);

// --- DATABASE IMPORTS (Optimized) ---
  const users = useLiveCollection('users', rId);
  const shifts = useLiveCollection('shifts', rId);
  const shiftSwaps = useLiveCollection('shiftSwaps', rId);
  const events = useLiveCollection('events', rId);
  const sales = useLiveCollection('sales', rId);
  const timeOffRequests = useLiveCollection('timeOffRequests', rId);
  const timePunches = useLiveCollection('timePunches', rId);
  
// --- LIVE APP USER LOGIC ---
  const fullGhostPermissions = { schedule: true, events: true, ops: true, inventory: true, prep: true, sales: true, team: true };
  const realAppUser = appUser ? (appUser.id === 'dev-backdoor' ? appUser : (users?.find(u => u.id === appUser.id) || appUser)) : null;
  let liveAppUser = realAppUser;

  if (ghostTenant && realAppUser) {
    const ghostWorkspaceId = ghostTenant.id || ghostTenant.restaurantId;
    const realName = realAppUser.name || realAppUser.email || 'System Admin';

    if (ghostTenant.impersonate) {
       // USER POSSESSION MODE:
       // Show the target user's "My Schedule" and profile identity, but keep your support/admin powers
       // so Schedule Builder, Team, Settings, Sales, Inventory, etc. still load for that workspace.
       liveAppUser = {
         ...ghostTenant.impersonate,
         restaurantId: ghostWorkspaceId,
         restaurantName: ghostTenant.name,
         isAdmin: true,
         isSuperAdmin: realAppUser.isSuperAdmin || realAppUser.email?.toLowerCase() === MASTER_ADMIN_EMAIL.toLowerCase(),
         role: `Ghosting ${ghostTenant.impersonate.role || 'User'}`,
         permissions: { ...fullGhostPermissions, ...(ghostTenant.impersonate.permissions || {}) },
         isGhost: true,
         ghostMode: 'user',
         ghostRealUserId: realAppUser.id,
         ghostRealUserName: realName,
         ghostTargetUserId: ghostTenant.impersonate.id,
         ghostTargetUserName: ghostTenant.impersonate.name || ghostTenant.impersonate.email || 'Target User'
       };
    } else {
       // WORKSPACE GHOST MODE: Enter the client account as a full support administrator.
       liveAppUser = {
         ...realAppUser,
         restaurantId: ghostWorkspaceId,
         restaurantName: ghostTenant.name,
         isAdmin: true,
         isSuperAdmin: true,
         role: 'System Administrator',
         permissions: { ...fullGhostPermissions, ...(realAppUser.permissions || {}) },
         isGhost: true,
         ghostMode: 'workspace',
         ghostRealUserId: realAppUser.id,
         ghostRealUserName: realName,
         ghostWorkspaceName: ghostTenant.name
       };
    }
  }

  // --- REMOTE SESSION KILL SWITCH ---
  useEffect(() => {
    if (liveAppUser?.forceLogout) {
      updateDoc(doc(db, "users", liveAppUser.id), { forceLogout: false }).catch(()=>{});
      localStorage.removeItem('86chaosUser');
      sessionStorage.removeItem('86chaosUser');
      setAppUser(null);
      alert("Session terminated by System Administrator to clear a cache error. Please log in again.");
    }
  }, [liveAppUser?.forceLogout]);



  const [activeTabState, setActiveTabState] = useState('published');
  const [labelsToPrint, setLabelsToPrint] = useState(null);

  // --- GLOBAL WORKSPACE & HEALTH PING ---
  const [clientData, setClientData] = useState({});
  const clientFeatures = clientData?.features || {};

  // Safety net: if System Admin disables a module while a user still has that tab open,
  // send them back to the main Time Clock/Shifts screen instead of showing a blank page.
  useEffect(() => {
    const gatedTabs = ['ops', 'events', 'messages', 'prep', 'recipes', 'inventory', 'sales', 'team', 'maintenance', 'schedule'];
    if (gatedTabs.includes(activeTabState) && clientFeatures?.[activeTabState] === false) {
      setActiveTab('published');
    }
  }, [activeTabState, clientFeatures]);

// THE FIX: Safely attach BOTH the System Settings and the Plan Tier to the live user
if (liveAppUser && clientData) {
     liveAppUser = { 
       ...liveAppUser, 
       systemSettings: clientData.systemSettings || {},
       planType: clientData.planType || 'Pro'
     };
  }
  useEffect(() => {
    if (!rId) return;
    
    // 1. Fetch Master Client Data (Features & Billing)
    const unsub = onSnapshot(doc(db, 'restaurants', rId), (d) => {
      if (d.exists()) {
         const data = d.data();
         setClientData(data);
         
         // FORCE REFRESH LISTENER
         const localRefresh = sessionStorage.getItem('lastRefreshSignal');
         if (data.forceRefresh && data.forceRefresh !== localRefresh) {
            sessionStorage.setItem('lastRefreshSignal', data.forceRefresh);
            if (localRefresh) {
                // Instantly triggers a hard reload and pulls fresh cache from Vercel
                window.location.reload(true);
            }
         }
      }
    });

// 2. Live Presence Heartbeat (Only real users, never Ghost Mode)
    let heartbeatTimer = null;
    let handleVisibility = null;
    let handleBeforeUnload = null;

    if (!ghostTenant && appUser?.id) {
      let sessionId = sessionStorage.getItem('chaosSessionId');
      if (!sessionId) {
        sessionId = `${appUser.id}_${Date.now()}_${Math.random().toString(36).slice(2)}`;
        sessionStorage.setItem('chaosSessionId', sessionId);
      }

      const sendHeartbeat = (state = 'online') => {
        const stamp = new Date().toISOString();
        const device = (navigator.userAgent || 'Unknown device').substring(0, 140);
        updateDoc(doc(db, 'restaurants', rId), { lastActive: stamp }).catch(()=>{});
        updateDoc(doc(db, 'users', appUser.id), {
          lastActive: stamp,
          lastSeen: stamp,
          onlineState: state,
          activeTab: activeTabState,
          activeSessionId: sessionId,
          activeDevice: device,
          activeHost: window.location.hostname
        }).catch(()=>{});
      };

      sendHeartbeat(document.hidden ? 'away' : 'online');
      heartbeatTimer = setInterval(() => sendHeartbeat(document.hidden ? 'away' : 'online'), 60000);
      handleVisibility = () => sendHeartbeat(document.hidden ? 'away' : 'online');
      handleBeforeUnload = () => sendHeartbeat('offline');
      document.addEventListener('visibilitychange', handleVisibility);
      window.addEventListener('beforeunload', handleBeforeUnload);
    }

    return () => {
      unsub();
      if (heartbeatTimer) clearInterval(heartbeatTimer);
      if (handleVisibility) document.removeEventListener('visibilitychange', handleVisibility);
      if (handleBeforeUnload) window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [rId, ghostTenant, appUser?.id, activeTabState]);

 
  useEffect(() => {
    const handlePopState = (e) => { if (e.state && e.state.tab) setActiveTabState(e.state.tab); else setActiveTabState('published'); };
    window.addEventListener('popstate', handlePopState);
    const params = new URLSearchParams(window.location.search);
    const preferredTab = appUser?.preferences?.defaultTab || (appUser?.isAdmin ? 'schedule' : 'published');
    const tab = params.get('tab') || preferredTab;
    setActiveTabState(tab); window.history.replaceState({ tab }, '', `?tab=${tab}`);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [appUser]);

  const setActiveTab = (tab) => { window.history.pushState({ tab }, '', `?tab=${tab}`); setActiveTabState(tab); };

useEffect(() => {
    const shouldRemember = localStorage.getItem('chaosRememberMe') !== 'false';
    if (appUser) {
      if (shouldRemember) {
        localStorage.setItem('86chaosUser', JSON.stringify(appUser));
        sessionStorage.removeItem('86chaosUser');
      } else {
        sessionStorage.setItem('86chaosUser', JSON.stringify(appUser));
        localStorage.removeItem('86chaosUser');
      }
    } else {
      localStorage.removeItem('86chaosUser');
      sessionStorage.removeItem('86chaosUser');
    }
  }, [appUser]);

  // --- AUTO-LOGOUT INACTIVITY TIMER (30 MINUTES) ---
  useEffect(() => {
    if (!appUser) return;
    let timeoutId;
    
    const logoutUser = () => {
      setAppUser(null);
      alert("You have been automatically logged out due to inactivity.");
    };
    
    const resetTimer = () => {
      clearTimeout(timeoutId);
      // Change the 30 below to whatever minute threshold you prefer
      timeoutId = setTimeout(logoutUser, 30 * 60 * 1000); 
    };
    
    // Listen for any kind of interaction
    const events = ['mousedown', 'mousemove', 'keydown', 'scroll', 'touchstart'];
    events.forEach(e => document.addEventListener(e, resetTimer));
    resetTimer();
    
    return () => {
      clearTimeout(timeoutId);
      events.forEach(e => document.removeEventListener(e, resetTimer));
    };
  }, [appUser]);
  

  const [currentDate, setCurrentDate] = useState(getToday());
  const [toasts, setToasts] = useState([]);
  const [isDateModalOpen, setIsDateModalOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);


// --- NOTIFICATION DOT LOGIC (WITH READ RECEIPTS) ---
  // 1. Unread Messages (with NaN safety fallback)
  const latestNoteDate = events.filter(e => e.type === 'note').reduce((max, n) => {
     const dTime = new Date(n.date || 0).getTime();
     return isNaN(dTime) ? max : Math.max(max, dTime);
  }, 0);
  const lastReadMsg = liveAppUser ? parseInt(localStorage.getItem(`${liveAppUser.id}_lastReadMsg`) || '0') : 0;
  const hasUnreadMessages = latestNoteDate > lastReadMsg && activeTabState !== 'messages';

  // 2. Shift Swaps (Clear dot when they visit My Shift / Trade Board)
  const latestSwap = shiftSwaps.filter(s => s.status === 'available' && s.originalEmployeeId !== liveAppUser?.id).reduce((max, s) => Math.max(max, new Date(s.date).getTime()), 0);
  const lastReadSwaps = liveAppUser ? parseInt(localStorage.getItem(`${liveAppUser.id}_lastReadSwaps`) || '0') : 0;
  const hasAvailableSwaps = latestSwap > lastReadSwaps && activeTabState !== 'published'; 

  // 3. Manager Alerts (Clear dot when they visit Schedule Builder)
  const realCurrentMonthStr = getToday().substring(0, 7);
  const latestTimeOffReq = timeOffRequests.filter(r => r.status === 'pending' && r.date?.startsWith(realCurrentMonthStr)).reduce((max, r) => Math.max(max, new Date(r.submittedAt || 0).getTime()), 0);
  const lastReadTimeOff = liveAppUser ? parseInt(localStorage.getItem(`${liveAppUser.id}_lastReadTimeOff`) || '0') : 0;
  const isManagerAlert = !!(liveAppUser?.isAdmin || liveAppUser?.permissions?.schedule) && (latestTimeOffReq > lastReadTimeOff) && activeTabState !== 'schedule';

  // Consolidated Alerts
  const hasMyShiftAlert = hasAvailableSwaps; 
  const hasScheduleBuilderAlert = isManagerAlert; 
  const hasAnyMenuAlert = hasUnreadMessages || hasMyShiftAlert || hasScheduleBuilderAlert; 

  // The "Read Receipt" Engine - Clears the dots instantly when tabs are opened
  useEffect(() => {
    if (!liveAppUser) return;
    if (activeTabState === 'messages') localStorage.setItem(`${liveAppUser.id}_lastReadMsg`, Date.now().toString());
    if (activeTabState === 'published') localStorage.setItem(`${liveAppUser.id}_lastReadSwaps`, Date.now().toString());
    if (activeTabState === 'schedule') localStorage.setItem(`${liveAppUser.id}_lastReadTimeOff`, Date.now().toString());
  }, [activeTabState, events, shiftSwaps, timeOffRequests, liveAppUser]);

  const addToast = (title, message) => {
    const id = Date.now();
    setToasts(prev => [...prev, { id, title, message }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 6000);
  };

// --- AUTO-ASK FOR NOTIFICATIONS ON LOGIN ---
  useEffect(() => {
    if (liveAppUser && !ghostTenant && typeof window !== 'undefined' && 'Notification' in window) {
      // Only ask if they haven't made a decision yet
      if (Notification.permission === 'default') {
        // Wait 2.5 seconds after app load so the browser doesn't flag it as spam
        setTimeout(() => {
          Notification.requestPermission().then(async (permission) => {
            if (permission === 'granted' && messaging) {
              
              // THE FIX: Apply the Smart Target Lock here too
              const activeVapidKey = window.location.hostname === 'app.86chaos.com' 
                ? 'BJzM9xVnkPwLB6aq588ZHhekjqI_Z-xpInDquX_nknrDhew8ytFZbCA22uFN4iSKP_YvGV0sPH9M6aBzGCA9AcU' // Production
                : 'BO6mdu87G4ICBRZjY5e6mpsvCXdpV32TEyyJzJeQHZ4QXolGNsa6ncvgVAzRxIKihx83AxHS36aCtr--XzE45bc'; // Testing Sandbox

              const currentToken = await getToken(messaging, { 
                vapidKey: activeVapidKey 
              });
              if (currentToken) {
                await updateDoc(doc(db, "users", liveAppUser.id), { fcmToken: currentToken });
                addToast('Success', 'Push notifications enabled for this device.');
              }
            }
          });
        }, 2500);
      }
    }
  }, [liveAppUser?.id]);
                      
  // --- FOREGROUND NOTIFICATION CATCHER ---
  useEffect(() => {
    if (!messaging) return;
    const unsub = onMessage(messaging, (payload) => {
      console.log("Foreground message caught:", payload);
      addToast(
        payload.notification?.title || 'System Alert', 
        payload.notification?.body || 'You have a new notification.'
      );
    });
    return () => unsub();
  }, [addToast, messaging]);

  const prevDay = () => { const d = new Date(currentDate + 'T12:00:00'); d.setDate(d.getDate() - 1); setCurrentDate(formatDate(d)); };
  const nextDay = () => { const d = new Date(currentDate + 'T12:00:00'); d.setDate(d.getDate() + 1); setCurrentDate(formatDate(d)); };
  const prevMonth = () => { const d = new Date(currentDate + 'T12:00:00'); d.setMonth(d.getMonth() - 1); setCurrentDate(formatDate(d)); };
  const nextMonth = () => { const d = new Date(currentDate + 'T12:00:00'); d.setMonth(d.getMonth() + 1); setCurrentDate(formatDate(d)); };

  if (labelsToPrint) return <DayDotPrintScreen labelsToPrint={labelsToPrint.items} prepDate={labelsToPrint.prepDate} appUser={liveAppUser} onClose={() => setLabelsToPrint(null)} />;

  if (!liveAppUser) return <LoginScreen users={users} setAppUser={setAppUser} addToast={addToast} />;

  // BILLING LOCK SCREEN (Only locks real users, Super Admins in Ghost Mode bypass this)
  if (clientData?.billingStatus === 'Past Due' && !ghostTenant) {
    return (
      <div className={`min-h-screen flex flex-col items-center justify-center p-6 text-center ${T.bg}`}>
        <div className="bg-[#1A2126] p-8 rounded-3xl border border-red-900/50 shadow-2xl max-w-md w-full">
          <span className="text-6xl mb-4 block">🚫</span>
          <h1 className="text-2xl font-black text-white mb-2">Subscription Past Due</h1>
          <p className="text-slate-400 font-medium mb-6">Access to 86 Chaos has been temporarily suspended for {clientData.name || 'this workspace'}. Please contact your management team or 86 Chaos Support to renew your plan.</p>
          <button onClick={() => { localStorage.removeItem('86chaosUser'); setAppUser(null); }} className="w-full bg-red-900/20 text-red-500 font-black py-3 rounded-xl border border-red-900/50 hover:bg-red-900/40 transition-all uppercase tracking-widest">Log Out</button>
        </div>
      </div>
    );
  }

return (
    <div className={`ui-v13-polished ui-v12-compact cockpit-shell ui-density-${liveAppUser?.preferences?.uiDensity || clientData?.systemSettings?.uiDensity || 'compact'} recipe-density-${liveAppUser?.preferences?.recipeDensity || clientData?.systemSettings?.recipeCardDensity || 'tight'} motion-${liveAppUser?.preferences?.motionMode || clientData?.systemSettings?.cockpitLights || 'normal'} min-h-screen font-sans flex flex-col w-full max-w-[100vw] overflow-x-hidden ${T.bg}`}>
      
      {/* GHOST MODE BANNER */}
      {ghostTenant && (
        <div className="bg-gradient-to-r from-purple-900 to-fuchsia-900 text-white text-[11px] sm:text-xs font-black px-4 py-2.5 flex items-center justify-between sticky top-0 z-[99999] shadow-2xl uppercase tracking-wider border-b border-fuchsia-500/50">
          <div className="flex items-center gap-2 min-w-0">
            <Moon size={16} className="flex-shrink-0 animate-pulse text-fuchsia-300" />
            <span className="truncate">GHOST MODE OVERRIDE: {ghostTenant.impersonate ? `${ghostTenant.impersonate.name || ghostTenant.impersonate.email} @ ${ghostTenant.name}` : ghostTenant.name}</span>
          </div>
          <button onClick={() => { setGhostTenant(null); window.history.pushState({ tab: 'godmode' }, '', '?tab=godmode'); setActiveTabState('godmode'); }} className="bg-white text-purple-900 px-3 py-1.5 rounded-lg font-black text-[10px] shadow-md hover:bg-slate-100 transition-all tracking-widest flex-shrink-0 ml-3">
            EXIT GHOST MODE
          </button>
        </div>
      )}
      
      <style>{`
        html, body { overflow-x: hidden !important; max-width: 100vw !important; width: 100% !important; background-color: #0F1318 !important; }
        @keyframes slideIn { from { transform: translateX(100%); } to { transform: translateX(0); } }
        @keyframes toastSlide { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .animate-toast { animation: toastSlide 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
        input[type="date"]::-webkit-calendar-picker-indicator, input[type="month"]::-webkit-calendar-picker-indicator, input[type="time"]::-webkit-calendar-picker-indicator { filter: invert(1); }
        .custom-scrollbar::-webkit-scrollbar { width: 4px; height: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #475569; border-radius: 4px; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .cockpit-shell { --chaos-copper: #D4A381; --chaos-panel: #1A2126; --chaos-deck: #12161A; }
        .ui-v12-compact button { touch-action: manipulation; }
        .ui-v12-compact textarea { line-height: 1.35 !important; }
        .cockpit-light { position: relative; display: inline-flex; width: .55rem; height: .55rem; border-radius: 999px; box-shadow: 0 0 6px currentColor; }
        .cockpit-light::after { content: ''; position: absolute; inset: -4px; border-radius: 999px; background: currentColor; opacity: .08; animation: none; }
        .cockpit-light.quiet::after { animation: none !important; opacity: .08; }
        .cockpit-light.slow::after { animation: cockpitPing 5.5s infinite; opacity: .12; }
        .cockpit-light.hot::after { animation: cockpitPing 1.8s infinite; opacity: .24; }
        @keyframes cockpitPing { 0% { transform: scale(.75); opacity: .28; } 70%,100% { transform: scale(1.8); opacity: 0; } }
        @keyframes softGlow { 0%,100% { box-shadow: 0 0 0 rgba(212,163,129,0); } 50% { box-shadow: 0 0 18px rgba(212,163,129,.22); } }
        .cockpit-panel { background: linear-gradient(180deg, rgba(26,33,38,.98), rgba(15,19,24,.98)); border: 1px solid #2A353D; box-shadow: inset 0 1px 0 rgba(255,255,255,.035), 0 16px 50px rgba(0,0,0,.18); }
        .cockpit-grid { background-image: radial-gradient(circle at 1px 1px, rgba(212,163,129,.09) 1px, transparent 0); background-size: 18px 18px; }
        .line-clamp-2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
        .message-pro .message-card-pro { box-shadow: inset 0 1px 0 rgba(255,255,255,.025), 0 8px 28px rgba(0,0,0,.12); }
        .recipe-card-v13 { min-height: 0 !important; }
        .recipe-card-v13:hover { transform: translateY(-1px); }
        .ui-density-ultra main { padding: .6rem !important; }
        .ui-density-ultra .p-5 { padding: .75rem !important; }
        .ui-density-ultra .p-4 { padding: .65rem !important; }
        .ui-density-ultra .gap-4 { gap: .55rem !important; }
        .ui-density-comfortable main { padding: 1.25rem !important; }
        .recipe-density-tight .recipe-card-v13 .p-2\.5 { padding: .55rem !important; }
        .recipe-density-tight .recipe-card-v13 h3 { font-size: .9rem !important; line-height: 1.15rem !important; }
        .motion-reduced .cockpit-light::after, .motion-quiet .cockpit-light::after { animation: none !important; opacity: .08 !important; }
        .motion-quiet .cockpit-light { box-shadow: none !important; }

        @media (max-width: 640px) {
          .ui-v12-compact main { padding: .75rem !important; }
          .ui-v12-compact button:not(.no-compact) { min-height: 32px !important; padding-top: .42rem !important; padding-bottom: .42rem !important; }
          .ui-v12-compact textarea { min-height: 42px !important; font-size: 14px !important; }
          .ui-v12-compact .rounded-3xl { border-radius: 1rem !important; }
          .ui-v12-compact .rounded-2xl { border-radius: .85rem !important; }
          .ui-v12-compact .p-6 { padding: 1rem !important; }
          .ui-v12-compact .p-5 { padding: .85rem !important; }
          .ui-v12-compact .p-4 { padding: .75rem !important; }
          .ui-v12-compact .gap-5 { gap: .75rem !important; }
          .ui-v12-compact .gap-4 { gap: .65rem !important; }
          .ui-v12-compact .text-2xl { font-size: 1.25rem !important; line-height: 1.55rem !important; }
          .ui-v12-compact .text-xl { font-size: 1.05rem !important; line-height: 1.4rem !important; }
          .ui-v12-compact .text-lg { font-size: .98rem !important; line-height: 1.3rem !important; }
        }
      `}</style>

      {/* UPDATE ALERT BANNER */}
      {showUpdateBanner && (
        <div className="bg-red-600 text-white text-[11px] sm:text-xs font-black px-4 py-2.5 flex items-center justify-between sticky top-0 z-[9999] shadow-2xl uppercase tracking-wider">
          <div className="flex items-center gap-2 min-w-0">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="flex-shrink-0 animate-pulse text-white"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path><path d="M12 9v4"></path><path d="M12 17h.01"></path></svg>
            <span className="truncate">System update available. Refresh to prevent database desync.</span>
          </div>
          <button 
            onClick={() => window.location.reload(true)} 
            className="bg-white text-red-600 px-3 py-1.5 rounded-lg font-black text-[10px] shadow-md hover:bg-slate-100 transition-all tracking-widest flex-shrink-0 ml-3"
          >
            REFRESH NOW
          </button>
        </div>
      )}

      <header className="sticky top-0 z-40 shadow-sm border-b h-16 flex items-center justify-between px-4 bg-[#12161A]/95 backdrop-blur-md border-[#2A353D]">
        <CheersLogo />

        {/* DYNAMIC RESTAURANT NAME */}
        {liveAppUser && (
          <div className="flex-1 text-center px-4 truncate mt-1">
            <span className="text-[10px] sm:text-[11px] font-black uppercase tracking-widest text-slate-500">
              {liveAppUser.restaurantName || "Cheers"}
            </span>
          </div>
        )}

        <button onClick={() => setIsMenuOpen(true)} className={`relative p-2 border rounded-xl shadow-sm transition-all outline-none bg-[#1A2126] border-[#2A353D] ${T.copper} hover:text-white flex-shrink-0`}>
          <Menu size={20} />
          {hasAnyMenuAlert && <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-[#12161A] shadow-[0_0_8px_rgba(239,68,68,0.8)] animate-pulse"></span>}
        </button>
      </header>

      {/* SYSTEM BROADCAST BANNER */}
      {clientData?.systemBanner && (
        <div className="bg-blue-600 border-b border-blue-800 text-white text-[11px] sm:text-xs font-black px-4 py-2.5 flex items-center justify-center shadow-lg uppercase tracking-wider w-full relative z-30 animate-[slideIn_0.2s_ease-out]">
          <div className="flex items-center gap-2 text-center">
            <Bell size={14} className="animate-pulse flex-shrink-0" />
            <span>{clientData.systemBanner}</span>
          </div>
        </div>
      )}

      <DrawerMenu isOpen={isMenuOpen} onClose={() => setIsMenuOpen(false)} activeTab={activeTabState} setActiveTab={setActiveTab} appUser={liveAppUser} setAppUser={setAppUser} hasUnreadMessages={hasUnreadMessages} hasMyShiftAlert={hasMyShiftAlert} hasScheduleBuilderAlert={hasScheduleBuilderAlert} clientFeatures={clientFeatures} addToast={addToast} />    

      {ghostTenant?.impersonate && (
        <div className="bg-fuchsia-950/60 border-b border-fuchsia-500/30 px-4 py-2 text-[10px] sm:text-xs text-fuchsia-100 font-bold flex flex-wrap items-center justify-center gap-x-4 gap-y-1">
          <span>Viewing user: <strong>{ghostTenant.impersonate.name || 'Unnamed'}</strong></span>
          <span>Email: <strong>{ghostTenant.impersonate.email || 'No email'}</strong></span>
          <span>Role: <strong>{ghostTenant.impersonate.role || 'No role'}</strong></span>
          <span>User ID: <strong className="font-mono">{ghostTenant.impersonate.id}</strong></span>
        </div>
      )}
      
      {['schedule', 'events', 'published', 'month', 'sales', 'prep'].includes(activeTabState) && (
        <div className="py-4 px-4 shadow-sm z-30 border-b flex justify-between items-center bg-[#1A2126] border-[#2A353D] relative">
          {activeTabState === 'sales' ? (
            <div className="w-full text-center">
              <h2 className="text-xl sm:text-2xl font-black tracking-widest text-white uppercase">Sales & Trends</h2>
            </div>
          ) : (
            <>
              <button onClick={activeTabState === 'prep' ? prevDay : prevMonth} className="p-2 border rounded-xl transition-colors bg-[#12161A] border-[#2A353D] text-slate-400 hover:text-[#D4A381] relative z-10"><ChevronLeft size={20} /></button>
              
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <h2 onClick={() => setIsDateModalOpen(true)} className="text-xl sm:text-2xl font-black tracking-tight text-center cursor-pointer transition-colors text-white hover:text-[#D4A381] pointer-events-auto">
                  {activeTabState === 'prep' ? formatDisplayFullDate(currentDate) : formatDisplayMonth(getMonthStr(currentDate))}
                </h2>
              </div>

              <button onClick={activeTabState === 'prep' ? nextDay : nextMonth} className="p-2 border rounded-xl transition-colors bg-[#12161A] border-[#2A353D] text-slate-400 hover:text-[#D4A381] relative z-10"><ChevronRight size={20} /></button>
            </>
          )}
        </div>
      )}

      <Modal isOpen={isDateModalOpen} onClose={() => setIsDateModalOpen(false)} title="Select Date">
        <div className="space-y-4">
          <input 
            type={activeTabState === 'prep' || activeTabState === 'sales' ? 'date' : 'month'} 
            value={activeTabState === 'prep' || activeTabState === 'sales' ? currentDate : getMonthStr(currentDate)} 
            onChange={e => { 
              if (e.target.value) { 
                setCurrentDate(activeTabState === 'prep' || activeTabState === 'sales' ? e.target.value : e.target.value + '-01'); 
                setIsDateModalOpen(false); 
              } 
            }} 
            className={T.input} 
          />
          <button onClick={() => setIsDateModalOpen(false)} className={`w-full ${T.btn}`}>Close</button>
        </div>
      </Modal>

      <main className="flex-1 max-w-6xl mx-auto w-full p-3 sm:p-6 pb-24">
        {activeTabState === 'schedule' && (liveAppUser?.isAdmin || liveAppUser?.permissions?.schedule) && <TabSchedule key={`sch-${rId}`} currentDate={currentDate} users={users} shifts={shifts} events={events} timeOffRequests={timeOffRequests} timePunches={timePunches} addToast={addToast} appUser={liveAppUser} />}
        {activeTabState === 'events' && clientFeatures?.events !== false && (liveAppUser?.isAdmin || liveAppUser?.permissions?.events || liveAppUser?.permissions?.schedule || liveAppUser?.permissions?.team) && <TabSchedule key={`evt-${rId}`} currentDate={currentDate} users={users} shifts={shifts} events={events} timeOffRequests={timeOffRequests} timePunches={timePunches} addToast={addToast} appUser={liveAppUser} initialSubTab="events" hideSubTabs />}
        {activeTabState === 'published' && <TabMasterSchedule key={`pub-${rId}-${liveAppUser?.id}`} currentDate={currentDate} appUser={liveAppUser} users={users} shifts={shifts} shiftSwaps={shiftSwaps} timeOffRequests={timeOffRequests} events={events} addToast={addToast} />}
        {activeTabState === 'ops' && clientFeatures?.ops !== false && (liveAppUser?.isSuperAdmin || liveAppUser?.isAdmin || liveAppUser?.permissions?.ops) && <TabOpsCenter key={`ops-${rId}`} currentDate={currentDate} appUser={liveAppUser} users={users} shifts={shifts} events={events} sales={sales} timePunches={timePunches} addToast={addToast} />}
        {activeTabState === 'sales' && (liveAppUser?.isAdmin || liveAppUser?.permissions?.sales) && <TabSales key={`sal-${rId}`} sales={sales} timePunches={timePunches} users={users} addToast={addToast} appUser={liveAppUser} />}
        {activeTabState === 'messages' && <TabMessages key={`msg-${rId}`} events={events} appUser={liveAppUser} users={users} addToast={addToast} />}
        {activeTabState === 'prep' && <TabPrep key={`prp-${rId}`} currentDate={currentDate} appUser={liveAppUser} setLabelsToPrint={setLabelsToPrint} />}
        {activeTabState === 'recipes' && <TabRecipes key={`rec-${rId}`} appUser={liveAppUser} addToast={addToast} />}
        {activeTabState === 'inventory' && clientFeatures?.inventory !== false && <TabInventory key={`inv-${rId}`} addToast={addToast} appUser={liveAppUser} />}
        {activeTabState === 'team' && clientFeatures?.team !== false && <TabTeam key={`tea-${rId}`} appUser={liveAppUser} users={users} addToast={addToast} />}
        {activeTabState === 'maintenance' && clientFeatures?.maintenance !== false && (liveAppUser?.isAdmin || liveAppUser?.permissions?.team) && <TabMaintenance key={`mtn-${rId}`} appUser={liveAppUser} addToast={addToast} />}
        {activeTabState === 'settings' && <TabSettings key={`set-${rId}`} addToast={addToast} appUser={liveAppUser} clientData={clientData} users={users} />}
        {activeTabState === 'godmode' && ((liveAppUser?.email || '').toLowerCase() === MASTER_ADMIN_EMAIL.toLowerCase() || liveAppUser?.isSuperAdmin === true) && <TabGodMode key={`god-${rId}`} appUser={liveAppUser} addToast={addToast} setGhostTenant={setGhostTenant} setActiveTab={setActiveTab} />}
        {activeTabState === 'audit' && (liveAppUser?.isAdmin || liveAppUser?.isSuperAdmin) && <TabAuditLog key={`aud-${rId}`} appUser={liveAppUser} />}
      </main>
      
      <div className="fixed top-20 inset-x-0 mx-auto w-full max-w-md z-50 flex flex-col gap-2 px-4 pointer-events-none">
        {toasts.map(t => (
          <div key={t.id} className="bg-[#1A2126] text-white p-3 rounded-xl shadow-2xl pointer-events-auto flex items-start gap-3 border border-[#2A353D] animate-toast">
            <div className="bg-[#12161A] p-1.5 rounded-full text-[#D4A381] mt-0.5 border border-[#2A353D]"><Bell size={16} /></div>
            <div className="flex-1"><h4 className="font-bold text-sm leading-tight">{t.title}</h4><p className="text-xs text-slate-300 font-medium mt-0.5">{t.message}</p></div>
            <button onClick={() => setToasts(prev => prev.filter(toast => toast.id !== t.id))} className="text-slate-400 hover:text-white"><X size={16}/></button>
          </div>
        ))}
      </div>
      
      <div className="w-full flex flex-col items-center justify-center py-4 border-t z-10 mt-auto bg-[#161D22] border-[#2A353D]">
        <img src="/6139.png" alt="86 Chaos OS" className="h-6 sm:h-8 w-auto mb-1.5 rounded shadow-sm opacity-80" onError={(e) => e.target.style.display = 'none'}/>
        <span className="text-slate-500 font-bold text-[10px] tracking-widest uppercase">Beta Version 11.8.0 Admin/UI Polish</span>
        <span className="text-slate-600 font-bold text-[8px] tracking-widest uppercase mt-1">© 2026 Chilton App Works LLC</span>
      </div>
    </div>
  );
}