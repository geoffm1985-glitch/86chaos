@echo off
setlocal enableextensions
cd /d "
C:\Users\geoff\Documents\GitHub\86chaos
"
call 
npm run test:client -- --runInBand --coverage --verbose --reporters=default --reporters="C:\Users\geoff\Documents\GitHub\86chaos\test-tools\reporters\jest-live-timer.cjs"
exit /b %ERRORLEVEL%
