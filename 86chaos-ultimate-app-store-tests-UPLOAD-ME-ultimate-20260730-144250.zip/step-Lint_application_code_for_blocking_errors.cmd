@echo off
setlocal enableextensions
cd /d "
C:\Users\geoff\Documents\GitHub\86chaos
"
call 
npm run lint -- --config test-tools/config/eslint.cjs --quiet
exit /b %ERRORLEVEL%
