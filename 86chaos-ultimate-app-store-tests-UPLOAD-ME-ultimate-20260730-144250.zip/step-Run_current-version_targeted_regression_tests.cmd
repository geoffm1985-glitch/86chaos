@echo off
setlocal enableextensions
cd /d "
C:\Users\geoff\Documents\GitHub\86chaos
"
call 
node scripts\test-16-0-67-targeted.cjs
exit /b %ERRORLEVEL%
