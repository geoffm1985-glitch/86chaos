@echo off
setlocal enableextensions
cd /d "
C:\Users\geoff\Documents\GitHub\86chaos
"
call 
node_modules\.bin\playwright.cmd test --config=playwright.ultimate-app-store.config.cjs
exit /b %ERRORLEVEL%
