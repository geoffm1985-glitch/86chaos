@echo off
setlocal enableextensions
cd /d "
C:\Users\geoff\Documents\GitHub\86chaos
"
call 
node test-tools/run-node-tests.cjs
exit /b %ERRORLEVEL%
