@echo off
setlocal enableextensions
cd /d "
C:\Users\geoff\Documents\GitHub\86chaos
"
call 
node_modules\.bin\playwright.cmd install chromium firefox webkit
exit /b %ERRORLEVEL%
