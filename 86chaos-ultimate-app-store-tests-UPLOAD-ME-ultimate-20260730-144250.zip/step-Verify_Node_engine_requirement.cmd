@echo off
setlocal enableextensions
cd /d "
C:\Users\geoff\Documents\GitHub\86chaos
"
call 
npm run node:check
exit /b %ERRORLEVEL%
