@echo off
setlocal enableextensions
cd /d "
C:\Users\geoff\Documents\GitHub\86chaos
"
call 
node scripts/86chaos-release-gate/collect-release-gate-report.cjs
exit /b %ERRORLEVEL%
