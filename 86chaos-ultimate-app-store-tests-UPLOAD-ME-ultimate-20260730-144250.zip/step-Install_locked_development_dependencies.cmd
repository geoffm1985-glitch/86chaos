@echo off
setlocal enableextensions
cd /d "
C:\Users\geoff\Documents\GitHub\86chaos
"
call 
npm ci --include=dev --no-audit --no-fund
exit /b %ERRORLEVEL%
