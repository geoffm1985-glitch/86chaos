@echo off
setlocal enableextensions
cd /d "
C:\Users\geoff\Documents\GitHub\86chaos
"
call 
node scripts/86chaos-release-gate/verify-role-accounts.cjs
exit /b %ERRORLEVEL%
