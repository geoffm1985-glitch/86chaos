@echo off
setlocal enableextensions
cd /d "
C:\Users\geoff\Documents\GitHub\86chaos
"
call 
node test-tools/analyze-app.cjs
exit /b %ERRORLEVEL%
