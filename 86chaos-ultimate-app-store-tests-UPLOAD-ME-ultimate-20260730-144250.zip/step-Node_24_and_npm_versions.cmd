@echo off
setlocal enableextensions
cd /d "
C:\Users\geoff\Documents\GitHub\86chaos
"
call 
node --version && npm --version
exit /b %ERRORLEVEL%
